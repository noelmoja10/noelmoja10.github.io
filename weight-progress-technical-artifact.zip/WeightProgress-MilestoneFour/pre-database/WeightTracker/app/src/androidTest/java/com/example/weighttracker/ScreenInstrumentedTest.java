package com.example.weighttracker;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.SystemClock;
import android.graphics.Bitmap;
import android.widget.EditText;
import androidx.lifecycle.ViewModelProvider;
import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry;
import androidx.test.runner.lifecycle.Stage;
import com.example.weighttracker.data.*;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.presentation.*;
import com.example.weighttracker.ui.*;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** UI actions + real SQLite on synthetic test files. Never enables a real SMS gateway. */
@RunWith(AndroidJUnit4.class)
public class ScreenInstrumentedTest {
    private final Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
    private WeightApplication app;
    private DatabaseHelper helper;
    private WeightRepository originalRepo;
    private GoalAlerts originalAlerts;
    private String databaseName;
    private long user;
    @Before public void setup() throws Exception {
        app = ApplicationProvider.getApplicationContext();
        originalRepo = app.repository; originalAlerts = app.alerts;
        databaseName = "screen-test-" + UUID.randomUUID() + ".db";
        helper = new DatabaseHelper(app, databaseName);
        app.repository = new SqliteWeightRepository(helper);
        app.alerts = new GoalAlerts(app.repository, new GoalAlerts.Gateway() {
            public boolean permitted() { return false; }
            public void request(String phone, double current, double goal) { throw new AssertionError("No real SMS allowed"); }
        });
        user = app.worker.submit(() -> app.repository.register("Noel", "Tester", "qa@example.com", "5551234567", "Testpass1")).get(10, TimeUnit.SECONDS);
        app.worker.submit(() -> app.repository.finishSetup(user,null,null,"lbs","",false)).get(10,TimeUnit.SECONDS);
        instrumentation.runOnMainSync(() -> app.session.signIn(user));
    }
    @After public void cleanup() throws Exception {
        instrumentation.runOnMainSync(() -> {
            Set<Activity> activities = new HashSet<>();
            for (Stage stage : Stage.values()) activities.addAll(ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(stage));
            for (Activity a : activities) if (!a.isDestroyed()) a.finish();
            app.session.logout();
        });
        instrumentation.waitForIdleSync();
        app.worker.submit(() -> { }).get(10, TimeUnit.SECONDS);
        helper.close(); app.deleteDatabase(databaseName);
        app.repository = originalRepo; app.alerts = originalAlerts;
    }
    private void awaitMain(BooleanSupplier condition) {
        long deadline = SystemClock.uptimeMillis() + 10000;
        while (SystemClock.uptimeMillis() < deadline) {
            boolean[] satisfied = {false};
            instrumentation.runOnMainSync(() -> satisfied[0] = condition.getAsBoolean());
            if (satisfied[0]) return;
            SystemClock.sleep(25);
        }
        fail("UI condition timed out");
    }
    private <T extends Activity> T current(Class<T> type) {
        AtomicReference<T> found = new AtomicReference<>();
        awaitMain(() -> {
            for (Activity a : ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED))
                if (type.isInstance(a)) { found.set(type.cast(a)); return true; }
            return false;
        });
        return found.get();
    }
    private WeightEditorViewModel editorModel(Activity activity) { return new ViewModelProvider((WeightEditorActivity) activity).get(WeightEditorViewModel.class); }
    private void put(Activity activity, int id, String value) { ((EditText) activity.findViewById(id)).setText(value); }
    private String text(Activity activity, int id) { return ((EditText) activity.findViewById(id)).getText().toString(); }
    private android.view.View findLabel(android.view.View view,String label) {
        if (view instanceof android.widget.TextView && label.equalsIgnoreCase(((android.widget.TextView)view).getText().toString())) return view;
        if (view instanceof android.view.ViewGroup) { android.view.ViewGroup group = (android.view.ViewGroup)view; for (int i = 0; i < group.getChildCount(); i++) { android.view.View found = findLabel(group.getChildAt(i),label); if (found != null) return found; } }
        return null;
    }
    private android.view.View dialogLabel(String text) {
        for (android.view.View root : android.view.inspector.WindowInspector.getGlobalWindowViews()) { android.view.View found = findLabel(root,text); if (found != null && found.isShown()) return found; }
        throw new AssertionError("Dialog control missing: " + text);
    }
    private long seed() throws Exception {
        return app.worker.submit(() -> app.repository.save(user, new WeightInput(-1, "2026-09-18", 181.26, "original", 150.25))).get(10, TimeUnit.SECONDS);
    }
    private Intent editorIntent(long id) { return new Intent(app, WeightEditorActivity.class).putExtra("recordId", id); }
    private void screenshot(String name) {
        instrumentation.waitForIdleSync();
        // Activity lifecycle callbacks can finish before the compositor's transition frames.
        // This delay affects evidence capture only; assertions above use state-based waits.
        SystemClock.sleep(1000);
        instrumentation.waitForIdleSync();
        Bitmap image = instrumentation.getUiAutomation().takeScreenshot();
        assertNotNull(image);
        File file = new File(app.getExternalFilesDir("ui-review-evidence"), name + ".png");
        try (FileOutputStream output = new FileOutputStream(file)) { image.compress(Bitmap.CompressFormat.PNG, 100, output); }
        catch (Exception failure) { throw new AssertionError(failure); }
        finally { image.recycle(); }
    }

    @Test public void tabSlidesFollowOrderAndNeverTranslateBottomNavigation() throws Exception {
        org.junit.Assume.assumeTrue(android.animation.ValueAnimator.areAnimatorsEnabled());
        Class<?>[] screens = {HomeActivity.class, HistoryActivity.class, WeightEditorActivity.class, MeActivity.class};
        int[] buttons = {R.id.navHomeButton, R.id.navHistoryButton, R.id.navAddEntryButton, R.id.navMeButton};
        // Every distinct ordered pair, including the reported Me -> Add Entry regression.
        int[] route = {1, 2, 3, 2, 1, 0, 2, 0, 3, 1, 3, 0};
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            Activity source = current(HomeActivity.class);
            Activity originalHome = source;
            int from = 0;
            android.os.ParcelFileDescriptor recording = null;
            try {
            for (int to : route) {
                final Activity previous = source;
                final int targetButton = buttons[to];
                int[] barLocation = new int[2];
                awaitMain(() -> {
                    android.view.View bar = previous.findViewById(R.id.bottomNavigation);
                    androidx.core.view.WindowInsetsCompat insets = androidx.core.view.ViewCompat.getRootWindowInsets(bar);
                    int[] position = new int[2]; bar.getLocationOnScreen(position);
                    // A keyboard from the preceding test may still be closing. This test
                    // measures horizontal tab motion, not the separate IME inset animation.
                    return previous.findViewById(targetButton).isEnabled() && insets != null
                            && !insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.ime())
                            && position[1] + bar.getHeight() == previous.getWindow().getDecorView().getHeight()
                            - insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()).bottom;
                });
                if (recording == null && "true".equals(InstrumentationRegistry.getArguments().getString("recordNavigation"))) {
                    // Start only after the fictional account is visible. Hold that screen
                    // until recording ends so no unrelated app/account is captured.
                    recording = instrumentation.getUiAutomation().executeShellCommand("screenrecord --time-limit 20 "
                            + app.getExternalFilesDir("ui-review-evidence") + "/navigation-motion.mp4");
                }
                int expected = TabMotion.direction(from, to);
                MotionTrace trace = new MotionTrace(screens[to], expected, barLocation);
                Activity destination;
                app.registerActivityLifecycleCallbacks(trace);
                try {
                    instrumentation.runOnMainSync(() -> {
                        previous.findViewById(R.id.bottomNavigation).getLocationOnScreen(barLocation);
                        previous.findViewById(targetButton).performClick();
                    });
                    destination = current(screens[to].asSubclass(Activity.class));
                    assertContentSlidesAboveFixedBar(destination, expected, barLocation, trace);
                } finally {
                    app.unregisterActivityLifecycleCallbacks(trace);
                    instrumentation.runOnMainSync(trace::detach);
                }
                if (to == 0) assertSame("Home reuse must also receive the new transition", originalHome, destination);
                instrumentation.runOnMainSync(() -> assertTrue(destination.findViewById(targetButton).isSelected()));
                source = destination;
                from = to;
            }
            } finally {
            if (recording != null) {
                try (java.io.InputStream result = new android.os.ParcelFileDescriptor.AutoCloseInputStream(recording)) {
                    byte[] buffer = new byte[256];
                    while (result.read(buffer) != -1) { /* Wait for the bounded recording to finish. */ }
                }
            }
            }
        }
    }

    /** Observe the first draw, before waiting for RESUMED/idle can miss a short animation. */
    private static final class MotionTrace implements android.app.Application.ActivityLifecycleCallbacks {
        final Class<?> target;
        final int direction;
        final int[] location;
        volatile boolean moved;
        volatile Throwable failure;
        android.view.View viewport;
        android.view.ViewTreeObserver.OnPreDrawListener listener;
        MotionTrace(Class<?> target, int direction, int[] location) {
            this.target = target; this.direction = direction; this.location = location;
        }
        @Override public void onActivityResumed(Activity activity) {
            if (!target.isInstance(activity) || viewport != null) return;
            viewport = activity.findViewById(R.id.tabContentViewport);
            listener = () -> {
                try {
                    android.view.View page = activity.findViewById(R.id.tabPageContent);
                    android.view.View bar = activity.findViewById(R.id.bottomNavigation);
                    int[] current = new int[2]; bar.getLocationOnScreen(current);
                    assertArrayEquals("Navigation remains fixed even on the first transition frame", location, current);
                    assertEquals(0f, bar.getTranslationX(), 0f);
                    assertEquals(0f, bar.getTranslationY(), 0f);
                    assertTrue(page.getTranslationX() * direction >= 0);
                    if (Math.abs(page.getTranslationX()) > 1f) moved = true;
                } catch (Throwable problem) { failure = problem; }
                return true;
            };
            viewport.getViewTreeObserver().addOnPreDrawListener(listener);
        }
        void detach() {
            if (viewport != null && viewport.getViewTreeObserver().isAlive()) viewport.getViewTreeObserver().removeOnPreDrawListener(listener);
        }
        @Override public void onActivityCreated(Activity a, android.os.Bundle state) { }
        @Override public void onActivityStarted(Activity a) { }
        @Override public void onActivityPaused(Activity a) { }
        @Override public void onActivityStopped(Activity a) { }
        @Override public void onActivitySaveInstanceState(Activity a, android.os.Bundle state) { }
        @Override public void onActivityDestroyed(Activity a) { }
    }

    private void assertContentSlidesAboveFixedBar(Activity activity, int direction, int[] barLocation, MotionTrace trace) throws Exception {
        CountDownLatch sampled = new CountDownLatch(1);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        boolean[] moving = {false};
        instrumentation.runOnMainSync(() -> {
            android.view.View page = activity.findViewById(R.id.tabPageContent);
            android.view.View bar = activity.findViewById(R.id.bottomNavigation);
            android.widget.FrameLayout viewport = activity.findViewById(R.id.tabContentViewport);
            assertEquals(direction, viewport.getTag(R.id.tabMotionDirection));
            android.view.Choreographer.FrameCallback probe = new android.view.Choreographer.FrameCallback() {
                int frames;
                @Override public void doFrame(long time) {
                    try {
                        int[] currentPosition = new int[2];
                        bar.getLocationOnScreen(currentPosition);
                        assertArrayEquals("Navigation must stay at the same screen position", barLocation, currentPosition);
                        assertEquals(0f, bar.getTranslationX(), 0f);
                        assertEquals(0f, bar.getTranslationY(), 0f);
                        assertEquals(1f, bar.getAlpha(), 0f);
                        assertTrue("Incoming page must enter from the selected tab's side", page.getTranslationX() * direction >= 0);
                        if (Math.abs(page.getTranslationX()) > 1f) moving[0] = true;
                        if (viewport.getChildCount() == 2)
                            assertTrue("Outgoing content moves in the opposite direction", viewport.getChildAt(1).getTranslationX() * direction <= 0);
                        if (++frames < 28) android.view.Choreographer.getInstance().postFrameCallback(this);
                        else sampled.countDown();
                    } catch (Throwable problem) { failure.set(problem); sampled.countDown(); }
                }
            };
            android.view.Choreographer.getInstance().postFrameCallback(probe);
        });
        assertTrue("Frame sampling completed", sampled.await(5, TimeUnit.SECONDS));
        if (failure.get() != null) throw new AssertionError(failure.get());
        if (trace.failure != null) throw new AssertionError(trace.failure);
        assertTrue("Observed content movement rather than only a static final screen", moving[0] || trace.moved);
        awaitMain(() -> activity.findViewById(R.id.tabPageContent).getTranslationX() == 0
                && ((android.view.ViewGroup) activity.findViewById(R.id.tabContentViewport)).getChildCount() == 1);
    }

    @Test public void selectedTabIsNoOpAndRecreationDoesNotReplaySlide() {
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class);
            awaitMain(() -> home.findViewById(R.id.navMeButton).isEnabled());
            instrumentation.runOnMainSync(() -> home.findViewById(R.id.navHomeButton).performClick());
            assertSame(home, current(HomeActivity.class));
            instrumentation.runOnMainSync(() -> home.findViewById(R.id.navMeButton).performClick());
            MeActivity me = current(MeActivity.class);
            awaitMain(() -> me.findViewById(R.id.navMeButton).isEnabled());
            instrumentation.runOnMainSync(me::recreate);
            awaitMain(me::isDestroyed);
            MeActivity recreated = current(MeActivity.class);
            assertNotSame(me, recreated);
            instrumentation.runOnMainSync(() -> {
                assertNull(recreated.findViewById(R.id.tabContentViewport).getTag(R.id.tabMotionDirection));
                assertEquals(0f, recreated.findViewById(R.id.tabPageContent).getTranslationX(), 0f);
                assertEquals(1, ((android.view.ViewGroup) recreated.findViewById(R.id.tabContentViewport)).getChildCount());
                recreated.findViewById(R.id.navMeButton).performClick();
            });
            assertSame(recreated, current(MeActivity.class));
        }
    }

    @Test public void rapidTabChangeFinishesOldSlideWithoutLeavingOverlay() {
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class);
            awaitMain(() -> home.findViewById(R.id.navMeButton).isEnabled());
            instrumentation.runOnMainSync(() -> home.findViewById(R.id.navMeButton).performClick());
            MeActivity me = current(MeActivity.class);
            awaitMain(() -> me.findViewById(R.id.navAddEntryButton).isEnabled());
            instrumentation.runOnMainSync(() -> me.findViewById(R.id.navAddEntryButton).performClick());
            WeightEditorActivity editor = current(WeightEditorActivity.class);
            awaitMain(() -> editor.findViewById(R.id.navHistoryButton).isEnabled());
            instrumentation.runOnMainSync(() -> editor.findViewById(R.id.navHistoryButton).performClick());
            HistoryActivity history = current(HistoryActivity.class);
            awaitMain(() -> history.findViewById(R.id.tabPageContent).getTranslationX() == 0
                    && ((android.view.ViewGroup) history.findViewById(R.id.tabContentViewport)).getChildCount() == 1);
            instrumentation.runOnMainSync(() -> {
                assertTrue(history.findViewById(R.id.navHistoryButton).isSelected());
                assertEquals(0f, history.findViewById(R.id.bottomNavigation).getTranslationX(), 0f);
            });
        }
    }

    @Test public void validSignInNavigatesToHome() {
        instrumentation.runOnMainSync(() -> app.session.logout());
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(a -> { put(a, R.id.usernameEditText, "qa@example.com"); put(a, R.id.passwordEditText, "Testpass1"); a.findViewById(R.id.loginButton).performClick(); });
            assertNotNull(current(HomeActivity.class)); assertEquals(user, app.session.userId());
        }
    }
    @Test public void createAccountCompletesOptionalOnboarding() {
        instrumentation.runOnMainSync(() -> app.session.logout());
        AtomicReference<CreateAccountActivity> registration = new AtomicReference<>();
        try (ActivityScenario<CreateAccountActivity> scenario = ActivityScenario.launch(CreateAccountActivity.class)) {
            scenario.onActivity(a -> {
                registration.set(a);
                put(a, R.id.firstNameEditText, "New"); put(a, R.id.lastNameEditText, "Tester");
                put(a, R.id.accountEmailEditText, "new@example.com"); put(a, R.id.accountPhoneEditText, "5551234568");
                put(a, R.id.createPasswordEditText, "Testpass2"); put(a, R.id.confirmPasswordEditText, "Testpass2");
                a.findViewById(R.id.submitCreateAccountButton).performClick();
            });
            FinishProfileActivity profile = current(FinishProfileActivity.class); assertTrue(app.session.userId() > user);
            instrumentation.runOnMainSync(() -> {
                assertEquals(android.view.View.GONE,registration.get().getWindow().getDecorView().findViewWithTag("error:password").getVisibility());
                assertEquals(android.view.View.GONE,registration.get().getWindow().getDecorView().findViewWithTag("error:confirmation").getVisibility());
            });
            awaitMain(() -> profile.findViewById(R.id.profileSaveButton).isEnabled());
            screenshot("finish-profile");
            instrumentation.runOnMainSync(() -> { assertFalse(profile.findViewById(R.id.accountEmailEditText).isEnabled()); assertEquals("new@example.com",text(profile,R.id.accountEmailEditText)); profile.findViewById(R.id.profileSaveButton).performClick(); });
            GoalSetupActivity goals = current(GoalSetupActivity.class); awaitMain(() -> goals.findViewById(R.id.setupFinishButton).isEnabled());
            screenshot("goal-setup");
            instrumentation.runOnMainSync(() -> goals.findViewById(R.id.unitSpinner).performClick()); screenshot("unit-dropdown");
            instrumentation.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);
            instrumentation.runOnMainSync(() -> goals.findViewById(R.id.setupFinishButton).performClick());
            HomeActivity home = current(HomeActivity.class); awaitMain(() -> !new ViewModelProvider(home).get(DashboardViewModel.class).busy());
            assertFalse(app.session.needsSetup()); Snapshot result = app.repository.load(app.session.userId()); assertTrue(result.settings.isOnboardingComplete()); assertEquals(150,result.settings.getGoalWeight(),0); assertTrue(result.records.isEmpty());
            instrumentation.runOnMainSync(() -> assertEquals(android.view.View.GONE,home.findViewById(R.id.targetDateDisplay).getVisibility()));
        }
    }
    @Test public void quickEntrySuccessfulSaveDoesNotShowEmptyError() {
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                put(a,R.id.quickWeightEditText,"0"); a.findViewById(R.id.addWeightButton).performClick();
                assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                put(a,R.id.quickWeightEditText,"176.5");
                assertEquals(android.view.View.GONE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                a.findViewById(R.id.addWeightButton).performClick();
            });
            awaitMain(() -> !vm.busy() && vm.state().getValue().data.records.size() == 1);
            scenario.onActivity(a -> {
                assertEquals("",text(a,R.id.quickWeightEditText));
                assertEquals(android.view.View.GONE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                // A new, genuinely empty submission must still validate after the reset.
                a.findViewById(R.id.addWeightButton).performClick();
                assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                put(a,R.id.quickWeightEditText,"175"); a.findViewById(R.id.addWeightButton).performClick();
            });
            awaitMain(() -> !vm.busy() && vm.state().getValue().error != null);
            assertEquals(AppFailure.Kind.DUPLICATE_DATE,vm.state().getValue().error.kind);
            scenario.onActivity(a -> {
                assertEquals("175",text(a,R.id.quickWeightEditText));
                assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                assertTrue(((android.widget.TextView)a.getWindow().getDecorView().findViewWithTag("error:weight")).getText().toString().contains("History"));
            });
            screenshot("review-duplicate-inline");
            assertEquals(1,app.repository.load(user).records.size());
        }
    }
    @Test public void kilogramQuickEntryResetsWithoutFalseError() throws Exception {
        app.worker.submit(() -> app.repository.updateProfile(user,"Noel","Tester","5551234567","kg")).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> { put(a,R.id.quickWeightEditText,"80"); a.findViewById(R.id.addWeightButton).performClick(); });
            awaitMain(() -> !vm.busy() && vm.state().getValue().data.records.size() == 1);
            scenario.onActivity(a -> {
                assertEquals("",text(a,R.id.quickWeightEditText));
                assertEquals(android.view.View.GONE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                assertEquals("80 kg",((android.widget.TextView)a.findViewById(R.id.currentWeightTextView)).getText().toString());
            });
            assertEquals(WeightUnits.KG.toPounds(80),app.repository.load(user).records.get(0).getWeight(),0.000001);
        }
    }
    @Test public void clearingInvalidQuickWeightDismissesRangeErrorButSubmitStillRequiresInput() {
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                put(a,R.id.quickWeightEditText,"701"); a.findViewById(R.id.addWeightButton).performClick();
                android.widget.TextView error = a.getWindow().getDecorView().findViewWithTag("error:weight");
                assertTrue(error.getText().toString().contains("700 lbs")); assertEquals(android.view.View.VISIBLE,error.getVisibility());
                put(a,R.id.quickWeightEditText,""); assertEquals(android.view.View.GONE,error.getVisibility());
                a.findViewById(R.id.addWeightButton).performClick();
                assertEquals("Enter a weight to continue",error.getText().toString());
                put(a,R.id.quickWeightEditText,"175"); assertEquals(android.view.View.GONE,error.getVisibility());
                assertTrue(vm.state().getValue().data.records.isEmpty());
                assertEquals(a.getResources().getFont(R.font.inter_semibold),((android.widget.TextView)a.findViewById(R.id.quickEntryHeading)).getTypeface());
            }); screenshot("review-quick-entry-heading");
        }
    }
    @Test public void kilogramRangeClearsAndAcceptsDisplayedUpperBoundary() throws Exception {
        app.worker.submit(() -> app.repository.updateProfile(user,"Noel","Tester","5551234567","kg")).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                put(a,R.id.quickWeightEditText,"318"); a.findViewById(R.id.addWeightButton).performClick();
                android.widget.TextView error = a.getWindow().getDecorView().findViewWithTag("error:weight");
                assertTrue(error.getText().toString().contains("317.5 kg"));
                put(a,R.id.quickWeightEditText,""); assertEquals(android.view.View.GONE,error.getVisibility());
                put(a,R.id.quickWeightEditText,"317.5"); a.findViewById(R.id.addWeightButton).performClick();
            });
            awaitMain(() -> !vm.busy() && vm.state().getValue().data.records.size()==1);
            assertEquals(WeightUnits.KG.toPounds(317.5),app.repository.load(user).records.get(0).getWeight(),0.000001);
        }
    }
    @Test public void duplicateDatedEntryHasInlineDateErrorWithoutReplacingExistingWeight() throws Exception {
        String date = java.time.LocalDate.now().toString();
        app.worker.submit(() -> app.repository.save(user,new WeightInput(-1,date,180,"original",null))).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<WeightEditorActivity> scenario = ActivityScenario.launch(editorIntent(-1))) {
            WeightEditorActivity editor = current(WeightEditorActivity.class); WeightEditorViewModel vm = editorModel(editor);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> { put(a,R.id.weightEditText,"175"); put(a,R.id.dateEditText,date); a.findViewById(R.id.saveWeightButton).performClick(); });
            awaitMain(() -> !vm.busy() && vm.state().getValue().error != null);
            scenario.onActivity(a -> {
                assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:date").getVisibility());
                assertEquals("175",text(a,R.id.weightEditText));
            }); screenshot("review-duplicate-date");
            assertEquals(1,app.repository.load(user).records.size()); assertEquals(180,app.repository.load(user).records.get(0).getWeight(),0);
        }
    }
    @Test public void sharedDropdownShowsSelectionAndCleanApplicationLabel() {
        assertEquals("Weight Progress",app.getApplicationInfo().loadLabel(app.getPackageManager()).toString());
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                assertTrue(a.findViewById(R.id.trendWindowSpinner) instanceof ChoiceSpinner);
                android.widget.Spinner choice = a.findViewById(R.id.trendWindowSpinner);
                android.widget.CheckedTextView selected = (android.widget.CheckedTextView)choice.getAdapter().getDropDownView(1,null,new android.widget.LinearLayout(a));
                assertTrue(selected.isChecked()); assertEquals("7 entries",selected.getText().toString());
                android.widget.CheckedTextView other = (android.widget.CheckedTextView)choice.getAdapter().getDropDownView(0,null,new android.widget.LinearLayout(a));
                assertFalse(other.isChecked());
                scrollToTrends(a);
            });
            scenario.onActivity(a -> a.findViewById(R.id.trendWindowSpinner).performClick()); screenshot("review-trends-dropdown");
            // Exercise the native menu's keyboard selection, not just setSelection().
            // The first Down may only exit touch mode; walk to the final option explicitly.
            for (int i=0;i<3;i++) instrumentation.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_DPAD_DOWN);
            instrumentation.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_ENTER);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> assertEquals("Native keyboard choice",14,vm.windowSize()));
        }
        try (ActivityScenario<ProfileActivity> scenario = ActivityScenario.launch(ProfileActivity.class)) {
            ProfileActivity profile = current(ProfileActivity.class); awaitMain(() -> profile.findViewById(R.id.profileSaveButton).isEnabled());
            scenario.onActivity(a -> {
                assertTrue(a.findViewById(R.id.unitSpinner) instanceof ChoiceSpinner);
                android.view.ViewParent parent = a.findViewById(R.id.unitSpinner).getParent();
                while (!(parent instanceof android.widget.ScrollView)) parent = parent.getParent();
                ((android.widget.ScrollView)parent).fullScroll(android.view.View.FOCUS_DOWN);
            });
            instrumentation.waitForIdleSync();
            scenario.onActivity(a -> a.findViewById(R.id.unitSpinner).performClick()); screenshot("review-account-dropdown");
            instrumentation.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);
        }
    }
    @Test public void deletionPasswordUsesAppFontAndRemainsMasked() {
        try (ActivityScenario<MeActivity> scenario = ActivityScenario.launch(MeActivity.class)) {
            MeActivity me = current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            scenario.onActivity(a -> a.findViewById(R.id.deleteAccountButton).performClick());
            instrumentation.runOnMainSync(() -> {
                EditText password = null;
                for (android.view.View root : android.view.inspector.WindowInspector.getGlobalWindowViews()) {
                    EditText candidate = root.findViewById(R.id.currentPasswordInput);
                    if (candidate != null && candidate.isShown()) password = candidate;
                }
                assertNotNull(password); assertEquals(app.getResources().getFont(R.font.inter_regular),password.getTypeface());
                assertTrue(password.getTransformationMethod() instanceof android.text.method.PasswordTransformationMethod);
                assertFalse(password.isSaveEnabled());
            }); screenshot("review-password-font");
            instrumentation.runOnMainSync(() -> dialogLabel("Keep account").performClick());
            assertEquals(user,app.repository.signIn("qa@example.com","Testpass1"));
        }
    }
    @Test public void accountRowsWrapAtLargeTextAndUseDistinctLabelStyle() {
        try (ActivityScenario<MeActivity> scenario = ActivityScenario.launch(MeActivity.class)) {
            MeActivity me = current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            scenario.onActivity(a -> {
                android.widget.TextView label = a.findViewById(R.id.accountDetails).findViewWithTag("account:email:label");
                android.widget.TextView value = a.findViewById(R.id.accountDetails).findViewWithTag("account:email:value");
                assertNotEquals(label.getCurrentTextColor(),value.getCurrentTextColor()); assertTrue(label.getTextSize() < value.getTextSize());
                android.content.res.Configuration config = new android.content.res.Configuration(a.getResources().getConfiguration());
                config.fontScale = 1.5f; config.screenWidthDp = 320;
                AccountDetailsView large = new AccountDetailsView(a.createConfigurationContext(config));
                large.show(new com.example.weighttracker.model.AccountProfile(user,"A Long First Name","A Long Last Name","long.email.for.review@example.com",new com.example.weighttracker.model.UserSettings(user,150,"5551234567",false,false)));
                assertEquals(android.widget.LinearLayout.VERTICAL,((android.widget.LinearLayout)large.getChildAt(0)).getOrientation());
                large.measure(android.view.View.MeasureSpec.makeMeasureSpec(Math.round(270*a.getResources().getDisplayMetrics().density),android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(0,android.view.View.MeasureSpec.UNSPECIFIED));
                android.widget.TextView email = large.findViewWithTag("account:email:value"); assertTrue(email.getLineCount() > 1);
            }); screenshot("review-me-labels");
        }
    }
    @Test public void deletingRecentEntryKeepsUnsubmittedQuickEntry() throws Exception {
        long id = seed();
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> { put(a,R.id.quickWeightEditText,"175"); vm.delete(id); });
            awaitMain(() -> !vm.busy() && vm.state().getValue().data.records.isEmpty());
            scenario.onActivity(a -> {
                assertEquals("175",text(a,R.id.quickWeightEditText));
                assertEquals(android.view.View.GONE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
            });
        }
    }
    @Test public void homeShowsThreeNewestEntriesCountdownAndHistoryHasAllBorderedCells() throws Exception {
        java.time.LocalDate today = java.time.LocalDate.now();
        app.worker.submit(() -> {
            // Insert out of order so the test proves chronological ordering, not insertion order.
            for (int days : new int[]{3,1,4,2}) app.repository.save(user,new WeightInput(-1,today.minusDays(days).toString(),175+days,"synthetic",null));
            app.repository.updateGoals(user,150,today.plusDays(11).toString());
        }).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); awaitMain(() -> !new ViewModelProvider(home).get(DashboardViewModel.class).busy());
            scenario.onActivity(a -> {
                android.widget.LinearLayout recent = a.findViewById(R.id.recentHistoryContainer); assertEquals(3,recent.getChildCount());
                for (int i = 0; i < 3; i++) {
                    android.widget.TextView label = (android.widget.TextView)((android.view.ViewGroup)recent.getChildAt(i)).getChildAt(0);
                    assertTrue(label.getText().toString().startsWith(com.example.weighttracker.util.DateUtils.formatForDisplay(today.minusDays(i+1).toString())));
                }
                assertEquals("176 lbs",((android.widget.TextView)a.findViewById(R.id.currentWeightTextView)).getText().toString());
                assertEquals("150 lbs",((android.widget.TextView)a.findViewById(R.id.goalWeightTextView)).getText().toString());
                assertEquals(TargetDateDisplay.label(today.plusDays(11).toString(),today),((android.widget.TextView)a.findViewById(R.id.targetDateDisplay)).getText().toString());
                assertEquals(android.view.View.VISIBLE,a.findViewById(R.id.targetDateDisplay).getVisibility());
            }); screenshot("home-three-entries-countdown");
            scenario.onActivity(a -> {
                android.view.View view = a.findViewById(R.id.recentHistoryContainer);
                while (!(view instanceof android.widget.ScrollView)) view = (android.view.View)view.getParent();
                ((android.widget.ScrollView)view).fullScroll(android.view.View.FOCUS_DOWN);
            }); screenshot("home-recent-three");
            scenario.onActivity(a -> a.findViewById(R.id.navHistoryButton).performClick());
            HistoryActivity history = current(HistoryActivity.class); awaitMain(() -> !new ViewModelProvider(history).get(DashboardViewModel.class).busy());
            instrumentation.runOnMainSync(() -> {
                android.widget.TableLayout table = history.findViewById(R.id.weightHistoryTable); assertEquals(5,table.getChildCount());
                for (int i = 1; i < table.getChildCount(); i++) {
                    android.view.ViewGroup row = (android.view.ViewGroup)table.getChildAt(i); assertEquals(5,row.getChildCount());
                    for (int column = 0; column < 5; column++) {
                        assertTrue(row.getChildAt(column).getBackground() instanceof android.graphics.drawable.GradientDrawable);
                        assertEquals(row.getChildAt(0).getHeight(),row.getChildAt(column).getHeight());
                    }
                }
            }); screenshot("history-dividers");
        }
    }
    @Test public void passwordIsNotRestoredOnRecreation() {
        instrumentation.runOnMainSync(() -> app.session.logout());
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(a -> put(a, R.id.passwordEditText, "DoNotPersist1"));
            scenario.recreate();
            scenario.onActivity(a -> { assertEquals("", text(a, R.id.passwordEditText)); assertFalse(a.findViewById(R.id.passwordEditText).isSaveEnabled()); });
            screenshot("login");
        }
    }
    @Test public void editorRetainsUnsavedFieldsOnRecreation() throws Exception {
        try (ActivityScenario<WeightEditorActivity> scenario = ActivityScenario.launch(editorIntent(seed()))) {
            WeightEditorActivity activity = current(WeightEditorActivity.class);
            awaitMain(() -> !editorModel(activity).busy());
            scenario.onActivity(a -> { assertEquals("181.26", text(a, R.id.weightEditText)); put(a, R.id.notesEditText, "unsaved after rotation"); });
            scenario.recreate();
            scenario.onActivity(a -> { assertEquals("181.26", text(a, R.id.weightEditText)); assertEquals("unsaved after rotation", text(a, R.id.notesEditText)); });
            screenshot("editor-restored");
        }
    }
    @Test public void invalidInputShowsFieldErrorAndDoesNotSave() {
        try (ActivityScenario<WeightEditorActivity> scenario = ActivityScenario.launch(editorIntent(-1))) {
            WeightEditorActivity activity = current(WeightEditorActivity.class); awaitMain(() -> !editorModel(activity).busy());
            scenario.onActivity(a -> {
                put(a, R.id.weightEditText, "0"); a.findViewById(R.id.saveWeightButton).performClick();
                assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:weight").getVisibility());
                assertFalse(editorModel(a).busy());
            });
            assertTrue(app.repository.load(user).records.isEmpty());
            screenshot("invalid-weight");
        }
    }
    @Test public void savingEntryReachesHistoryWithoutChangingGoal() {
        try (ActivityScenario<WeightEditorActivity> scenario = ActivityScenario.launch(editorIntent(-1))) {
            WeightEditorActivity activity = current(WeightEditorActivity.class); awaitMain(() -> !editorModel(activity).busy());
            scenario.onActivity(a -> {
                put(a, R.id.weightEditText, "181.26"); put(a, R.id.notesEditText, "synthetic save");
                a.findViewById(R.id.saveWeightButton).performClick();
            });
            assertNotNull(current(HistoryActivity.class));
            HistoryActivity history = current(HistoryActivity.class);
            awaitMain(() -> !new ViewModelProvider(history).get(DashboardViewModel.class).busy());
            screenshot("history-after-save");
            Snapshot saved = app.repository.load(user); assertEquals(181.26, saved.records.get(0).getWeight(), 0); assertEquals(150, saved.settings.getGoalWeight(), 0);
        }
    }
    @Test public void rotatingDuringSaveDoesNotRepeatWrite() throws Exception {
        CountDownLatch release = new CountDownLatch(1);
        try (ActivityScenario<WeightEditorActivity> scenario = ActivityScenario.launch(editorIntent(-1))) {
            WeightEditorActivity activity = current(WeightEditorActivity.class); awaitMain(() -> !editorModel(activity).busy());
            app.worker.execute(() -> { try { release.await(10, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } });
            scenario.onActivity(a -> {
                put(a, R.id.weightEditText, "182.5"); a.findViewById(R.id.saveWeightButton).performClick();
                assertFalse(a.findViewById(R.id.saveWeightButton).isEnabled());
            });
            scenario.recreate();
            scenario.onActivity(a -> { assertTrue(editorModel(a).busy()); assertEquals("182.5", text(a, R.id.weightEditText)); });
            release.countDown(); assertNotNull(current(HistoryActivity.class));
            assertEquals(1, app.repository.load(user).records.size());
        } finally { release.countDown(); }
    }
    @Test public void clearingSessionPreventsAccessToProtectedScreen() {
        instrumentation.runOnMainSync(() -> app.session.logout());
        Intent intent = new Intent(app, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        app.startActivity(intent);
        assertNotNull(current(MainActivity.class)); assertEquals(-1, app.session.userId());
    }
    @Test public void homeNavigationOpensHistoryAndEditor() throws Exception {
        seed();
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class);
            awaitMain(() -> !new ViewModelProvider(home).get(DashboardViewModel.class).busy());
            screenshot("home");
            scenario.onActivity(a -> a.findViewById(R.id.historyButton).performClick());
            HistoryActivity history = current(HistoryActivity.class);
            awaitMain(() -> !new ViewModelProvider(history).get(DashboardViewModel.class).busy());
            instrumentation.runOnMainSync(() -> history.findViewById(R.id.addFromHistoryButton).performClick());
            assertNotNull(current(WeightEditorActivity.class));
        }
    }
    @Test public void decliningSmsKeepsTrackingAvailable() {
        try (ActivityScenario<SmsSettingsActivity> scenario = ActivityScenario.launch(SmsSettingsActivity.class)) {
            SmsSettingsActivity settings = current(SmsSettingsActivity.class);
            awaitMain(() -> !new ViewModelProvider(settings).get(SmsViewModel.class).busy());
            scenario.onActivity(a -> {
                assertFalse(((android.widget.Switch)a.findViewById(R.id.smsToggle)).isChecked());
                assertNull(a.findViewById(R.id.declinePermissionButton));
                assertNull(a.findViewById(R.id.requestPermissionButton));
                assertEquals("5551234567",((android.widget.TextView)a.findViewById(R.id.smsRecipient)).getText().toString());
            });
            awaitMain(() -> !new ViewModelProvider(settings).get(SmsViewModel.class).busy());
            assertFalse(app.repository.load(user).settings.isSmsEnabled());
            screenshot("sms-disabled");
            scenario.onActivity(a -> a.findViewById(R.id.navHomeButton).performClick());
            assertNotNull(current(HomeActivity.class));
        }
    }
    @Test public void emptyLoginFieldsValidateOnBlurAndConfirmationUpdatesLive() {
        instrumentation.runOnMainSync(() -> app.session.logout());
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(a -> {
                assertEquals(android.view.View.GONE,a.getWindow().getDecorView().findViewWithTag("error:email").getVisibility());
                a.findViewById(R.id.usernameEditText).requestFocus(); a.findViewById(R.id.passwordEditText).requestFocus();
                assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:email").getVisibility());
            }); screenshot("login-inline-error");
        }
        try (ActivityScenario<CreateAccountActivity> scenario = ActivityScenario.launch(CreateAccountActivity.class)) {
            scenario.onActivity(a -> {
                put(a,R.id.createPasswordEditText,"Testpass1"); a.findViewById(R.id.confirmPasswordEditText).requestFocus();
                android.widget.TextView error = a.getWindow().getDecorView().findViewWithTag("error:confirmation");
                assertEquals("Password doesn’t match",error.getText().toString()); put(a,R.id.confirmPasswordEditText,"Testpass1"); assertEquals(android.view.View.GONE,error.getVisibility());
                put(a,R.id.createPasswordEditText,"Testpass2"); assertEquals(android.view.View.VISIBLE,error.getVisibility());
                put(a,R.id.confirmPasswordEditText,"Testpass2"); assertEquals(android.view.View.GONE,error.getVisibility());
                assertEquals(android.view.View.GONE,a.getWindow().getDecorView().findViewWithTag("error:password").getVisibility());
                put(a,R.id.confirmPasswordEditText,"Different1");
            }); screenshot("registration-inline-errors");
        }
    }
    @Test public void accountUnitsApplyToHomeHistoryAndEditorAndEmailStaysLocked() throws Exception {
        seed();
        try (ActivityScenario<MeActivity> scenario = ActivityScenario.launch(MeActivity.class)) {
            MeActivity me = current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy()); screenshot("me");
            scenario.onActivity(a -> {
                assertTrue(a.findViewById(R.id.navMeButton).isSelected());
                String[] keys = {"first","last","email","phone"}, values = {"Noel","Tester","qa@example.com","5551234567"};
                for (int i=0;i<keys.length;i++) assertEquals(values[i],((android.widget.TextView)a.findViewById(R.id.accountDetails).findViewWithTag("account:"+keys[i]+":value")).getText().toString());
                android.view.View edit = a.findViewById(R.id.editAccountButton);
                assertTrue(edit.getLeft() > 0); assertTrue(edit.getWidth() < ((android.view.View)edit.getParent()).getWidth()/2);
                edit.performClick();
            });
            ProfileActivity profile = current(ProfileActivity.class); awaitMain(() -> profile.findViewById(R.id.profileSaveButton).isEnabled());
            instrumentation.runOnMainSync(() -> { assertFalse(profile.findViewById(R.id.accountEmailEditText).isEnabled()); ((android.widget.Spinner)profile.findViewById(R.id.unitSpinner)).setSelection(1); put(profile,R.id.firstNameEditText,"Noel Updated"); });
            screenshot("edit-account"); instrumentation.runOnMainSync(() -> profile.findViewById(R.id.profileSaveButton).performClick());
            current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            assertEquals("kg",app.repository.load(user).settings.getUnit()); assertEquals(181.26,app.repository.load(user).records.get(0).getWeight(),0);
            instrumentation.runOnMainSync(() -> me.findViewById(R.id.navHomeButton).performClick());
            HomeActivity home = current(HomeActivity.class); awaitMain(() -> !new ViewModelProvider(home).get(DashboardViewModel.class).busy());
            instrumentation.runOnMainSync(() -> { assertEquals("82.2 kg",((android.widget.TextView)home.findViewById(R.id.currentWeightTextView)).getText().toString()); home.findViewById(R.id.navHistoryButton).performClick(); });
            HistoryActivity history = current(HistoryActivity.class); awaitMain(() -> !new ViewModelProvider(history).get(DashboardViewModel.class).busy()); screenshot("history-kg");
            instrumentation.runOnMainSync(() -> { assertTrue(history.findViewById(R.id.navHistoryButton).isSelected()); history.findViewById(R.id.navAddEntryButton).performClick(); });
            WeightEditorActivity editor = current(WeightEditorActivity.class); awaitMain(() -> !editorModel(editor).busy());
            instrumentation.runOnMainSync(() -> { assertEquals(WeightUnits.KG,editorModel(editor).unit()); assertTrue(editor.findViewById(R.id.navAddEntryButton).isSelected()); }); screenshot("add-entry-kg");
        }
    }
    @Test public void completedAccountDoesNotRepeatOnboardingAfterLogout() {
        try (ActivityScenario<MeActivity> scenario = ActivityScenario.launch(MeActivity.class)) {
            MeActivity me = current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            scenario.onActivity(a -> a.findViewById(R.id.logoutButton).performClick());
            MainActivity login = current(MainActivity.class); assertEquals(-1,app.session.userId());
            instrumentation.runOnMainSync(() -> { put(login,R.id.usernameEditText,"qa@example.com"); put(login,R.id.passwordEditText,"Testpass1"); login.findViewById(R.id.loginButton).performClick(); });
            assertNotNull(current(HomeActivity.class)); assertFalse(app.session.needsSetup());
        }
    }
    @Test public void profileCancelDoesNotChangePreferencesAndRotationKeepsDraft() {
        try (ActivityScenario<ProfileActivity> scenario = ActivityScenario.launch(ProfileActivity.class)) {
            ProfileActivity profile = current(ProfileActivity.class); awaitMain(() -> profile.findViewById(R.id.profileSaveButton).isEnabled());
            scenario.onActivity(a -> { put(a,R.id.firstNameEditText,"Unsaved"); ((android.widget.Spinner)a.findViewById(R.id.unitSpinner)).setSelection(1); }); scenario.recreate();
            scenario.onActivity(a -> { assertEquals("Unsaved",text(a,R.id.firstNameEditText)); assertFalse(a.findViewById(R.id.accountEmailEditText).isEnabled()); a.findViewById(R.id.profileCancelButton).performClick(); });
            assertEquals("Noel",app.repository.profile(user).first); assertEquals("lbs",app.repository.profile(user).settings.getUnit());
        }
    }
    @Test public void passwordFormRejectsWrongCurrentPasswordAndSavesNewPassword() {
        try (ActivityScenario<ChangePasswordActivity> scenario = ActivityScenario.launch(ChangePasswordActivity.class)) {
            ChangePasswordActivity screen = current(ChangePasswordActivity.class);
            scenario.onActivity(a -> {
                for (int id : new int[]{R.id.currentPasswordInput,R.id.newPasswordInput,R.id.newPasswordConfirmation}) {
                    EditText input = a.findViewById(id); assertTrue(input.getTransformationMethod() instanceof android.text.method.PasswordTransformationMethod); assertFalse(input.isSaveEnabled());
                }
                put(a,R.id.currentPasswordInput,"wrong"); put(a,R.id.newPasswordInput,"Changedpass1"); put(a,R.id.newPasswordConfirmation,"Changedpass1"); a.findViewById(R.id.passwordSaveButton).performClick();
            });
            awaitMain(() -> !new ViewModelProvider(screen).get(AccountViewModel.class).busy());
            scenario.onActivity(a -> { assertEquals(android.view.View.VISIBLE,a.getWindow().getDecorView().findViewWithTag("error:currentPassword").getVisibility()); put(a,R.id.currentPasswordInput,"Testpass1"); }); screenshot("change-password");
            AccountViewModel model = new ViewModelProvider(screen).get(AccountViewModel.class);
            scenario.onActivity(a -> a.findViewById(R.id.passwordSaveButton).performClick()); awaitMain(() -> !model.busy());
            MeActivity me = current(MeActivity.class);
            instrumentation.runOnMainSync(() -> assertTrue(me.findViewById(R.id.navMeButton).isSelected()));
            assertEquals(user,app.repository.signIn("qa@example.com","Changedpass1")); assertThrows(AppFailure.class,() -> app.repository.signIn("qa@example.com","Testpass1"));
        }
    }
    @Test public void deletingSyntheticAccountWarnsThenReturnsToLogin() {
        try (ActivityScenario<MeActivity> scenario = ActivityScenario.launch(MeActivity.class)) {
            MeActivity me = current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            scenario.onActivity(a -> { a.findViewById(R.id.deleteAccountButton).performClick(); assertNotNull(dialogLabel("Permanently delete your account?")); }); screenshot("delete-warning");
            instrumentation.runOnMainSync(() -> dialogLabel("Keep account").performClick()); assertTrue(helper.userExists(user));
            scenario.onActivity(a -> a.findViewById(R.id.deleteAccountButton).performClick());
            instrumentation.runOnMainSync(() -> {
                for (android.view.View root : android.view.inspector.WindowInspector.getGlobalWindowViews()) {
                    android.view.View field = root.findViewById(R.id.currentPasswordInput); if (field instanceof EditText && field.isShown()) ((EditText)field).setText("Testpass1");
                }
                dialogLabel("Delete permanently").performClick();
            });
            assertNotNull(current(MainActivity.class)); assertEquals(-1,app.session.userId()); assertFalse(helper.userExists(user));
        }
    }
    @Test public void goalsSaveAndCancelAreDistinct() {
        try (ActivityScenario<GoalFormActivity> scenario = ActivityScenario.launch(GoalFormActivity.class)) {
            GoalFormActivity goals = current(GoalFormActivity.class); awaitMain(() -> goals.findViewById(R.id.setupFinishButton).isEnabled());
            scenario.onActivity(a -> { put(a,R.id.goalInput,"140"); put(a,R.id.targetDateInput,"2027-01-01"); a.findViewById(R.id.setupBackButton).performClick(); });
            assertEquals(150,app.repository.load(user).settings.getGoalWeight(),0); assertEquals("",app.repository.load(user).settings.getTargetDate());
        }
        try (ActivityScenario<GoalFormActivity> scenario = ActivityScenario.launch(GoalFormActivity.class)) {
            GoalFormActivity goals = current(GoalFormActivity.class); awaitMain(() -> goals.findViewById(R.id.setupFinishButton).isEnabled());
            scenario.onActivity(a -> { put(a,R.id.goalInput,"140"); put(a,R.id.targetDateInput,"2027-01-01"); }); screenshot("update-goals");
            scenario.onActivity(a -> a.findViewById(R.id.setupFinishButton).performClick());
            awaitMain(() -> !new ViewModelProvider(goals).get(AccountViewModel.class).busy());
            assertEquals(140,app.repository.load(user).settings.getGoalWeight(),0); assertEquals("2027-01-01",app.repository.load(user).settings.getTargetDate());
        }
    }
    @Test public void meSubpagesHaveBackAndPasswordShortcutIsBelowEmail() {
        try (ActivityScenario<MeActivity> scenario = ActivityScenario.launch(MeActivity.class)) {
            MeActivity me = current(MeActivity.class); awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            scenario.onActivity(a -> a.findViewById(R.id.editAccountButton).performClick());
            ProfileActivity profile = current(ProfileActivity.class); awaitMain(() -> profile.findViewById(R.id.profileSaveButton).isEnabled());
            instrumentation.runOnMainSync(() -> {
                android.view.View email = profile.findViewById(R.id.accountEmailEditText), password = profile.findViewById(R.id.passwordButton);
                assertTrue(password.getTop() >= email.getBottom());
                android.widget.Spinner units = profile.findViewById(R.id.unitSpinner);
                assertTrue(units.getWidth() < ((android.view.View)units.getParent()).getWidth());
                assertFalse(units.getSelectedItem().toString().contains("▾"));
            }); screenshot("edit-account-shortcut");
            instrumentation.runOnMainSync(() -> profile.findViewById(R.id.pageBackButton).performClick()); current(MeActivity.class);
            awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            instrumentation.runOnMainSync(() -> me.findViewById(R.id.openSmsButton).performClick());
            SmsSettingsActivity sms = current(SmsSettingsActivity.class); awaitMain(() -> !new ViewModelProvider(sms).get(SmsViewModel.class).busy());
            instrumentation.runOnMainSync(() -> sms.findViewById(R.id.pageBackButton).performClick()); current(MeActivity.class);
            awaitMain(() -> !new ViewModelProvider(me).get(AccountViewModel.class).busy());
            instrumentation.runOnMainSync(() -> me.findViewById(R.id.updateGoalsButton).performClick());
            GoalFormActivity goals = current(GoalFormActivity.class); awaitMain(() -> goals.findViewById(R.id.setupFinishButton).isEnabled());
            instrumentation.runOnMainSync(() -> { put(goals,R.id.goalInput,"123"); goals.findViewById(R.id.pageBackButton).performClick(); });
            assertNotNull(current(MeActivity.class)); assertEquals(150,app.repository.load(user).settings.getGoalWeight(),0);
        }
    }
    @Test public void smsSwitchPersistsBothStatesWithoutRealMessages() {
        // Do not change the user's device permission. This test requires it to be granted already.
        Assume.assumeTrue(com.example.weighttracker.util.SmsNotifier.canSend(app));
        try (ActivityScenario<SmsSettingsActivity> scenario = ActivityScenario.launch(SmsSettingsActivity.class)) {
            SmsSettingsActivity screen = current(SmsSettingsActivity.class); SmsViewModel model = new ViewModelProvider(screen).get(SmsViewModel.class);
            awaitMain(() -> !model.busy() && screen.findViewById(R.id.smsToggle).isEnabled());
            scenario.onActivity(a -> a.findViewById(R.id.smsToggle).performClick());
            awaitMain(() -> !model.busy() && model.state().getValue().data.settings.isSmsEnabled());
            assertTrue(app.repository.load(user).settings.isSmsEnabled()); screenshot("sms-toggle-on");
            scenario.recreate(); SmsSettingsActivity recreated = current(SmsSettingsActivity.class);
            awaitMain(() -> !new ViewModelProvider(recreated).get(SmsViewModel.class).busy());
            scenario.onActivity(a -> { assertTrue(((android.widget.Switch)a.findViewById(R.id.smsToggle)).isChecked()); a.findViewById(R.id.smsToggle).performClick(); });
            awaitMain(() -> !new ViewModelProvider(recreated).get(SmsViewModel.class).busy());
            assertFalse(app.repository.load(user).settings.isSmsEnabled());
            scenario.onActivity(a -> assertFalse(((android.widget.Switch)a.findViewById(R.id.smsToggle)).isChecked())); screenshot("sms-toggle-off");
        }
    }
    @Test public void weightDeletionDialogKeepsThenDeletesOnlySelectedEntry() throws Exception {
        long id = seed();
        try (ActivityScenario<HistoryActivity> scenario = ActivityScenario.launch(HistoryActivity.class)) {
            HistoryActivity history = current(HistoryActivity.class); DashboardViewModel vm = new ViewModelProvider(history).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> a.getWindow().getDecorView().findViewWithTag("history:delete:"+id).performClick()); screenshot("delete-entry-dialog");
            instrumentation.runOnMainSync(() -> dialogLabel("Keep entry").performClick()); assertEquals(1,app.repository.load(user).records.size());
            scenario.onActivity(a -> a.getWindow().getDecorView().findViewWithTag("history:delete:"+id).performClick());
            instrumentation.runOnMainSync(() -> dialogLabel("Delete entry").performClick());
            awaitMain(() -> !vm.busy() && vm.state().getValue().data.records.isEmpty()); assertTrue(app.repository.load(user).records.isEmpty());
        }
    }
    @Test public void backdatedRecordsRecalculateProgressUsingNewestDatedWeight() throws Exception {
        java.time.LocalDate today = java.time.LocalDate.now();
        app.worker.submit(() -> {
            app.repository.updateProfile(user,"Noel","Tester","5551234567","kg");
            app.repository.updateGoals(user,WeightUnits.KG.toPounds(68),"");
            app.repository.save(user,new WeightInput(-1,today.minusDays(1).toString(),WeightUnits.KG.toPounds(76),"newest",null));
        }).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<HomeActivity> scenario = ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home = current(HomeActivity.class); DashboardViewModel vm = new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> assertEquals("0%",((android.widget.TextView)a.findViewById(R.id.progressPercentTextView)).getText().toString()));
            app.worker.submit(() -> {
                app.repository.save(user,new WeightInput(-1,today.minusDays(4).toString(),WeightUnits.KG.toPounds(90),"starting",null));
                app.repository.save(user,new WeightInput(-1,today.minusDays(2).toString(),WeightUnits.KG.toPounds(75),"backdated after newest",null));
            }).get(10,TimeUnit.SECONDS);
            scenario.onActivity(a -> vm.refresh()); awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                assertEquals("76 kg",((android.widget.TextView)a.findViewById(R.id.currentWeightTextView)).getText().toString());
                assertEquals("64%",((android.widget.TextView)a.findViewById(R.id.progressPercentTextView)).getText().toString());
            }); screenshot("home-kg-progress");
            long newestId = app.repository.load(user).records.get(0).getId();
            scenario.onActivity(a -> vm.delete(newestId)); awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                assertEquals("75 kg",((android.widget.TextView)a.findViewById(R.id.currentWeightTextView)).getText().toString());
                assertEquals("68%",((android.widget.TextView)a.findViewById(R.id.progressPercentTextView)).getText().toString());
            });
        }
    }
    private String label(Activity activity,int id) {
        return ((android.widget.TextView)activity.findViewById(id)).getText().toString();
    }
    private void scrollToTrends(HomeActivity activity) {
        android.view.View child = activity.findViewById(R.id.trendsCard);
        android.view.ViewParent parent = child.getParent();
        while (!(parent instanceof android.widget.ScrollView)) parent = parent.getParent();
        ((android.widget.ScrollView)parent).scrollTo(0,child.getTop());
    }
    @Test public void analyticsWindowUnitsRotationAndAccountIsolation() throws Exception {
        java.time.LocalDate today=java.time.LocalDate.now();
        app.worker.submit(() -> {
            // Deliberately insert the newest first to verify chronology, not insertion order.
            for (int day=12;day>=0;day-=2) app.repository.save(user,new WeightInput(-1,today.minusDays(14-day).toString(),180-day,"trend demo",null));
            app.repository.updateGoals(user,150,today.plusDays(60).toString());
            long other=app.repository.register("Other","Tester","other@example.com","5551234569","Testpass1");
            app.repository.save(other,new WeightInput(-1,today.toString(),700,"Must not appear in first account",null));
        }).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<HomeActivity> scenario=ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home=current(HomeActivity.class);
            DashboardViewModel vm=new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy() && vm.state().getValue().data != null);
            scenario.onActivity(a -> {
                assertEquals("174 lbs",label(a,R.id.trendAverage));
                assertEquals("-1.00 lbs/day",label(a,R.id.trendRate));
                assertTrue(label(a,R.id.trendProjection).endsWith(com.example.weighttracker.util.DateUtils.formatForDisplay(today.plusDays(16).toString())));
                assertTrue(label(a,R.id.targetDateDisplay).contains("60 days left"));
                assertEquals(7,vm.state().getValue().data.analysis.points.size());
                assertEquals(3,((android.widget.LinearLayout)a.findViewById(R.id.recentHistoryContainer)).getChildCount());
            });
            screenshot("m3-home-current-progress");
            scenario.onActivity(this::scrollToTrends); screenshot("m3-trends-seven-lbs");
            scenario.onActivity(a -> ((android.widget.Spinner)a.findViewById(R.id.trendWindowSpinner)).setSelection(0));
            awaitMain(() -> !vm.busy() && vm.state().getValue().data.analysis.windowSize==3);
            scenario.onActivity(a -> assertEquals("170 lbs",label(a,R.id.trendAverage)));
            scenario.recreate(); HomeActivity recreated=current(HomeActivity.class);
            awaitMain(() -> !new ViewModelProvider(recreated).get(DashboardViewModel.class).busy());
            scenario.onActivity(a -> {
                assertEquals(0,((android.widget.Spinner)a.findViewById(R.id.trendWindowSpinner)).getSelectedItemPosition());
                assertEquals("170 lbs",label(a,R.id.trendAverage));
            });
            app.worker.submit(() -> app.repository.updateProfile(user,"Noel","Tester","5551234567","kg")).get(10,TimeUnit.SECONDS);
            scenario.onActivity(a -> new ViewModelProvider(a).get(DashboardViewModel.class).refresh());
            awaitMain(() -> label(recreated,R.id.trendAverage).equals("77.1 kg"));
            scenario.onActivity(a -> {
                assertEquals("-0.45 kg/day",label(a,R.id.trendRate));
                assertTrue(label(a,R.id.trendProjection).endsWith(com.example.weighttracker.util.DateUtils.formatForDisplay(today.plusDays(16).toString())));
                scrollToTrends(a);
            }); screenshot("m3-trends-three-kg");
            assertEquals(168,app.repository.load(user).records.get(0).getWeight(),0);
        }
    }
    @Test public void analyticsRefreshesAfterGoalEditAndDeletion() throws Exception {
        java.time.LocalDate today=java.time.LocalDate.now();
        app.worker.submit(() -> {
            for (int day=0;day<=14;day+=7) app.repository.save(user,new WeightInput(-1,today.minusDays(14-day).toString(),180-day,"",null));
        }).get(10,TimeUnit.SECONDS);
        try (ActivityScenario<HomeActivity> scenario=ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home=current(HomeActivity.class); DashboardViewModel vm=new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy() && vm.state().getValue().data != null);
            assertEquals(today.plusDays(16),vm.state().getValue().data.analysis.projectedDate);
            app.worker.submit(() -> app.repository.updateGoals(user,160,"")).get(10,TimeUnit.SECONDS);
            scenario.onActivity(a -> vm.refresh()); awaitMain(() -> !vm.busy());
            assertEquals(today.plusDays(6),vm.state().getValue().data.analysis.projectedDate);
            long latest=app.repository.load(user).records.get(0).getId();
            app.worker.submit(() -> app.repository.save(user,new WeightInput(latest,today.toString(),165,"edited",null))).get(10,TimeUnit.SECONDS);
            scenario.onActivity(a -> vm.refresh()); awaitMain(() -> !vm.busy());
            assertEquals(172.6666666667,vm.state().getValue().data.analysis.latest().movingAverage,1e-8);
            scenario.onActivity(a -> vm.delete(latest)); awaitMain(() -> !vm.busy());
            assertEquals(ProgressAnalysis.Status.INSUFFICIENT_DATA,vm.state().getValue().data.analysis.status);
            scenario.onActivity(a -> assertTrue(label(a,R.id.trendProjection).contains("3 entries spanning 7 days")));
        }
    }
    @Test public void analyticsEmptyFlatAndFutureDateStatesAreExplained() throws Exception {
        java.time.LocalDate today=java.time.LocalDate.now();
        try (ActivityScenario<HomeActivity> scenario=ActivityScenario.launch(HomeActivity.class)) {
            HomeActivity home=current(HomeActivity.class); DashboardViewModel vm=new ViewModelProvider(home).get(DashboardViewModel.class);
            awaitMain(() -> !vm.busy() && vm.state().getValue().data != null);
            scenario.onActivity(a -> { assertEquals("Add your first entry to begin.",label(a,R.id.trendProjection)); scrollToTrends(a); });
            screenshot("m3-trends-empty");
            app.worker.submit(() -> {
                for (int day=0;day<=14;day+=7) app.repository.save(user,new WeightInput(-1,today.minusDays(day).toString(),180,"",null));
            }).get(10,TimeUnit.SECONDS);
            scenario.onActivity(a -> vm.refresh()); awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> { assertTrue(label(a,R.id.trendProjection).contains("flat")); scrollToTrends(a); });
            screenshot("m3-trends-flat");
            app.worker.submit(() -> app.repository.save(user,new WeightInput(-1,today.plusDays(1).toString(),179,"future",null))).get(10,TimeUnit.SECONDS);
            scenario.onActivity(a -> vm.refresh()); awaitMain(() -> !vm.busy());
            scenario.onActivity(a -> {
                assertTrue(label(a,R.id.trendProjection).contains("future"));
                assertEquals("—",label(a,R.id.trendAverage));
                assertNotNull(a.findViewById(R.id.bottomNavigation));
            });
        }
    }
}
