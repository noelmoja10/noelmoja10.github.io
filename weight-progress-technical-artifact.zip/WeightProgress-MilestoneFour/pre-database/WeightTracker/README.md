# Weight Progress — UI Review Preview (September 25)

Open **this WeightTracker directory** (the one containing `settings.gradle`) in Android Studio, not the outer ZIP/extraction folder. Select **app / debug**, choose your emulator, and Run. The visible name is **Weight Progress**; the debug package is `com.example.weighttracker.uireview`. It installs separately from Milestone Three and earlier previews. Use a fictional account; existing accounts are not copied.

This is a **review-only UI iteration**, based on the complete Milestone Three project. It preserves its algorithms and earlier UI enhancements while implementing Noel's seven September 25 requests. New and edited weights/goals are limited to 700 lbs (about 317.5 kg); existing records remain unchanged. See the outer `README.md`, `CHANGES.md`, and `VERIFICATION.md` for the walkthrough, limitations, and actual test results. Nothing is submitted, published, or adopted for Milestone Four until Noel approves it.

## Build

Use JDK 21, Android SDK platform 36.1, Gradle 9.4.1, and Android Gradle Plugin 9.2.1. Android Studio can configure the installed SDK. Dependencies need network access unless already cached.

```sh
./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest
./gradlew :app:connectedDebugAndroidTest
```

The debug APK is `app/build/outputs/apk/debug/app-debug.apk`. Instrumentation needs an emulator/device and uses unique disposable databases plus a non-sending SMS gateway. Gradle may remove the tested app afterward; Run again for interactive review.

## Structure

- `ui/`: shared navigation, inline errors, onboarding, Me/account/goals, and existing weight screens.
- `presentation/`: lifecycle-aware ViewModels and asynchronous UI state.
- `domain/`: repository contract, validation, unit conversion, session, SMS policy, and the new pure-Java `ProgressAnalyzer`, immutable `ProgressAnalysis`, and `TrendDisplay`.
- `data/`: SQLite adapter and additive version-3 account preferences. Stored measurements remain in pounds.
- `app/src/test`: analytics/reference comparisons and validation, units, ViewModel, SMS-policy, date, and password tests.
- `app/src/androidTest`: real SQLite and synthetic-account UI/lifecycle tests.

See `../VERIFICATION.md` for measured results. The database schema remains version 3. Room and goal-history migrations are reserved for the database milestone; this UI work does not replace that enhancement.

Inter assets and licensing notices are retained. `README-CS360.md` and `ALGORITHM_DESIGN.md` document the inherited artifact; use this README to run this preview.
