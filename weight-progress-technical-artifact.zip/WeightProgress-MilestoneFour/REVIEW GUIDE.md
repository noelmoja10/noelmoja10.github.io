# Milestone Four review guide

Noel Canlas · CS 499 · Enhancement Three — Databases

## Submission files

Submit the **technical artifact ZIP** and separate **Microsoft Word narrative** after reviewing them. The ZIP contains original/enhanced technical sources and an extra pre-database snapshot for comparison. The standalone APK is optional for local review. No course submission or GitHub publication has been performed.

| Folder | Contents |
| --- | --- |
| `original/WeightTracker` | Unmodified CS 360 source, matching the Milestone Three original snapshot |
| `pre-database/WeightTracker` | Unmodified approved September 25 UI version, including Milestone Three analytics |
| `enhanced/WeightTracker` | Runnable Room version-4 project |
| `evidence` | Build/test logs, unit XML, lint report, benchmarks, synthetic screenshots, and hashes |

Open **`enhanced/WeightTracker`** in Android Studio, not `enhanced` or the outer ZIP folder. Sync Gradle, select app/debug and an emulator, then Run. The enhanced README has prerequisites and commands. The visible name is Weight Progress; debug package `.milestone4` keeps it separate from earlier apps. Use a fictional account; separate installations do not share data.

## Database changes

- Four Room entities and three DAOs replace the production SQLite helper/adapter.
- Goal revisions retain earlier targets; a unique active-slot index and transactions keep one current goal.
- Date-range history, latest-by-date, SQL aggregates, and revision reports are account-scoped and parameterized.
- Multi-step registration, setup, goals, profile, and measurement operations are transactional.
- Explicit migrations support versions 1–3 without destructive fallback, preserving credentials, IDs, weights, and preferences.
- Constraints/triggers supplement validation, including the 700 lb new-write limit while preserving older records.

`enhanced/WeightTracker/DATABASE_DESIGN.md` includes relationships, query trade-offs, migrations, security limits, and read-only demonstration queries. Most changes are behind the approved UI; no new goal-history screen was added.

## Approved UI carried forward

The enhanced source preserves the compact selectors, inline duplicate-date errors, error dismissal after clearing weight, Quick Entry typography, Weight Progress permission label, target-date/countdown styling, distinct account labels/values, and consistent password hints. It also retains onboarding, lbs/kg, stationary bottom navigation and directional transitions, three-entry Home preview, SMS toggles, account/goals controls, and moving-average/trend analysis.

`evidence/package-summary.json` verifies hashes against the approved baseline. UI/presentation/resources and analytics are unchanged; the application now supplies Room. Prior submitted packages and the approved UI archive remain untouched.

## Review sequence

1. Read the Word narrative and database design note.
2. Build/run, create a test account, complete setup, add dated entries, edit goals twice, and change units. Confirm familiar UI behavior.
3. Run unit/instrumentation tests covering migrations, rollback, isolation, constraints, concurrency, and query results.
4. Inspect goal rows in Database Inspector or review `RoomInstrumentedTest` report assertions. An identical goal/date save should not add a revision.
5. Review measured history-size benchmarks and their limitations. They address prior instructor feedback without claiming production performance guarantees.

## Remaining work

The database enhancement is prepared for instructor review; final ePortfolio polish awaits feedback. Physical-device/API coverage and a complete accessibility review remain, consistent with Milestone Two feedback. This package is not a medical validation, production security audit, or real SMS-delivery test.
