# Database enhancement design

Noel Canlas · CS 499 Milestone Four · October 3, 2026

## Plan and boundary

The Category Three plan replaces the custom SQLite adapter with Room, adds goal history, implements scoped queries, and verifies legacy-data preservation. Production `WeightApplication` now supplies `RoomWeightRepository` through the existing `WeightRepository` interface. UI/presentation, approved resources, validation, units, and analytics remain unchanged. `DatabaseReport` provides an immutable range/statistics/goal-history result without exposing credentials or Room entities.

The original already had parameterized SQL, foreign keys, uniqueness, and transactions. This enhancement retains those protections and adds typed DAO access, schema metadata, historical goals, migration evidence, and database guards. It does not claim to introduce every control for the first time.

## Relational model

```text
users 1 ───── 1 user_settings
      │
      ├────── * weight_records
      │
      └────── * weight_goals
```

All child tables reference `users.id` with `ON DELETE CASCADE`. Foreign keys and unique indexes enforce relationships and at-most-one rules; repository registration/goal transactions maintain the required settings and active goal.

| Table | Main fields and constraints | Purpose |
| --- | --- | --- |
| `users` | Autoincrement ID; unique normalized username; names, email, profile phone, hash, salt, created time | Identity and credential compatibility |
| `user_settings` | User ID primary/foreign key; SMS destination, enabled/alert flags, unit, onboarding flag | One-to-one preferences |
| `weight_records` | Autoincrement ID; user ID; ISO date; pounds; notes; created time; unique user/date | One measurement per account/date |
| `weight_goals` | Autoincrement ID; user ID; pounds; optional target date; recorded time; nullable active slot | Current goal and previous revisions |

Old `account_preferences` fields merge into settings; goal/target-date fields move into revisions. `active_slot=1` means current; NULL means historical. A unique `(user_id, active_slot)` index permits multiple historical rows but only one current row because SQLite treats NULL entries as distinct for uniqueness ([SQLite CREATE INDEX](https://www.sqlite.org/lang_createindex.html)). Triggers restrict slot values and revision-content changes. Retiring the current row is the supported update; identical goal/date saves create no redundant revision.

The model normalizes changing goals/preferences without rewriting every legacy field. Username/email duplication remains for compatibility. Profile contact and SMS destination are separately preserved because old versions could store different values; editing the profile still synchronizes both. This is not a claim that every historical redundancy was eliminated.

## Queries and indexes

Runtime values are bound parameters in `@Query` or generated `@Insert` operations. Reads/mutations include account ownership. Migration table identifiers are hard-coded, not supplied by users.

| Query | Behavior | Index and trade-off |
| --- | --- | --- |
| History | One account, newest entry date first | Unique user/date index also supports ordering |
| Range | Inclusive start/end, chronological rows | User/date index locates range; returning k rows still costs O(k) |
| Latest | Latest entry date, not last inserted ID | Reverse user/date traversal, LIMIT 1 |
| Statistics | SQL COUNT, MIN, MAX, AVG over range | Visits matching rows; no stale cached summary |
| Current goal | Account plus active slot 1 | Unique user/active index |
| Revisions | Account, newest revision ID first | User/ID index; output grows with history |

B-tree indexes support approximately O(log n) lookup plus matching-row work, but consume storage and increase write maintenance. Aggregation is not O(1). `report()` materializes the chosen weight range and all goal revisions. The dashboard still loads records for full-history analytics; future large-history work could add paging and separate summaries. `EXPLAIN QUERY PLAN` tests verify indexed search for range/current-goal queries. Timing evidence is in outer `evidence/BENCHMARKS.md`, separate from asymptotic claims.

An empty range yields count zero and NULL min/max/average, not a zero-weight observation. Report `latest` means latest overall, even outside its requested range. Invalid/reversed date ranges are rejected. Results remain in pounds; conversion is for display only.

## Transactions

- Registration creates user, settings, and default 150 lb goal together.
- Goal replacement retires the prior row and inserts its successor together. Failed insertion restores the prior current goal. Alert state resets on weight change, retaining existing date-only behavior.
- Measurement-plus-goal saves commit both or neither.
- One-time setup groups optional initial measurement, goal, unit, SMS preference, and completion flag.
- Profile updates keep contact/preferences consistent. Password changes/deletion require reauthentication; deletion cascades to children.
- Multi-query loads/reports return a consistent transactional view.

Tests inject failures into registration, setup, and goal insertion and verify rollback. Eight concurrent goal changes leave one active goal.

## Migration

Room version **4** accepts **1 → 3 → 4**, **2 → 3 → 4**, and **3 → 4**. Early paths restore legacy profile/preferences shape first. Accounts predating onboarding are marked complete. Room validates the final schema before opening it. Manual migration fits this table split/merge; Android recommends explicit paths and migration testing for complex changes ([Android migration guidance](https://developer.android.com/training/data-storage/room/migrating-db-versions)).

Inside Room's upgrade transaction, version 3 to 4:

1. Checks foreign keys and required settings/preferences relationships.
2. Renames old tables and creates the four Room tables.
3. Copies IDs, credentials, profiles, timestamps, exact weight values, notes, and preferences, including SMS/alert state.
4. Converts each stored current goal into an active revision. Its time is the migration time; prior goal dates are unknown.
5. Checks source/destination counts, preserves autoincrement high-water marks, replaces old tables, creates indexes, and checks foreign keys again.
6. Installs new-write guards after copying legacy values.

There is no destructive fallback. Unsupported/inconsistent schemas fail without a silent reset. A missing-settings fixture confirms failure leaves version 3 and its user row intact. Fixtures for versions 1–3 verify credentials, precision, IDs, preferences, relationships, queries, and reopen behavior. They reconstruct legacy SQLite shapes; generated Room validation checks the resulting version-4 schema. No private user database is read.

The approved new-write rule is **0 < weight ≤ 700 lbs**. Older permitted data above that limit is preserved exactly. Guards are installed after copying so a tighter rule does not erase history. Old large records remain viewable/deletable, but edits must meet the new limit. Calendar/range guards are verified on fresh and migrated databases.

## Security and limits

Bound parameters, account-scoped operations, relational constraints, and rollback help prevent injection, cross-account mutations, orphaned rows, and partial saves. Database guards reject invalid new weights, calendar dates, units, and flags as well as application validation. Existing password hashing remains; reports exclude hashes/salts, and storage errors expose no SQL/private details.

This is a local app, not a server authentication boundary. Room does not encrypt data at rest or protect a compromised device/process. Cloud sync, encrypted backup, credential-policy migration, and automatic corruption repair are outside this enhancement. Exported schema JSON describes tables/indexes/foreign keys, while custom triggers are documented and tested separately.

The legacy helper/adapter are test-only. UI tests use synthetic accounts and a non-sending SMS gateway. Physical-device, multiple-API, carrier, and full TalkBack verification remain follow-up work.

## Demonstration

Run the debug app, create a fictional account, add dated weights in mixed insertion order, and change goals twice in Me. Inspect this process's `weight_progress.db` with Android Studio Database Inspector. Use read-only queries:

```sql
SELECT id, user_id, goal_weight, target_date, active_slot, created_at
FROM weight_goals ORDER BY user_id, id;

SELECT user_id, COUNT(*) AS entries, MIN(weight) AS minimum,
       MAX(weight) AS maximum, AVG(weight) AS average
FROM weight_records GROUP BY user_id;

PRAGMA foreign_key_check;
```

Do not modify production rows in the inspector. There is no new goal-history screen: existing goal edits create revisions, and repository tests demonstrate scoped reports and migrations.
