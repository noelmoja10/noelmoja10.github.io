package com.example.weighttracker.domain;

import com.example.weighttracker.model.WeightRecord;
import java.time.LocalDate;
import java.util.Collections;
import org.junit.Test;
import static org.junit.Assert.*;

public class WeightPolicyTest {
    @Test public void newEntryAndLegacyReadPoliciesAreExplicit() {
        assertTrue(WeightPolicy.validEntry(700)); assertFalse(WeightPolicy.validEntry(701));
        assertTrue(WeightPolicy.validStored(1500)); assertFalse(WeightPolicy.validStored(1501));
        for (double n : new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY}) {
            assertFalse(WeightPolicy.validEntry(n)); assertFalse(WeightPolicy.validStored(n));
        }
    }
    @Test public void oldWeightsRemainVisibleToReadOnlyAnalytics() {
        WeightRecord record = new WeightRecord(1,1,"2026-09-25",800,"legacy");
        ProgressAnalysis result = new ProgressAnalyzer().analyze(Collections.singletonList(record),1,600,7,LocalDate.of(2026,9,25));
        assertNotEquals(ProgressAnalysis.Status.INVALID_DATA,result.status);
        assertEquals(800,result.points.get(0).weight,0);
        assertEquals(800,record.getWeight(),0);
    }
}
