package com.example.weighttracker.domain;

import com.example.weighttracker.model.WeightRecord;
import java.time.LocalDate;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;
import static com.example.weighttracker.domain.ProgressAnalysis.Status.*;

public class ProgressAnalyzerTest {
    private final ProgressAnalyzer analyzer = new ProgressAnalyzer();
    private final LocalDate first = LocalDate.of(2026,9,1), asOf = first.plusDays(14);
    private WeightRecord entry(int day,double pounds) { return new WeightRecord(day+1,1,first.plusDays(day).toString(),pounds,""); }
    private List<WeightRecord> loss() { return Arrays.asList(entry(0,180),entry(7,173),entry(14,166)); }
    private ProgressAnalysis analyze(List<WeightRecord> records,double goal,int window) { return analyzer.analyze(records,1,goal,window,asOf); }
    @Test public void noRecordsProducesExplicitEmptyState() {
        ProgressAnalysis r = analyze(Collections.emptyList(),150,7);
        assertEquals(NO_DATA,r.status); assertNull(r.latest()); assertNull(r.projectedDate);
    }
    @Test public void movingWindowEvictsOldestAndHandlesPartialWindow() {
        ProgressAnalysis r = analyze(loss(),150,2);
        assertEquals(180,r.points.get(0).movingAverage,1e-9);
        assertEquals(176.5,r.points.get(1).movingAverage,1e-9);
        assertEquals(169.5,r.latest().movingAverage,1e-9);
        assertEquals(2,r.latest().samples);
    }
    @Test public void oneEntryShowsAverageWithoutForecast() {
        ProgressAnalysis r = analyze(Collections.singletonList(entry(14,166)),150,7);
        assertEquals(INSUFFICIENT_DATA,r.status); assertNull(r.poundsPerDay); assertEquals(166,r.latest().movingAverage,0);
    }
    @Test public void twoEntriesCannotClaimForecast() { assertEquals(INSUFFICIENT_DATA,analyze(loss().subList(0,2),150,7).status); }
    @Test public void needsSevenDaySpan() {
        assertEquals(INSUFFICIENT_DATA,analyze(Arrays.asList(entry(0,180),entry(1,179),entry(6,174)),150,7).status);
    }
    @Test public void irregularDatesUseElapsedDaysAndLatestDateAnchor() {
        ProgressAnalysis r = analyze(Arrays.asList(entry(14,166),entry(0,180),entry(2,178)),150,7);
        assertEquals(-1,r.poundsPerDay,1e-10); assertEquals(ESTIMATED,r.status);
        assertEquals(first.plusDays(30),r.projectedDate);
    }
    @Test public void sortsDefensiveCopyAndReturnsImmutableOutput() {
        List<WeightRecord> input = new ArrayList<>(loss()); Collections.reverse(input);
        WeightRecord firstInput = input.get(0);
        ProgressAnalysis r = analyze(input,150,7);
        assertSame(firstInput,input.get(0)); assertEquals(first,r.points.get(0).date);
        assertThrows(UnsupportedOperationException.class,() -> r.points.clear());
    }
    @Test public void insertionOrderDoesNotChangeResult() {
        List<WeightRecord> list = new ArrayList<>(loss()); Collections.shuffle(list,new Random(8));
        assertEquals(analyze(loss(),150,7).projectedDate,analyze(list,150,7).projectedDate);
    }
    @Test public void flatTrendHasNoDate() {
        ProgressAnalysis r = analyze(Arrays.asList(entry(0,180),entry(7,180),entry(14,180)),150,7);
        assertEquals(FLAT_TREND,r.status); assertNull(r.projectedDate); assertEquals(0,r.poundsPerDay,0);
    }
    @Test public void increasingTrendDoesNotPredictWeightLoss() {
        assertEquals(MOVING_AWAY,analyze(Arrays.asList(entry(0,170),entry(7,177),entry(14,184)),150,7).status);
    }
    @Test public void goalReachedIsNotAnArtificialFutureDate() {
        ProgressAnalysis r = analyze(loss(),166,7); assertEquals(GOAL_REACHED,r.status); assertNull(r.projectedDate);
        assertEquals(GOAL_REACHED,analyze(Collections.singletonList(entry(0,140)),150,7).status);
    }
    @Test public void veryDistantForecastIsSuppressed() {
        assertEquals(OUT_OF_RANGE,analyze(Arrays.asList(entry(0,180),entry(7,179.99),entry(14,179.98)),150,7).status);
    }
    @Test public void projectionBoundaryIsInclusiveAndRoundsUp() {
        List<WeightRecord> high = Arrays.asList(entry(0,514),entry(7,507),entry(14,500));
        assertEquals(first.plusDays(379),analyze(high,135,7).projectedDate);
        assertEquals(first.plusDays(31),analyze(loss(),149.8,7).projectedDate);
        assertEquals(OUT_OF_RANGE,analyze(high,134,7).status);
    }
    @Test public void staleMeasurementsDoNotPredictFromToday() {
        assertEquals(STALE_DATA,analyzer.analyze(loss(),1,100,7,asOf.plusDays(31)).status);
    }
    @Test public void pastProjectionRequiresFreshMeasurement() {
        assertEquals(PAST_PROJECTION,analyzer.analyze(loss(),1,165,7,asOf.plusDays(3)).status);
    }
    @Test public void invalidDatesWeightsAndDuplicateDaysFailClosed() {
        for (String date : Arrays.asList("2026-02-30","garbage",null,"0000-01-01")) {
            assertEquals(INVALID_DATA,analyze(Collections.singletonList(new WeightRecord(1,1,date,180,"")),150,7).status);
        }
        for (double weight : new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY,1501}) {
            assertEquals(INVALID_DATA,analyze(Collections.singletonList(entry(0,weight)),150,7).status);
        }
        ProgressAnalysis duplicate = analyze(Arrays.asList(entry(0,180),entry(0,179),entry(7,170)),150,7);
        assertEquals(INVALID_DATA,duplicate.status); assertTrue(duplicate.points.isEmpty());
    }
    @Test public void futureRecordIsNotTreatedAsObservedWeight() { assertEquals(INVALID_DATA,analyze(Collections.singletonList(entry(15,180)),150,7).status); }
    @Test public void mixedAccountsCannotLeakIntoTrend() {
        List<WeightRecord> records = new ArrayList<>(loss()); records.add(new WeightRecord(99,2,"2026-09-10",50,"private"));
        ProgressAnalysis r = analyze(records,150,7); assertEquals(INVALID_DATA,r.status); assertTrue(r.points.isEmpty());
    }
    @Test public void invalidContainerGoalAndUserAreRejected() {
        assertEquals(INVALID_DATA,analyze(null,150,7).status);
        assertEquals(INVALID_DATA,analyze(Arrays.asList((WeightRecord)null),150,7).status);
        for (double goal : new double[]{0,1501,Double.NaN,Double.NEGATIVE_INFINITY}) assertEquals(INVALID_DATA,analyze(loss(),goal,7).status);
        assertEquals(INVALID_DATA,analyzer.analyze(loss(),-1,150,7,asOf).status);
    }
    @Test public void boundedConfigurationAndHistorySize() {
        assertThrows(IllegalArgumentException.class,() -> analyze(loss(),150,0));
        assertThrows(IllegalArgumentException.class,() -> analyze(loss(),150,366));
        assertThrows(IllegalArgumentException.class,() -> analyzer.analyze(loss(),1,150,7,null));
        assertEquals(LIMIT_EXCEEDED,analyze(Collections.nCopies(100001,entry(0,180)),150,7).status);
    }
    @Test public void leapDayAndDstUseCalendarDays() {
        List<WeightRecord> records = Arrays.asList(new WeightRecord(1,1,"2024-02-28",180,""),new WeightRecord(2,1,"2024-02-29",179,""),new WeightRecord(3,1,"2024-03-10",169,""));
        assertEquals(-1,analyzer.analyze(records,1,150,7,LocalDate.of(2024,3,10)).poundsPerDay,1e-12);
    }
    @Test public void displayConversionChangesNeitherProjectionNorStoredWeights() {
        ProgressAnalysis r = analyze(loss(),150,7);
        TrendDisplay lbs = new TrendDisplay(r,WeightUnits.LBS), kg = new TrendDisplay(r,WeightUnits.KG);
        assertEquals(lbs.projection,kg.projection); assertEquals("-0.45 kg/day",kg.trend);
        assertEquals("78.5 kg",kg.average); assertEquals(166,r.latest().weight,0);
        assertTrue(kg.context.contains("not days"));
    }
    @Test public void randomWindowsMatchNaiveReference() {
        Random random = new Random(499);
        for (int n : new int[]{1,2,3,20,300}) {
            List<WeightRecord> input = new ArrayList<>();
            for (int i=0;i<n;i++) input.add(entry(i,100+random.nextDouble()*100));
            for (int w : new int[]{1,3,7,14,365}) {
                ProgressAnalysis r = analyzer.analyze(input,1,50,w,first.plusDays(n));
                for (int i=0;i<n;i++) {
                    double sum = 0; int start = Math.max(0,i-w+1);
                    for (int j=start;j<=i;j++) sum += input.get(j).getWeight();
                    assertEquals(sum/(i-start+1),r.points.get(i).movingAverage,1e-9);
                }
            }
        }
    }
    @Test public void regressionMatchesIndependentTwoPassReference() {
        Random random = new Random(500); List<WeightRecord> input = new ArrayList<>();
        double meanX = 0,meanY = 0; int day = 0;
        for (int i=0;i<500;i++) { day += 1+random.nextInt(4); double y=100+random.nextDouble()*50; input.add(entry(day,y)); meanX += day/500.0; meanY += y/500.0; }
        double xx=0,xy=0;
        for (WeightRecord r : input) { double x=java.time.temporal.ChronoUnit.DAYS.between(first,LocalDate.parse(r.getEntryDate())); xx+=(x-meanX)*(x-meanX); xy+=(x-meanX)*(r.getWeight()-meanY); }
        ProgressAnalysis r = analyzer.analyze(input,1,50,7,first.plusDays(day));
        assertEquals(xy/xx,r.poundsPerDay,1e-12);
    }
    @Test public void longHistoryProducesFiniteResultsAndMatchesNaiveWindow() {
        int n=20000,w=365;
        List<WeightRecord> input=new ArrayList<>(); LocalDate start=LocalDate.of(1970,1,1);
        for (int i=0;i<n;i++) input.add(new WeightRecord(i+1,1,start.plusDays(i).toString(),180+(i%13)*0.1,""));
        ProgressAnalysis result=analyzer.analyze(input,1,150,w,start.plusDays(n));
        long referenceVisits=0; double naive=0;
        for (int i=0;i<n;i++) {
            naive=0; int begin=Math.max(0,i-w+1);
            for (int j=begin;j<=i;j++) { naive+=input.get(j).getWeight(); referenceVisits++; }
            assertEquals(naive/(i-begin+1),result.points.get(i).movingAverage,1e-8);
        }
        long dequeOperations=n+Math.max(0,n-w);
        assertEquals(n,result.points.size()); assertTrue(Double.isFinite(result.poundsPerDay));
        assertTrue(referenceVisits>dequeOperations*100);
        System.out.println("SCALING EVIDENCE: n="+n+", w="+w+", naive weight visits="+referenceVisits
                +", deque end operations="+dequeOperations+" (analytical count, not a timing benchmark)");
    }
}
