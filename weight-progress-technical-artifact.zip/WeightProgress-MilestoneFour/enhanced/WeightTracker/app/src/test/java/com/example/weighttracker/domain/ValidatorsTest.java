package com.example.weighttracker.domain;

import org.junit.Test;
import static org.junit.Assert.*;

public class ValidatorsTest {
    @Test public void emailIsTrimmedAndNormalized() { assertEquals("qa@example.com", Validators.email(" QA@Example.COM ")); }
    @Test public void invalidEmailIsFieldSpecific() { assertEquals("email", assertThrows(AppFailure.class, () -> Validators.email("bad")).field); }
    @Test public void phoneAllowsPresentationCharacters() { assertEquals("+15551234567", Validators.phone("+1 (555) 123-4567")); }
    @Test public void phoneRejectsUnexpectedCharacters() { assertThrows(AppFailure.class, () -> Validators.phone("555abc1234")); }
    @Test public void weightRejectsNonFiniteAndOutOfRangeValues() {
        for (String value : new String[]{"NaN", "Infinity", "-Infinity", "0", "-1", "700.1", "1500.1", "1e309", "", "x"})
            assertThrows(value, AppFailure.class, () -> Validators.weight(value, "weight"));
    }
    @Test public void weightPreservesDecimalsAndAllowsBoundaries() {
        assertEquals(181.26, Validators.weight("181.26", "weight"), 0);
        assertEquals(700, Validators.weight("700", "weight"), 0);
        assertEquals(0.1, Validators.weight("0.1", "weight"), 0);
    }
    @Test public void dateAcceptsDisplayAndIsoForms() {
        assertEquals("2026-09-19", Validators.date("09/19/2026"));
        assertEquals("2026-09-19", Validators.date("2026-09-19"));
    }
    @Test public void impossibleDateFails() { assertThrows(AppFailure.class, () -> Validators.date("02/30/2026")); }
    @Test public void newPasswordRequiresLetterAndDigit() {
        for (String value : new String[]{"short1", "abcdefgh", "12345678"}) assertThrows(AppFailure.class, () -> Validators.password(value, true));
        assertEquals("Goodpass1", Validators.password("Goodpass1", true));
    }
    @Test public void loginDoesNotChangeExistingPasswordPolicy() { assertEquals("old", Validators.password("old", false)); }
    @Test public void emptyPasswordFails() { assertThrows(AppFailure.class, () -> Validators.password("", false)); }
    @Test public void notesAreBounded() { assertThrows(AppFailure.class, () -> Validators.notes("x".repeat(2001))); }
    @Test public void missingUserFails() { assertThrows(AppFailure.class, () -> Validators.user(-1)); }
    @Test public void namesAreTrimmed() { assertEquals("Noel", Validators.name(" Noel ", "first")); }
    @Test public void editableWeightRoundTripsWithoutDisplayRounding() {
        assertEquals("181.26", WeightDisplay.editable(181.26));
        assertEquals("181.3", WeightDisplay.display(181.26));
        assertEquals("150", WeightDisplay.editable(150));
    }
    @Test public void originalLossProgressIsBounded() {
        assertEquals(50, WeightDisplay.lossProgress(200, 175, 150));
        assertEquals(0, WeightDisplay.lossProgress(200, 220, 150));
        assertEquals(100, WeightDisplay.lossProgress(200, 140, 150));
    }
}
