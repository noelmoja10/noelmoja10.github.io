package com.example.weighttracker.presentation;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import com.example.weighttracker.domain.*;
import org.junit.*;
import static org.junit.Assert.*;

public class SmsViewModelTest {
    @Rule public InstantTaskExecutorRule executor = new InstantTaskExecutorRule();
    private FakeRepository repository;
    private SmsViewModel model;
    @Before public void setup() {
        repository = new FakeRepository(); Session session = new Session(); session.signIn(1);
        model = new SmsViewModel(repository,session,Runnable::run,Runnable::run,repository.alerts()); model.refresh();
    }
    @Test public void readingPreferenceDoesNotWriteOrEnableIt() {
        model.refresh(); assertEquals(0,repository.smsUpdates); assertFalse(model.state().getValue().data.settings.isSmsEnabled());
    }
    @Test public void enablingAndDisablingPersistTheirExplicitStates() {
        model.update("5551234567",true); assertTrue(model.state().getValue().data.settings.isSmsEnabled());
        model.consumeCompletion(); model.update("5551234567",false); assertFalse(model.state().getValue().data.settings.isSmsEnabled());
        assertEquals(2,repository.smsUpdates);
    }
    @Test public void invalidPhoneCannotEnableSms() {
        model.update("invalid",true); assertEquals(0,repository.smsUpdates); assertEquals("phone",model.state().getValue().error.field);
    }
    @Test public void storageFailureRetainsPreviouslySavedPreference() {
        model.update("5551234567",true); model.consumeCompletion(); repository.smsFailure = AppFailure.storage();
        model.update("5551234567",false); assertEquals(AppFailure.Kind.STORAGE,model.state().getValue().error.kind);
        assertTrue(model.state().getValue().data.settings.isSmsEnabled()); assertEquals(1,repository.smsUpdates);
    }
    @Test public void disablingDoesNotRequireValidPhone() {
        model.update("",false); assertNull(model.state().getValue().error); assertEquals(1,repository.smsUpdates);
        assertFalse(model.state().getValue().data.settings.isSmsEnabled());
    }
}
