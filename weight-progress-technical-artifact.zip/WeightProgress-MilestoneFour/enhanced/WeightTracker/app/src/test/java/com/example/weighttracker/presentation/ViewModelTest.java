package com.example.weighttracker.presentation;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.lifecycle.SavedStateHandle;
import com.example.weighttracker.domain.*;
import java.util.ArrayDeque;
import java.util.concurrent.Executor;
import org.junit.*;
import static org.junit.Assert.*;

public class ViewModelTest {
    @Rule public InstantTaskExecutorRule rule = new InstantTaskExecutorRule();
    private final FakeRepository repo = new FakeRepository();
    private final Session session = new Session();
    private final Queue worker = new Queue();
    private static final class Queue implements Executor {
        final ArrayDeque<Runnable> pending = new ArrayDeque<>();
        @Override public void execute(Runnable job) { pending.add(job); }
        void run() { pending.remove().run(); }
    }
    @Before public void setup() { session.signIn(1); }
    private WeightEditorViewModel editor() {
        WeightEditorViewModel vm = new WeightEditorViewModel(repo, session, worker, Runnable::run, new SavedStateHandle(), repo.alerts());
        vm.initialize(7); worker.run(); return vm;
    }
    @Test public void loadPublishesLoadingThenData() {
        DashboardViewModel vm = new DashboardViewModel(repo, session, worker, Runnable::run, repo.alerts());
        vm.refresh(); assertTrue(vm.state().getValue().loading);
        assertNull(vm.state().getValue().data); worker.run();
        assertFalse(vm.state().getValue().loading); assertEquals(1, vm.state().getValue().data.records.size());
    }
    @Test public void analyticsRunsOnWorkerAndWindowChangeDoesNotWrite() {
        DashboardViewModel vm = new DashboardViewModel(repo,session,worker,Runnable::run,repo.alerts());
        vm.refresh(); assertNull(vm.state().getValue().data); worker.run();
        assertNotNull(vm.state().getValue().data.analysis);
        assertEquals(7,vm.state().getValue().data.analysis.windowSize);
        vm.setWindowSize(3); assertTrue(vm.busy());
        assertEquals(7,vm.state().getValue().data.analysis.windowSize);
        worker.run(); assertEquals(3,vm.state().getValue().data.analysis.windowSize);
        assertEquals(0,repo.saves); assertEquals(0,repo.smsUpdates);
        vm.setWindowSize(3); assertTrue(worker.pending.isEmpty());
        assertThrows(IllegalArgumentException.class,() -> vm.setWindowSize(0));
    }
    @Test public void analyticsCannotPublishAfterSessionChanges() {
        DashboardViewModel vm = new DashboardViewModel(repo,session,worker,Runnable::run,repo.alerts());
        vm.refresh(); worker.run(); assertNotNull(vm.state().getValue().data.analysis);
        vm.refresh(); session.logout(); worker.run();
        assertNull(vm.state().getValue().data);
        assertEquals(AppFailure.Kind.AUTHENTICATION,vm.state().getValue().error.kind);
    }
    @Test public void refreshReplacesAnalyticsAfterRecordsChange() {
        DashboardViewModel vm = new DashboardViewModel(repo,session,worker,Runnable::run,repo.alerts());
        vm.refresh(); worker.run(); assertEquals(1,vm.state().getValue().data.analysis.points.size());
        repo.snapshot = new Snapshot(java.util.Collections.emptyList(),repo.snapshot.settings);
        vm.delete(7); worker.run();
        assertEquals(ProgressAnalysis.Status.NO_DATA,vm.state().getValue().data.analysis.status);
    }
    @Test public void editingPreservesExactWeightAndGoal() {
        WeightEditorViewModel vm = editor(); assertEquals("181.26", vm.field("weight")); assertEquals("150.25", vm.field("goal"));
        vm.draft("notes", "note only"); vm.save(); worker.run();
        assertEquals(181.26, repo.lastInput.weight, 0); assertEquals("note only", repo.lastInput.notes);
    }
    @Test public void invalidWeightNeverReachesPersistence() {
        WeightEditorViewModel vm = editor(); vm.draft("weight", "NaN"); vm.save();
        assertEquals(0, repo.saves); assertTrue(worker.pending.isEmpty());
        assertEquals("weight", vm.state().getValue().error.field);
    }
    @Test public void invalidDateNeverReachesPersistence() {
        WeightEditorViewModel vm = editor(); vm.draft("date", "02/30/2026"); vm.save();
        assertEquals(0, repo.saves); assertEquals("date", vm.state().getValue().error.field);
    }
    @Test public void repeatedSubmissionIsIgnoredUntilCompletion() {
        WeightEditorViewModel vm = editor(); vm.save(); vm.save();
        assertEquals(1, worker.pending.size()); worker.run(); assertEquals(1, repo.saves);
        assertTrue(vm.consumeCompletion()); assertFalse(vm.consumeCompletion());
    }
    @Test public void duplicateDateHasDistinctErrorAndRetainsDraft() {
        WeightEditorViewModel vm = editor(); vm.draft("notes", "keep this");
        repo.saveFailure = new AppFailure(AppFailure.Kind.DUPLICATE_DATE, "date", "Duplicate date");
        vm.save(); worker.run(); assertEquals(AppFailure.Kind.DUPLICATE_DATE, vm.state().getValue().error.kind);
        assertEquals("keep this", vm.field("notes")); assertNotNull(vm.state().getValue().data);
    }
    @Test public void quickEntryDuplicateDateIsMappedToItsVisibleWeightField() {
        DashboardViewModel vm = new DashboardViewModel(repo,session,worker,Runnable::run,repo.alerts());
        vm.refresh(); worker.run();
        repo.saveFailure = new AppFailure(AppFailure.Kind.DUPLICATE_DATE,"date","Duplicate date");
        vm.quickSave("175"); worker.run();
        assertEquals(AppFailure.Kind.DUPLICATE_DATE,vm.state().getValue().error.kind);
        assertEquals("weight",vm.state().getValue().error.field);
        assertTrue(vm.state().getValue().error.getMessage().contains("History"));
        assertNotNull(vm.state().getValue().data); assertFalse(vm.state().getValue().completed);
    }
    @Test public void quickEntryCannotPersistMoreThanSevenHundredPounds() {
        DashboardViewModel vm = new DashboardViewModel(repo,session,worker,Runnable::run,repo.alerts());
        vm.refresh(); worker.run(); vm.quickSave("700.1");
        assertTrue(worker.pending.isEmpty()); assertEquals(0,repo.saves);
        assertEquals("weight",vm.state().getValue().error.field);
    }
    @Test public void storageFailureAllowsRetryWithoutLosingDraft() {
        WeightEditorViewModel vm = editor(); vm.draft("notes", "retry me"); repo.saveFailure = AppFailure.storage();
        vm.save(); worker.run(); assertEquals(AppFailure.Kind.STORAGE, vm.state().getValue().error.kind);
        repo.saveFailure = null; vm.save(); worker.run(); assertTrue(vm.state().getValue().completed);
        assertEquals("retry me", repo.lastInput.notes);
    }
    @Test public void reinitializingRetainedEditorDoesNotDiscardDraftOrResave() {
        WeightEditorViewModel vm = editor(); vm.draft("notes", "rotation"); vm.save();
        vm.initialize(7); assertEquals(1, worker.pending.size()); worker.run();
        vm.initialize(7); assertTrue(worker.pending.isEmpty()); assertEquals(1, repo.saves);
        assertEquals("rotation", vm.field("notes"));
    }
    @Test public void savedDraftWinsOverStoredValuesWhenRecreated() {
        SavedStateHandle saved = new SavedStateHandle(); saved.set("weight", "182.123"); saved.set("notes", "draft");
        WeightEditorViewModel vm = new WeightEditorViewModel(repo, session, worker, Runnable::run, saved, repo.alerts());
        vm.initialize(7); worker.run(); assertEquals("182.123", vm.field("weight")); assertEquals("draft", vm.field("notes"));
    }
    @Test public void draftDoesNotAcceptPasswordKeys() { assertThrows(IllegalArgumentException.class, () -> editor().draft("password", "secret")); }
    @Test public void missingRecordCannotBeSaved() {
        WeightEditorViewModel vm = new WeightEditorViewModel(repo, session, worker, Runnable::run, new SavedStateHandle(), repo.alerts());
        vm.initialize(99); worker.run(); vm.save(); assertEquals(0, repo.saves);
        assertEquals(AppFailure.Kind.NOT_FOUND, vm.state().getValue().error.kind);
    }
    @Test public void postSaveReadFailureDoesNotReportWriteFailure() {
        WeightEditorViewModel vm = editor(); repo.failLoadAfterSave = true; vm.save(); worker.run();
        assertTrue(vm.state().getValue().completed); assertNull(vm.state().getValue().error);
        assertTrue(vm.state().getValue().message.contains("saved")); assertEquals(1, repo.saves);
    }
    @Test public void queuedOperationDoesNotWriteAfterLogout() {
        WeightEditorViewModel vm = editor(); vm.save(); session.logout(); worker.run();
        assertEquals(0, repo.saves); assertNull(vm.state().getValue().data);
        assertEquals(AppFailure.Kind.AUTHENTICATION, vm.state().getValue().error.kind);
    }
    @Test public void authenticationRunsOnlyOnWorkerAndSetsSessionAfterSuccess() {
        session.logout(); AuthViewModel vm = new AuthViewModel(repo, session, worker, Runnable::run);
        vm.signIn("qa@example.com", "Goodpass1"); assertEquals(0, repo.logins); assertEquals(-1, session.userId());
        worker.run(); assertEquals(1, repo.logins); assertEquals(1, session.userId());
    }
    @Test public void badEmailDoesNotReachAuthentication() {
        AuthViewModel vm = new AuthViewModel(repo, session, worker, Runnable::run); vm.signIn("invalid", "Goodpass1");
        assertTrue(worker.pending.isEmpty()); assertEquals(0, repo.logins);
    }
    @Test public void mismatchedConfirmationDoesNotCreateAccount() {
        AuthViewModel vm = new AuthViewModel(repo, session, worker, Runnable::run);
        vm.register("Noel", "Canlas", "qa@example.com", "5551234567", "Goodpass1", "wrong");
        assertEquals("confirmation", vm.state().getValue().error.field); assertEquals(0, repo.registrations);
    }
    @Test public void invalidQuickWeightDoesNotSave() {
        DashboardViewModel vm = new DashboardViewModel(repo, session, worker, Runnable::run, repo.alerts());
        vm.quickSave("Infinity"); assertEquals(0, repo.saves); assertTrue(worker.pending.isEmpty());
    }
    @Test public void quickSaveUsesTodayAndDoesNotChangeGoal() {
        DashboardViewModel vm = new DashboardViewModel(repo, session, worker, Runnable::run, repo.alerts());
        vm.refresh(); worker.run();
        vm.quickSave("190.25"); worker.run(); assertNull(repo.lastInput.goal); assertTrue(vm.state().getValue().completed);
    }
    @Test public void completionIdentifiesQuickEntryAndNotDeletion() {
        DashboardViewModel vm = new DashboardViewModel(repo, session, worker, Runnable::run, repo.alerts());
        vm.refresh(); worker.run(); assertFalse(vm.isQuickEntryOperation());
        vm.quickSave("175"); assertTrue(vm.isQuickEntryOperation());
        // A resume/refresh while saving must not misidentify the pending operation.
        vm.refresh(); assertTrue(vm.isQuickEntryOperation()); assertEquals(1,worker.pending.size());
        worker.run(); assertTrue(vm.consumeCompletion()); assertTrue(vm.isQuickEntryOperation());
        vm.delete(7); assertFalse(vm.isQuickEntryOperation()); worker.run();
        assertTrue(vm.consumeCompletion()); assertFalse(vm.isQuickEntryOperation());
    }
    @Test public void kilogramNoteOnlyEditPreservesExactStoredPounds() {
        repo.snapshot = new Snapshot(repo.snapshot.records,new com.example.weighttracker.model.UserSettings(1,150.25,"",false,false,"kg","",true));
        WeightEditorViewModel vm = editor(); assertEquals(WeightUnits.KG.input(181.26),vm.field("weight"));
        vm.draft("notes","note only in kg"); vm.save(); worker.run();
        assertEquals(181.26,repo.lastInput.weight,0); assertNull(repo.lastInput.goal);
    }
    @Test public void kilogramQuickEntryIsConvertedOnce() {
        repo.snapshot = new Snapshot(repo.snapshot.records,new com.example.weighttracker.model.UserSettings(1,150,"",false,false,"kg","",true));
        DashboardViewModel vm = new DashboardViewModel(repo,session,worker,Runnable::run,repo.alerts()); vm.refresh(); worker.run();
        vm.quickSave("80"); worker.run(); assertEquals(WeightUnits.KG.toPounds(80),repo.lastInput.weight,0);
    }
    @Test public void unfinishedAccountResumesOnboardingOnLogin() {
        repo.snapshot = new Snapshot(repo.snapshot.records,new com.example.weighttracker.model.UserSettings(1,150,"",false,false,"lbs","",false));
        session.logout(); AuthViewModel vm = new AuthViewModel(repo,session,worker,Runnable::run); vm.signIn("qa@example.com","Testpass1"); worker.run();
        assertTrue(session.needsSetup());
    }
}
