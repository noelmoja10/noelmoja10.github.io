package com.example.weighttracker.domain;

import java.time.LocalDate;
import org.junit.Test;
import static org.junit.Assert.*;

public class TargetDateDisplayTest {
    private final LocalDate today = LocalDate.of(2026, 9, 19);
    @Test public void absentDateHasNoLabel() {
        assertEquals("",TargetDateDisplay.label(null,today));
        assertEquals("",TargetDateDisplay.label("",today));
        assertEquals("",TargetDateDisplay.label("  ",today));
    }
    @Test public void futureDateShowsDaysLeftBesideDate() {
        assertEquals("Sep 30, 2026\n11 days left",TargetDateDisplay.label("2026-09-30",today));
    }
    @Test public void tomorrowUsesSingularDay() {
        assertEquals("Sep 20, 2026\n1 day left",TargetDateDisplay.label("2026-09-20",today));
    }
    @Test public void todayShowsZeroNotNegativeDays() {
        assertEquals("Sep 19, 2026\nTarget is today",TargetDateDisplay.label("2026-09-19",today));
    }
    @Test public void pastDateShowsDaysOverdue() {
        assertEquals("Sep 17, 2026\nTarget passed 2 days ago",TargetDateDisplay.label("2026-09-17",today));
        assertEquals("Sep 18, 2026\nTarget passed 1 day ago",TargetDateDisplay.label("2026-09-18",today));
    }
    @Test public void leapDayIsCounted() {
        assertEquals("Mar 1, 2028\n2 days left",TargetDateDisplay.label("2028-03-01",LocalDate.of(2028,2,28)));
    }
    @Test public void daylightSavingBoundaryUsesCalendarDays() {
        assertEquals("Mar 9, 2026\n2 days left",TargetDateDisplay.label("2026-03-09",LocalDate.of(2026,3,7)));
    }
    @Test public void invalidStoredDateDoesNotCrashHome() {
        assertEquals("",TargetDateDisplay.label("2026-02-30",today));
        assertEquals("",TargetDateDisplay.label("not a date",today));
    }
}
