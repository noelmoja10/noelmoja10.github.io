package com.example.weighttracker.ui;

import org.junit.Test;
import static org.junit.Assert.*;

public class TabMotionTest {
    @Test public void rightwardTabSelectionEntersFromRight() {
        for (int from = 0; from < 4; from++)
            for (int to = from + 1; to < 4; to++) assertEquals(1, TabMotion.direction(from, to));
    }
    @Test public void leftwardTabSelectionEntersFromLeft() {
        for (int from = 1; from < 4; from++)
            for (int to = 0; to < from; to++) assertEquals(-1, TabMotion.direction(from, to));
    }
    @Test public void sameTabDoesNotSlide() {
        for (int tab = 0; tab < 4; tab++) assertEquals(0, TabMotion.direction(tab, tab));
    }
}
