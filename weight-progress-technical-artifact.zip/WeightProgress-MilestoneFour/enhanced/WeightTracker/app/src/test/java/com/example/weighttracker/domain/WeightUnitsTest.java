package com.example.weighttracker.domain;
import org.junit.Test;
import static org.junit.Assert.*;
public class WeightUnitsTest {
    @Test public void defaultsRepresentTheSamePhysicalWeight() { assertEquals(68.0388555,WeightUnits.KG.fromPounds(150),0.00000001); assertEquals(150,WeightUnits.KG.toPounds(68.0388555),0.00000001); }
    @Test public void boundariesAndInvalidNumbersAreRejected() {
        for (String input : new String[]{"","-2","0","NaN","Infinity","999999"}) assertThrows(AppFailure.class,() -> WeightUnits.KG.parse(input,"weight"));
        assertEquals(700,WeightUnits.KG.parse(WeightUnits.KG.input(700),"weight"),0.000002);
    }
    @Test public void bothUnitsEnforceTheSameNewEntryLimit() {
        assertEquals(700,WeightUnits.LBS.parse("700","weight"),0);
        assertEquals(700,WeightUnits.KG.parse("317.514659","weight"),0.000001);
        assertTrue(WeightUnits.KG.parse("317.5","goal") < 700);
        assertThrows(AppFailure.class,() -> WeightUnits.LBS.parse("700.001","weight"));
        assertThrows(AppFailure.class,() -> WeightUnits.KG.parse("317.6","weight"));
        assertThrows(AppFailure.class,() -> WeightUnits.LBS.parse("1500","goal"));
    }
    @Test public void emptyInputUsesRequiredCopyRatherThanRangeCopy() {
        assertEquals("Enter a weight to continue",assertThrows(AppFailure.class,() -> WeightUnits.KG.parse(" ","weight")).getMessage());
        assertTrue(assertThrows(AppFailure.class,() -> WeightUnits.KG.parse("999","weight")).getMessage().contains("317.5 kg"));
    }
    @Test public void poundsEditingRemainsLossless() { double n = 181.123456789; assertEquals(n,Double.parseDouble(WeightUnits.LBS.input(n)),0); }
}
