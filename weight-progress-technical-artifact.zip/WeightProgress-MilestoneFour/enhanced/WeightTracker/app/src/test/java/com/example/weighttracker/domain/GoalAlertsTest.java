package com.example.weighttracker.domain;

import com.example.weighttracker.model.*;
import java.util.Collections;
import org.junit.Test;
import static org.junit.Assert.*;

public class GoalAlertsTest {
    private static final class Repo implements WeightRepository {
        boolean flag; int writes;
        public long signIn(String e, String p) { return 1; }
        public long register(String f, String l, String e, String p, String s) { return 1; }
        public Snapshot load(long id) { return null; }
        public long save(long id, WeightInput w) { return 1; }
        public void delete(long user, long id) { }
        public void smsSettings(long user, String phone, boolean enabled) { }
        public void alertRequested(long user, boolean requested) { flag = requested; writes++; }
        public AccountProfile profile(long user) { return null; }
        public void updateProfile(long user,String first,String last,String phone,String unit) { }
        public void finishSetup(long user,Double goal,Double current,String unit,String date,boolean sms) { }
        public void updateGoals(long user,double goal,String date) { }
        public void changePassword(long user,String current,String updated) { }
        public void deleteAccount(long user,String password) { }
    }
    private static final class Gateway implements GoalAlerts.Gateway {
        boolean permitted = true, fails; int requests;
        public boolean permitted() { return permitted; }
        public void request(String phone, double current, double goal) { requests++; if (fails) throw new IllegalStateException(); }
    }
    private Snapshot snapshot(double weight, boolean enabled, boolean sent) {
        return new Snapshot(Collections.singletonList(new WeightRecord(1, 1, "2026-09-19", weight, "")), new UserSettings(1, 150, "5551234567", enabled, sent));
    }
    @Test public void deniedPermissionNeverRequestsSms() {
        Repo repo = new Repo(); Gateway gateway = new Gateway(); gateway.permitted = false;
        new GoalAlerts(repo, gateway).evaluate(1, snapshot(140, true, false)); assertEquals(0, gateway.requests);
    }
    @Test public void disabledSmsNeverRequestsSms() {
        Repo repo = new Repo(); Gateway gateway = new Gateway();
        new GoalAlerts(repo, gateway).evaluate(1, snapshot(140, false, false)); assertEquals(0, gateway.requests);
    }
    @Test public void alreadyRequestedAlertIsNotRepeated() {
        Repo repo = new Repo(); Gateway gateway = new Gateway();
        new GoalAlerts(repo, gateway).evaluate(1, snapshot(140, true, true)); assertEquals(0, gateway.requests);
    }
    @Test public void requestIsNotClaimedAsDelivery() {
        Repo repo = new Repo(); Gateway gateway = new Gateway();
        String message = new GoalAlerts(repo, gateway).evaluate(1, snapshot(140, true, false));
        assertEquals(1, gateway.requests); assertTrue(repo.flag); assertTrue(message.contains("not confirmed"));
    }
    @Test public void failureDoesNotMarkAlertRequested() {
        Repo repo = new Repo(); Gateway gateway = new Gateway(); gateway.fails = true;
        assertFalse(new GoalAlerts(repo, gateway).evaluate(1, snapshot(140, true, false)).isEmpty()); assertEquals(0, repo.writes);
    }
    @Test public void movingAboveGoalResetsFlag() {
        Repo repo = new Repo(); Gateway gateway = new Gateway();
        new GoalAlerts(repo, gateway).evaluate(1, snapshot(180, true, true)); assertEquals(1, repo.writes); assertFalse(repo.flag);
    }
}
