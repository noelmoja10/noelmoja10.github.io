package com.example.weighttracker.presentation;

import com.example.weighttracker.domain.*;
import com.example.weighttracker.model.*;
import java.util.*;

final class FakeRepository implements WeightRepository {
    int saves, logins, registrations, deletes;
    WeightInput lastInput;
    AppFailure saveFailure;
    AppFailure smsFailure;
    int smsUpdates;
    boolean failLoadAfterSave;
    Snapshot snapshot = new Snapshot(Collections.singletonList(new WeightRecord(7, 1, "2026-09-18", 181.26, "original")), new UserSettings(1, 150.25, "", false, false));
    @Override public long signIn(String email, String password) { logins++; return 1; }
    @Override public long register(String first, String last, String email, String phone, String password) { registrations++; return 1; }
    @Override public Snapshot load(long id) { if (failLoadAfterSave && saves > 0) throw AppFailure.storage(); return snapshot; }
    @Override public long save(long user, WeightInput input) { saves++; lastInput = input; if (saveFailure != null) throw saveFailure; return 7; }
    @Override public void delete(long user, long id) { deletes++; }
    @Override public void smsSettings(long user, String phone, boolean enabled) {
        if (smsFailure != null) throw smsFailure;
        smsUpdates++;
        UserSettings old = snapshot.settings;
        snapshot = new Snapshot(snapshot.records,new UserSettings(user,old.getGoalWeight(),phone,enabled,old.isGoalAlertSent(),old.getUnit(),old.getTargetDate(),old.isOnboardingComplete()));
    }
    @Override public void alertRequested(long user, boolean requested) { }
    public AccountProfile profile(long user) { return new AccountProfile(user,"Test","User","test@example.com",snapshot.settings); }
    public void updateProfile(long user,String first,String last,String phone,String unit) { }
    public void finishSetup(long user,Double goal,Double current,String unit,String date,boolean sms) { }
    public void updateGoals(long user,double goal,String date) { }
    public void changePassword(long user,String current,String updated) { }
    public void deleteAccount(long user,String password) { }
    GoalAlerts alerts() { return new GoalAlerts(this, new GoalAlerts.Gateway() {
        @Override public boolean permitted() { return false; }
        @Override public void request(String phone, double current, double goal) { throw new AssertionError("No real SMS in tests"); }
    }); }
}
