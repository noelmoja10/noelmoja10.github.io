package com.example.weighttracker;

import android.content.Context;
import android.os.Bundle;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.weighttracker.data.RoomWeightRepository;
import com.example.weighttracker.data.room.*;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.model.WeightRecord;
import java.time.LocalDate;
import java.util.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Reproducible exploratory benchmark, not a device-independent performance guarantee. */
@RunWith(AndroidJUnit4.class)
public class PerformanceInstrumentedTest {
    private volatile Object sink;
    private double[] measure(Runnable work) {
        for(int i=0;i<5;i++) work.run();
        double[] ms=new double[11];
        for(int i=0;i<ms.length;i++) { long start=System.nanoTime(); work.run(); ms[i]=(System.nanoTime()-start)/1_000_000.0; }
        Arrays.sort(ms); return new double[]{ms[5],ms[10]};
    }
    @Test public void measureAnalyzerAndSqlAtDifferentHistorySizes() {
        Context context=ApplicationProvider.getApplicationContext();
        String name="benchmark-test-"+UUID.randomUUID()+".db";
        WeightDatabase db=WeightDatabase.open(context,name);
        try {
            RoomWeightRepository repo=new RoomWeightRepository(db);
            long user=repo.register("Benchmark","Tester","benchmark@example.com","5551234567","Testpass1");
            LocalDate asOf=LocalDate.of(2026,10,2); ProgressAnalyzer analyzer=new ProgressAnalyzer();
            for(int size:new int[]{10,100,1000,10000}) {
                db.getOpenHelper().getWritableDatabase().execSQL("DELETE FROM weight_records WHERE user_id=?",new Object[]{user});
                List<WeightRecord> shuffled=new ArrayList<>();
                db.runInTransaction(()->{
                    for(int i=0;i<size;i++) {
                        Tables.Weight w=new Tables.Weight(); w.user_id=user; w.entry_date=asOf.minusDays(size-i-1).toString(); w.weight=190-i*0.001; w.created_at="synthetic benchmark";
                        long id=db.weights().insert(w); shuffled.add(new WeightRecord(id,user,w.entry_date,w.weight,""));
                    }
                });
                Collections.shuffle(shuffled,new Random(42));
                assertEquals(size,analyzer.analyze(shuffled,user,150,7,asOf).points.size());
                assertEquals(size,db.weights().stats(user,"1900-01-01","2026-10-02").count);
                double[] algorithm=measure(()->sink=analyzer.analyze(shuffled,user,150,7,asOf));
                double[] aggregate=measure(()->sink=db.weights().stats(user,"1900-01-01","2026-10-02"));
                double[] latest=measure(()->sink=db.weights().latest(user));
                double[] materialized=measure(()->sink=repo.report(user,"1900-01-01","2026-10-02"));
                Bundle status=new Bundle(); status.putString("stream",String.format(Locale.US,
                        "\nBENCHMARK n=%d analyzer_median_ms=%.3f analyzer_p95_ms=%.3f aggregate_median_ms=%.3f aggregate_p95_ms=%.3f latest_median_ms=%.3f latest_p95_ms=%.3f report_median_ms=%.3f report_p95_ms=%.3f\n",
                        size,algorithm[0],algorithm[1],aggregate[0],aggregate[1],latest[0],latest[1],materialized[0],materialized[1]));
                InstrumentationRegistry.getInstrumentation().sendStatus(0,status);
            }
        } finally { db.close(); context.deleteDatabase(name); }
    }
}
