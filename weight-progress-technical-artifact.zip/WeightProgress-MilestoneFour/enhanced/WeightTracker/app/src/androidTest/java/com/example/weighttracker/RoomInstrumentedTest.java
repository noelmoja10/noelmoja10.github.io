package com.example.weighttracker;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.example.weighttracker.data.*;
import com.example.weighttracker.data.room.*;
import com.example.weighttracker.domain.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real Room + SQLite, disposable synthetic databases only. Never opens app account data. */
@RunWith(AndroidJUnit4.class)
public class RoomInstrumentedTest {
    private Context context;
    private WeightDatabase db;
    private RoomWeightRepository repo;
    private long alice,bob;
    private final List<String> names=new ArrayList<>();
    private final List<WeightDatabase> opened=new ArrayList<>();
    private String name() { String n="room-test-"+UUID.randomUUID()+".db"; names.add(n); return n; }
    private WeightDatabase open(String n) { WeightDatabase d=WeightDatabase.open(context,n); opened.add(d); return d; }
    @Before public void setup() {
        context=ApplicationProvider.getApplicationContext(); db=open(name()); repo=new RoomWeightRepository(db);
        alice=repo.register("Alice","Tester","alice@example.com","5551234567","Testpass1");
        bob=repo.register("Bobby","Tester","bob@example.com","5551234568","Testpass2");
    }
    @After public void cleanup() {
        for(WeightDatabase d:opened) d.close();
        for(String n:names) context.deleteDatabase(n);
    }
    private WeightInput input(long id,String date,double weight,Double goal) { return new WeightInput(id,date,weight,"synthetic",goal); }
    private DatabaseReport report(long user) { return repo.report(user,"2020-01-01","2030-12-31"); }
    private long count(String table,long user) {
        try(Cursor c=db.getOpenHelper().getReadableDatabase().query("SELECT COUNT(*) FROM "+table+" WHERE user_id=?",new Object[]{user})) { c.moveToFirst(); return c.getLong(0); }
    }
    @Test public void emptyAggregatesRemainNullNotZero() {
        DatabaseReport r=report(alice); assertEquals(0,r.count); assertNull(r.average); assertNull(r.minimum); assertNull(r.maximum); assertNull(r.latest);
        assertEquals(1,r.goals.size()); assertTrue(r.goals.get(0).active); assertEquals(150,r.goals.get(0).weight,0);
    }
    @Test public void chronologicalRangeLatestAndSqlAggregatesAreAccountScoped() {
        long latest=repo.save(alice,input(-1,"2026-09-20",170,null));
        repo.save(alice,input(-1,"2026-09-01",190,null)); repo.save(alice,input(-1,"2026-09-10",180,null));
        repo.save(bob,input(-1,"2026-09-20",400,null));
        DatabaseReport r=repo.report(alice,"2026-09-01","2026-09-10");
        assertEquals(2,r.count); assertEquals(185,r.average,0); assertEquals(180,r.minimum,0); assertEquals(190,r.maximum,0);
        assertEquals("2026-09-01",r.records.get(0).getEntryDate()); assertEquals(latest,r.latest.getId());
        assertEquals(170,repo.load(alice).records.get(0).getWeight(),0);
        assertThrows(UnsupportedOperationException.class,()->r.records.clear()); assertThrows(UnsupportedOperationException.class,()->r.goals.clear());
    }
    @Test public void reportRejectsInvalidRangesAndMissingUsers() {
        assertThrows(AppFailure.class,()->repo.report(alice,"2026-02-30","2026-09-10"));
        assertThrows(AppFailure.class,()->repo.report(alice,"2026-10-01","2026-09-10"));
        assertThrows(AppFailure.class,()->report(99999));
    }
    @Test public void goalHistoryRecordsChangesAndSuppressesNoOp() {
        repo.alertRequested(alice,true); repo.updateGoals(alice,150,"2027-01-01");
        assertTrue(repo.load(alice).settings.isGoalAlertSent());
        repo.updateGoals(alice,140,"2027-01-01"); repo.updateGoals(alice,140,"2027-01-01");
        DatabaseReport r=report(alice); assertEquals(3,r.goals.size()); assertTrue(r.goals.get(0).active);
        assertFalse(r.goals.get(1).active); assertFalse(r.goals.get(2).active);
        assertEquals(140,repo.load(alice).settings.getGoalWeight(),0); assertFalse(repo.load(alice).settings.isGoalAlertSent());
        assertEquals(1,report(bob).goals.size());
    }
    @Test public void failedGoalInsertRollsBackRetirementAndMeasurement() {
        db.getOpenHelper().getWritableDatabase().execSQL("CREATE TRIGGER fail_goal BEFORE INSERT ON weight_goals BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");
        assertEquals(AppFailure.Kind.STORAGE,assertThrows(AppFailure.class,()->repo.save(alice,input(-1,"2026-09-20",175,140.0))).kind);
        assertEquals(0,report(alice).count); assertEquals(1,report(alice).goals.size()); assertTrue(report(alice).goals.get(0).active);
    }
    @Test public void failedRegistrationLeavesNoPartialAccount() {
        db.getOpenHelper().getWritableDatabase().execSQL("CREATE TRIGGER fail_settings BEFORE INSERT ON user_settings BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");
        assertThrows(AppFailure.class,()->repo.register("Charlie","Tester","charlie@example.com","5551234567","Testpass1"));
        assertNull(db.accounts().byEmail("charlie@example.com"));
    }
    @Test public void failedSetupRollsBackGoalRecordAndPreferences() {
        db.getOpenHelper().getWritableDatabase().execSQL("CREATE TRIGGER fail_setup BEFORE UPDATE OF onboarding_complete ON user_settings BEGIN SELECT RAISE(ABORT,'synthetic failure'); END");
        assertThrows(AppFailure.class,()->repo.finishSetup(alice,140.0,180.0,"kg","2027-01-01",true));
        Snapshot s=repo.load(alice); assertFalse(s.settings.isOnboardingComplete()); assertTrue(s.records.isEmpty());
        assertFalse(s.settings.isSmsEnabled()); assertEquals(150,s.settings.getGoalWeight(),0); assertEquals(1,report(alice).goals.size());
    }
    @Test public void oneTimeSetupDefaultsAndUnitChangesDoNotChangeMeasurements() {
        repo.finishSetup(alice,null,null,"kg","",false); repo.finishSetup(alice,140.0,180.0,"lbs","2027-01-01",true);
        assertTrue(repo.load(alice).records.isEmpty()); assertEquals("kg",repo.load(alice).settings.getUnit()); assertEquals(150,repo.load(alice).settings.getGoalWeight(),0);
        repo.save(alice,input(-1,"2026-09-20",181.123456789,null));
        repo.updateProfile(alice,"Alicia","Tester","5559876543","lbs");
        assertEquals(181.123456789,repo.load(alice).records.get(0).getWeight(),0); assertEquals("alice@example.com",repo.profile(alice).email);
    }
    @Test public void duplicateDateIsInlineFailureAndDoesNotChangeGoal() {
        repo.save(alice,input(-1,"2026-09-20",175,140.0));
        AppFailure f=assertThrows(AppFailure.class,()->repo.save(alice,input(-1,"2026-09-20",180,130.0)));
        assertEquals(AppFailure.Kind.DUPLICATE_DATE,f.kind); assertEquals("date",f.field);
        assertEquals(175,repo.load(alice).records.get(0).getWeight(),0); assertEquals(140,repo.load(alice).settings.getGoalWeight(),0);
        repo.save(bob,input(-1,"2026-09-20",190,null)); assertEquals(1,report(bob).count);
    }
    @Test public void crossUserUpdateDeleteAndQueriesAreIsolated() {
        long id=repo.save(alice,input(-1,"2026-09-20",175,null));
        assertEquals(AppFailure.Kind.NOT_FOUND,assertThrows(AppFailure.class,()->repo.save(bob,input(id,"2026-09-21",185,null))).kind);
        assertThrows(AppFailure.class,()->repo.delete(bob,id)); assertNull(db.weights().record(bob,id)); assertEquals(0,report(bob).count);
    }
    @Test public void crudAndSqlMetacharactersRemainData() {
        String notes="'); DROP TABLE users; --";
        long id=repo.save(alice,new WeightInput(-1,"2026-09-20",175.25,notes,null));
        assertEquals(notes,repo.load(alice).records.get(0).getNotes());
        repo.save(alice,input(id,"2026-09-21",174.75,null)); assertEquals(174.75,report(alice).average,0);
        repo.delete(alice,id); assertNull(report(alice).latest); assertEquals(alice,repo.signIn(" ALICE@EXAMPLE.COM ","Testpass1"));
    }
    @Test public void passwordChangeAndDeletionRequireReauthenticationAndCascade() {
        assertThrows(AppFailure.class,()->repo.changePassword(alice,"wrong","Updatedpass1"));
        repo.changePassword(alice,"Testpass1","Updatedpass1");
        assertThrows(AppFailure.class,()->repo.signIn("alice@example.com","Testpass1")); assertEquals(alice,repo.signIn("alice@example.com","Updatedpass1"));
        repo.save(alice,input(-1,"2026-09-20",175,null)); repo.updateGoals(alice,140,"");
        assertThrows(AppFailure.class,()->repo.deleteAccount(alice,"wrong"));
        repo.deleteAccount(alice,"Updatedpass1");
        for(String table:new String[]{"weight_records","user_settings","weight_goals"}) assertEquals(0,count(table,alice));
        assertNotNull(repo.profile(bob)); assertThrows(AppFailure.class,()->repo.load(alice));
    }
    @Test public void databaseConstraintsPreventDuplicatesOrphansAndInvalidUnits() {
        Tables.Goal g=new Tables.Goal(); g.user_id=alice; g.goal_weight=140; assertThrows(RuntimeException.class,()->db.goals().insert(g));
        g.user_id=99999; assertThrows(RuntimeException.class,()->db.goals().insert(g));
        assertThrows(RuntimeException.class,()->db.accounts().preferences(alice,"5551234567","stone"));
        repo.save(alice,input(-1,"2026-09-20",175,null));
        Tables.Weight w=new Tables.Weight(); w.user_id=alice; w.entry_date="2026-09-20"; w.weight=175;
        assertThrows(RuntimeException.class,()->db.weights().insert(w));
    }
    @Test public void newWriteLimitsAndCalendarDatesAreEnforcedByRepositoryAndDatabase() {
        for(double value:new double[]{0,-1,701,Double.NaN,Double.POSITIVE_INFINITY})
            assertThrows(AppFailure.class,()->repo.save(alice,input(-1,"2026-09-20",value,null)));
        assertThrows(AppFailure.class,()->repo.updateGoals(alice,701,""));
        Tables.Weight w=new Tables.Weight(); w.user_id=alice; w.entry_date="2026-02-30"; w.weight=175;
        assertThrows(RuntimeException.class,()->db.weights().insert(w));
        w.entry_date="2026-09-20"; w.weight=701; assertThrows(RuntimeException.class,()->db.weights().insert(w));
        repo.save(alice,input(-1,"2026-09-20",700,null)); assertEquals(700,report(alice).average,0);
    }
    @Test public void historicalGoalContentCannotBeRewritten() {
        repo.updateGoals(alice,140,"");
        assertThrows(RuntimeException.class,()->db.getOpenHelper().getWritableDatabase().execSQL("UPDATE weight_goals SET goal_weight=130 WHERE user_id=?",new Object[]{alice}));
        assertEquals(150,report(alice).goals.get(1).weight,0);
    }
    @Test public void repeatedConcurrentGoalUpdatesLeaveOneCurrentGoal() throws Exception {
        ExecutorService pool=Executors.newFixedThreadPool(4);
        try {
            List<Future<?>> futures=new ArrayList<>();
            for(int i=0;i<8;i++) { final double value=140+i; futures.add(pool.submit(()->repo.updateGoals(alice,value,""))); }
            for(Future<?> f:futures) f.get(20,TimeUnit.SECONDS);
        } finally { pool.shutdownNow(); }
        assertEquals(1,report(alice).goals.stream().filter(g->g.active).count()); assertEquals(9,report(alice).goals.size());
    }
    @Test public void indexedRangeAndCurrentGoalQueriesUseSearchPlans() {
        for(String sql:new String[]{"SELECT * FROM weight_records WHERE user_id=1 AND entry_date BETWEEN '2026-01-01' AND '2026-12-31'", "SELECT * FROM weight_goals WHERE user_id=1 AND active_slot=1"}) {
            StringBuilder plan=new StringBuilder();
            try(Cursor c=db.getOpenHelper().getReadableDatabase().query("EXPLAIN QUERY PLAN "+sql)) { while(c.moveToNext()) plan.append(c.getString(3)); }
            assertTrue(plan.toString(),plan.toString().contains("SEARCH")); assertTrue(plan.toString(),plan.toString().contains("INDEX"));
        }
    }
    @Test public void roomRejectsMainThreadDatabaseAccess() {
        java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();
        androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{
            try { db.accounts().user(alice); } catch(Throwable e) { failure.set(e); }
        });
        assertTrue(failure.get() instanceof IllegalStateException);
    }
    @Test public void legacyVersionOneMigratesWithoutChangingCredentialsOrMeasurements() { migration(1); }
    @Test public void legacyVersionTwoMigratesWithoutChangingCredentialsOrMeasurements() { migration(2); }
    @Test public void legacyVersionThreeMigratesAllUiPreferencesAndGoal() { migration(3); }
    private void migration(int version) {
        String n=name(); DatabaseHelper old=new DatabaseHelper(context,n);
        long user=old.createUser("Legacy","Tester","legacy@example.com","5551234567","Testpass1");
        long record=old.insertWeightRecord(user,"2026-09-20",800.123456789,"legacy out-of-range preserved");
        old.updateGoalWeight(user,750); old.updateSmsSettings(user,"5559999999",true); old.setGoalAlertSent(user,true);
        old.preferences(user,"kg","2027-01-01",true);
        String hash,salt,created;
        try(Cursor c=old.getReadableDatabase().rawQuery("SELECT password_hash,password_salt,created_at FROM users WHERE id=?",new String[]{Long.toString(user)})) { c.moveToFirst(); hash=c.getString(0); salt=c.getString(1); created=c.getString(2); }
        SQLiteDatabase sql=old.getWritableDatabase();
        if(version<3) sql.execSQL("DROP TABLE account_preferences");
        if(version==1) for(String col:new String[]{"first_name","last_name","email","phone_number"}) sql.execSQL("ALTER TABLE users DROP COLUMN "+col);
        sql.setVersion(version); old.close();
        WeightDatabase upgraded=open(n); RoomWeightRepository r=new RoomWeightRepository(upgraded);
        assertEquals(user,r.signIn("legacy@example.com","Testpass1")); assertEquals(4,upgraded.getOpenHelper().getReadableDatabase().getVersion());
        assertEquals(hash,upgraded.accounts().user(user).password_hash); assertEquals(salt,upgraded.accounts().user(user).password_salt); assertEquals(created,upgraded.accounts().user(user).created_at);
        assertEquals("legacy@example.com",r.profile(user).email);
        Snapshot s=r.load(user); assertEquals(record,s.records.get(0).getId()); assertEquals(800.123456789,s.records.get(0).getWeight(),0);
        assertEquals(750,s.settings.getGoalWeight(),0); assertTrue(s.settings.isSmsEnabled()); assertTrue(s.settings.isGoalAlertSent()); assertTrue(s.settings.isOnboardingComplete());
        assertEquals("5559999999",s.settings.getPhoneNumber()); assertEquals(version==3?"kg":"lbs",s.settings.getUnit()); assertEquals(version==3?"2027-01-01":"",s.settings.getTargetDate());
        assertEquals(1,r.report(user,"2026-01-01","2026-12-31").goals.size());
        r.updateProfile(user,"Legacy","Tester","5551234567","kg"); assertEquals(800.123456789,r.load(user).records.get(0).getWeight(),0);
        assertThrows(AppFailure.class,()->r.save(user,input(record,"2026-09-20",800.123456789,null)));
        // Migrated databases must install the same guards as fresh databases.
        Tables.Weight invalid=new Tables.Weight(); invalid.user_id=user; invalid.entry_date="2026-09-21"; invalid.weight=701;
        assertThrows(RuntimeException.class,()->upgraded.weights().insert(invalid));
        invalid.weight=175; invalid.entry_date="2026-02-30";
        assertThrows(RuntimeException.class,()->upgraded.weights().insert(invalid));
        r.updateGoals(user,140,""); assertEquals(750,r.report(user,"2026-01-01","2026-12-31").goals.get(1).weight,0);
        upgraded.close(); WeightDatabase reopened=open(n); assertEquals(140,new RoomWeightRepository(reopened).load(user).settings.getGoalWeight(),0);
    }
    @Test public void migrationPreservesDeletedHighWaterMarks() {
        String n=name(); DatabaseHelper old=new DatabaseHelper(context,n);
        long keep=old.createUser("Alive","Tester","keep@example.com","5551234567","Testpass1");
        long removed=old.createUser("Gone","Tester","gone@example.com","5551234567","Testpass1"); old.deleteUser(removed);
        long record=old.insertWeightRecord(keep,"2026-09-20",175,""); old.deleteWeightRecord(record,keep); old.close();
        RoomWeightRepository r=new RoomWeightRepository(open(n));
        assertTrue(r.register("New","Tester","new@example.com","5551234567","Testpass1")>removed);
        assertTrue(r.save(keep,input(-1,"2026-09-20",174,null))>record);
    }
    @Test public void missingSettingsAbortMigrationWithoutDeletingLegacyData() {
        String n=name(); DatabaseHelper old=new DatabaseHelper(context,n);
        long user=old.createUser("Legacy","Tester","legacy@example.com","5551234567","Testpass1");
        old.getWritableDatabase().execSQL("DELETE FROM user_settings WHERE user_id=?",new Object[]{user}); old.close();
        WeightDatabase broken=open(n); assertThrows(RuntimeException.class,()->broken.getOpenHelper().getWritableDatabase()); broken.close();
        try(SQLiteDatabase check=SQLiteDatabase.openDatabase(context.getDatabasePath(n).getPath(),null,SQLiteDatabase.OPEN_READONLY)) {
            assertEquals(3,check.getVersion()); try(Cursor c=check.rawQuery("SELECT COUNT(*) FROM users",null)) { c.moveToFirst(); assertEquals(1,c.getInt(0)); }
        }
    }
}
