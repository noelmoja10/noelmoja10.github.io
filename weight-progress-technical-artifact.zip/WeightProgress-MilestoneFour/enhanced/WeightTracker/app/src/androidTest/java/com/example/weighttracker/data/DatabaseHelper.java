package com.example.weighttracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.weighttracker.model.UserSettings;
import com.example.weighttracker.model.AccountProfile;
import com.example.weighttracker.model.WeightRecord;
import com.example.weighttracker.util.PasswordUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight_progress.db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_SETTINGS = "user_settings";
    private static final String TABLE_WEIGHTS = "weight_records";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /** A separate file lets instrumentation exercise real SQLite without touching user data. */
    public DatabaseHelper(Context context, String databaseName) {
        super(context, databaseName, null, DATABASE_VERSION);
    }

    public boolean userExists(long userId) {
        return exists(TABLE_USERS, "id = ?", new String[]{String.valueOf(userId)});
    }

    public boolean emailExists(String email) {
        return exists(TABLE_USERS, "username = ?", new String[]{normalizeUsername(email)});
    }

    public boolean dateExists(long userId, String date, long exceptId) {
        return exists(TABLE_WEIGHTS, "user_id = ? AND entry_date = ? AND id != ?",
                new String[]{String.valueOf(userId), date, String.valueOf(exceptId)});
    }

    private boolean exists(String table, String selection, String[] args) {
        try (Cursor cursor = getReadableDatabase().query(table, new String[]{"1"},
                selection, args, null, null, null, "1")) {
            return cursor.moveToFirst();
        }
    }

    @Override
    public void onConfigure(SQLiteDatabase database) {
        super.onConfigure(database);
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(
                "CREATE TABLE " + TABLE_USERS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "username TEXT NOT NULL UNIQUE, "
                        + "first_name TEXT NOT NULL DEFAULT '', "
                        + "last_name TEXT NOT NULL DEFAULT '', "
                        + "email TEXT NOT NULL DEFAULT '', "
                        + "phone_number TEXT NOT NULL DEFAULT '', "
                        + "password_hash TEXT NOT NULL, "
                        + "password_salt TEXT NOT NULL, "
                        + "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"
                        + ")");

        database.execSQL(
                "CREATE TABLE " + TABLE_SETTINGS + " ("
                        + "user_id INTEGER PRIMARY KEY, "
                        + "goal_weight REAL NOT NULL DEFAULT 150.0, "
                        + "phone_number TEXT NOT NULL DEFAULT '', "
                        + "sms_enabled INTEGER NOT NULL DEFAULT 0, "
                        + "goal_alert_sent INTEGER NOT NULL DEFAULT 0, "
                        + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id) ON DELETE CASCADE"
                        + ")");

        database.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "user_id INTEGER NOT NULL, "
                        + "entry_date TEXT NOT NULL, "
                        + "weight REAL NOT NULL CHECK(weight > 0), "
                        + "notes TEXT NOT NULL DEFAULT '', "
                        + "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
                        + "FOREIGN KEY(user_id) REFERENCES " + TABLE_USERS + "(id) ON DELETE CASCADE, "
                        + "UNIQUE(user_id, entry_date)"
                        + ")");

        database.execSQL(
                "CREATE INDEX idx_weight_user_date ON " + TABLE_WEIGHTS
                        + "(user_id, entry_date DESC)");
        createPreferences(database);
    }

    private void createPreferences(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE account_preferences (user_id INTEGER PRIMARY KEY, "
                + "weight_unit TEXT NOT NULL DEFAULT 'lbs' CHECK(weight_unit IN ('lbs','kg')), "
                + "target_date TEXT NOT NULL DEFAULT '', onboarding_complete INTEGER NOT NULL DEFAULT 0, "
                + "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN first_name TEXT NOT NULL DEFAULT ''");
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN last_name TEXT NOT NULL DEFAULT ''");
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN email TEXT NOT NULL DEFAULT ''");
            database.execSQL("ALTER TABLE " + TABLE_USERS
                    + " ADD COLUMN phone_number TEXT NOT NULL DEFAULT ''");
            database.execSQL("UPDATE " + TABLE_USERS
                    + " SET email = username WHERE email = ''");
        }
        if (oldVersion < 3) {
            createPreferences(database);
            // Existing accounts keep their data and do not repeat first-time onboarding.
            database.execSQL("INSERT INTO account_preferences(user_id,onboarding_complete) SELECT id,1 FROM users");
        }
    }

    public long createUser(String username, String password) {
        return createUser("", "", username, "", password);
    }

    public long createUser(
            String firstName,
            String lastName,
            String email,
            String phoneNumber,
            String password) {
        String normalizedUsername = normalizeUsername(email);
        String normalizedPhone = phoneNumber == null ? "" : phoneNumber.trim();
        String salt = PasswordUtils.createSalt();
        String hash = PasswordUtils.hashPassword(password, salt);
        SQLiteDatabase database = getWritableDatabase();

        database.beginTransaction();
        try {
            ContentValues userValues = new ContentValues();
            userValues.put("username", normalizedUsername);
            userValues.put("first_name", firstName == null ? "" : firstName.trim());
            userValues.put("last_name", lastName == null ? "" : lastName.trim());
            userValues.put("email", normalizedUsername);
            userValues.put("phone_number", normalizedPhone);
            userValues.put("password_hash", hash);
            userValues.put("password_salt", salt);
            long userId = database.insertOrThrow(TABLE_USERS, null, userValues);

            ContentValues settingsValues = new ContentValues();
            settingsValues.put("user_id", userId);
            settingsValues.put("phone_number", normalizedPhone);
            database.insertOrThrow(TABLE_SETTINGS, null, settingsValues);
            ContentValues preferences = new ContentValues();
            preferences.put("user_id", userId);
            database.insertOrThrow("account_preferences", null, preferences);

            database.setTransactionSuccessful();
            return userId;
        } catch (SQLiteConstraintException exception) {
            return -1L;
        } finally {
            database.endTransaction();
        }
    }

    public long authenticateUser(String username, String password) {
        String[] columns = {"id", "password_hash", "password_salt"};
        String[] arguments = {normalizeUsername(username)};

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                columns,
                "username = ?",
                arguments,
                null,
                null,
                null)) {
            if (!cursor.moveToFirst()) {
                return -1L;
            }

            String hash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow("password_salt"));
            if (!PasswordUtils.verifyPassword(password, salt, hash)) {
                return -1L;
            }
            return cursor.getLong(cursor.getColumnIndexOrThrow("id"));
        }
    }

    public long insertWeightRecord(
            long userId,
            String entryDate,
            double weight,
            String notes) {
        ContentValues values = weightValues(userId, entryDate, weight, notes);
        try {
            return getWritableDatabase().insertOrThrow(TABLE_WEIGHTS, null, values);
        } catch (SQLiteConstraintException exception) {
            return -1L;
        }
    }

    public boolean updateWeightRecord(
            long recordId,
            long userId,
            String entryDate,
            double weight,
            String notes) {
        ContentValues values = weightValues(userId, entryDate, weight, notes);
        try {
            int updated = getWritableDatabase().update(
                    TABLE_WEIGHTS,
                    values,
                    "id = ? AND user_id = ?",
                    new String[]{String.valueOf(recordId), String.valueOf(userId)});
            return updated == 1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public boolean deleteWeightRecord(long recordId, long userId) {
        int deleted = getWritableDatabase().delete(
                TABLE_WEIGHTS,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(recordId), String.valueOf(userId)});
        return deleted == 1;
    }

    public WeightRecord getWeightRecord(long recordId, long userId) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHTS,
                null,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(recordId), String.valueOf(userId)},
                null,
                null,
                null)) {
            return cursor.moveToFirst() ? readWeightRecord(cursor) : null;
        }
    }

    public List<WeightRecord> getWeightRecords(long userId) {
        return getWeightRecords(userId, 0);
    }

    public List<WeightRecord> getWeightRecords(long userId, int limit) {
        List<WeightRecord> records = new ArrayList<>();
        String limitText = limit > 0 ? String.valueOf(limit) : null;

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHTS,
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "entry_date DESC, id DESC",
                limitText)) {
            while (cursor.moveToNext()) {
                records.add(readWeightRecord(cursor));
            }
        }
        return records;
    }

    public UserSettings getUserSettings(long userId) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_SETTINGS,
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null)) {
            if (cursor.moveToFirst()) {
                String unit = "lbs", targetDate = "";
                boolean complete = false;
                try (Cursor preferences = getReadableDatabase().query("account_preferences", null,
                        "user_id = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
                    if (preferences.moveToFirst()) {
                        unit = preferences.getString(preferences.getColumnIndexOrThrow("weight_unit"));
                        targetDate = preferences.getString(preferences.getColumnIndexOrThrow("target_date"));
                        complete = preferences.getInt(preferences.getColumnIndexOrThrow("onboarding_complete")) == 1;
                    }
                }
                return new UserSettings(
                        userId,
                        cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone_number")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("sms_enabled")) == 1,
                        cursor.getInt(cursor.getColumnIndexOrThrow("goal_alert_sent")) == 1,
                        unit, targetDate, complete);
            }
        }

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        getWritableDatabase().insert(TABLE_SETTINGS, null, values);
        return new UserSettings(userId, 150.0, "", false, false);
    }

    public void updateGoalWeight(long userId, double goalWeight) {
        UserSettings settings = getUserSettings(userId);
        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);
        if (Double.compare(settings.getGoalWeight(), goalWeight) != 0) {
            values.put("goal_alert_sent", 0);
        }
        getWritableDatabase().update(
                TABLE_SETTINGS,
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)});
    }

    public void updateSmsSettings(long userId, String phoneNumber, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put("phone_number", phoneNumber == null ? "" : phoneNumber.trim());
        values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update(
                TABLE_SETTINGS,
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)});
    }

    public void setGoalAlertSent(long userId, boolean sent) {
        ContentValues values = new ContentValues();
        values.put("goal_alert_sent", sent ? 1 : 0);
        getWritableDatabase().update(
                TABLE_SETTINGS,
                values,
                "user_id = ?",
                new String[]{String.valueOf(userId)});
    }

    public AccountProfile getProfile(long id) {
        try (Cursor c = getReadableDatabase().query(TABLE_USERS, null, "id = ?",
                new String[]{String.valueOf(id)}, null, null, null)) {
            if (!c.moveToFirst()) return null;
            return new AccountProfile(id, c.getString(c.getColumnIndexOrThrow("first_name")),
                    c.getString(c.getColumnIndexOrThrow("last_name")), c.getString(c.getColumnIndexOrThrow("email")), getUserSettings(id));
        }
    }
    public void updateProfile(long id, String first, String last, String phone, String unit) {
        ContentValues values = new ContentValues();
        values.put("first_name", first); values.put("last_name", last); values.put("phone_number", phone);
        getWritableDatabase().update(TABLE_USERS, values, "id = ?", new String[]{String.valueOf(id)});
        updateSmsSettings(id, phone, getUserSettings(id).isSmsEnabled());
        ContentValues prefs = new ContentValues(); prefs.put("weight_unit", unit);
        getWritableDatabase().update("account_preferences", prefs, "user_id = ?", new String[]{String.valueOf(id)});
    }
    public void preferences(long id, String unit, String date, boolean complete) {
        ContentValues values = new ContentValues();
        values.put("weight_unit", unit); values.put("target_date", date); values.put("onboarding_complete", complete ? 1 : 0);
        getWritableDatabase().update("account_preferences", values, "user_id = ?", new String[]{String.valueOf(id)});
    }
    public void replacePassword(long id, String password) {
        String salt = PasswordUtils.createSalt();
        ContentValues values = new ContentValues();
        values.put("password_salt", salt); values.put("password_hash", PasswordUtils.hashPassword(password, salt));
        getWritableDatabase().update(TABLE_USERS, values, "id = ?", new String[]{String.valueOf(id)});
    }
    public boolean deleteUser(long id) {
        return getWritableDatabase().delete(TABLE_USERS, "id = ?", new String[]{String.valueOf(id)}) == 1;
    }

    private static ContentValues weightValues(
            long userId,
            String entryDate,
            double weight,
            String notes) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", entryDate);
        values.put("weight", weight);
        values.put("notes", notes == null ? "" : notes.trim());
        return values;
    }

    private static WeightRecord readWeightRecord(Cursor cursor) {
        return new WeightRecord(
                cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                cursor.getLong(cursor.getColumnIndexOrThrow("user_id")),
                cursor.getString(cursor.getColumnIndexOrThrow("entry_date")),
                cursor.getDouble(cursor.getColumnIndexOrThrow("weight")),
                cursor.getString(cursor.getColumnIndexOrThrow("notes")));
    }

    private static String normalizeUsername(String username) {
        return username == null ? "" : username.trim().toLowerCase(Locale.US);
    }
}
