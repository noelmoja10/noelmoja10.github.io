package com.example.weighttracker.data;

import android.database.sqlite.SQLiteDatabase;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.model.AccountProfile;
import com.example.weighttracker.model.UserSettings;
import com.example.weighttracker.util.DateUtils;

/** UI preview adapter: additive version-3 preferences; existing measurements remain in pounds. */
public final class SqliteWeightRepository implements WeightRepository {
    private final DatabaseHelper db;
    public SqliteWeightRepository(DatabaseHelper db) { this.db = db; }

    private interface Work<T> { T run(); }
    private <T> T safely(Work<T> work) {
        try { return work.run(); }
        catch (AppFailure failure) { throw failure; }
        catch (RuntimeException failure) { throw AppFailure.storage(); }
    }
    private void requireUser(long userId) {
        Validators.user(userId);
        if (!db.userExists(userId))
            throw new AppFailure(AppFailure.Kind.AUTHENTICATION, "", "Please sign in again");
    }
    @Override public long signIn(String email, String password) {
        return safely(() -> {
            long id = db.authenticateUser(Validators.email(email), Validators.password(password, false));
            if (id < 1) throw new AppFailure(AppFailure.Kind.AUTHENTICATION, "password", "Email or password is incorrect");
            return id;
        });
    }
    @Override public long register(String first, String last, String email, String phone, String password) {
        return safely(() -> {
            String normalized = Validators.email(email);
            if (db.emailExists(normalized)) throw new AppFailure(AppFailure.Kind.DUPLICATE_EMAIL, "email", "An account already exists for this email");
            long id = db.createUser(Validators.name(first, "first"), Validators.name(last, "last"),
                    normalized, Validators.phone(phone), Validators.password(password, true));
            if (id < 1) throw AppFailure.storage();
            return id;
        });
    }
    @Override public Snapshot load(long userId) {
        return safely(() -> {
            requireUser(userId);
            return new Snapshot(db.getWeightRecords(userId), db.getUserSettings(userId));
        });
    }
    @Override public long save(long userId, WeightInput input) {
        return safely(() -> {
            requireUser(userId);
            String date = Validators.date(input.date);
            double weight = Validators.weight(Double.toString(input.weight), "weight");
            String notes = Validators.notes(input.notes);
            if (input.goal != null) Validators.weight(Double.toString(input.goal), "goal");
            SQLiteDatabase database = db.getWritableDatabase();
            database.beginTransaction();
            try {
                if (input.recordId != -1 && db.getWeightRecord(input.recordId, userId) == null)
                    throw new AppFailure(AppFailure.Kind.NOT_FOUND, "", "This weight record no longer exists");
                if (db.dateExists(userId, date, input.recordId))
                    throw new AppFailure(AppFailure.Kind.DUPLICATE_DATE, "date", "A record already exists for this date. Edit it in History.");
                long id = input.recordId;
                if (id == -1) id = db.insertWeightRecord(userId, date, weight, notes);
                else if (!db.updateWeightRecord(id, userId, date, weight, notes)) throw AppFailure.storage();
                if (id < 1) throw AppFailure.storage();
                // One logical save must not leave a changed measurement with an unchanged requested goal.
                if (input.goal != null) db.updateGoalWeight(userId, input.goal);
                database.setTransactionSuccessful();
                return id;
            } finally { database.endTransaction(); }
        });
    }
    @Override public void delete(long userId, long recordId) {
        safely(() -> {
            requireUser(userId);
            if (!db.deleteWeightRecord(recordId, userId))
                throw new AppFailure(AppFailure.Kind.NOT_FOUND, "", "This weight record no longer exists");
            return null;
        });
    }
    @Override public void smsSettings(long userId, String phone, boolean enabled) {
        safely(() -> {
            requireUser(userId);
            db.updateSmsSettings(userId, enabled ? Validators.phone(phone) : Validators.text(phone).trim(), enabled);
            return null;
        });
    }
    @Override public void alertRequested(long userId, boolean requested) {
        safely(() -> { requireUser(userId); db.setGoalAlertSent(userId, requested); return null; });
    }
    private void transaction(Runnable operation) {
        SQLiteDatabase database = db.getWritableDatabase(); database.beginTransaction();
        try { operation.run(); database.setTransactionSuccessful(); }
        finally { database.endTransaction(); }
    }
    private String optionalDate(String date) { return Validators.text(date).trim().isEmpty() ? "" : Validators.date(date); }
    private double pounds(double value) { return Validators.weight(Double.toString(value), "goal"); }
    @Override public AccountProfile profile(long user) {
        return safely(() -> { requireUser(user); return db.getProfile(user); });
    }
    @Override public void updateProfile(long user, String first, String last, String phone, String unit) {
        safely(() -> {
            requireUser(user);
            String f = Validators.name(first, "first"), l = Validators.name(last, "last"), p = Validators.phone(phone);
            WeightUnits.of(unit);
            transaction(() -> db.updateProfile(user, f, l, p, unit)); return null;
        });
    }
    @Override public void finishSetup(long user, Double goal, Double current, String unit, String targetDate, boolean sms) {
        safely(() -> {
            requireUser(user); WeightUnits.of(unit);
            double target = goal == null ? 150 : pounds(goal);
            if (current != null) Validators.weight(Double.toString(current), "weight");
            String date = optionalDate(targetDate);
            transaction(() -> {
                UserSettings settings = db.getUserSettings(user);
                if (settings.isOnboardingComplete()) return; // Retried completion cannot create another entry.
                if (sms) Validators.phone(settings.getPhoneNumber());
                if (current != null && db.insertWeightRecord(user, DateUtils.todayIso(), current, "Initial weigh-in") < 1)
                    throw AppFailure.invalid("weight", "An entry already exists for today. Edit it in History.");
                db.updateGoalWeight(user, target);
                db.updateSmsSettings(user, settings.getPhoneNumber(), sms);
                db.preferences(user, unit, date, true);
            }); return null;
        });
    }
    @Override public void updateGoals(long user, double goal, String targetDate) {
        safely(() -> {
            requireUser(user); pounds(goal); String date = optionalDate(targetDate);
            transaction(() -> {
                UserSettings settings = db.getUserSettings(user);
                db.updateGoalWeight(user, goal);
                db.preferences(user, settings.getUnit(), date, settings.isOnboardingComplete());
            }); return null;
        });
    }
    private void reauthenticate(long user, String password) {
        requireUser(user); Validators.password(password, false);
        if (db.authenticateUser(db.getProfile(user).email, password) != user)
            throw AppFailure.invalid("currentPassword", "Current password is incorrect");
    }
    @Override public void changePassword(long user, String currentPassword, String newPassword) {
        safely(() -> { reauthenticate(user, currentPassword); db.replacePassword(user, Validators.password(newPassword, true)); return null; });
    }
    @Override public void deleteAccount(long user, String currentPassword) {
        safely(() -> {
            reauthenticate(user, currentPassword);
            transaction(() -> { if (!db.deleteUser(user)) throw AppFailure.storage(); });
            return null;
        });
    }
}
