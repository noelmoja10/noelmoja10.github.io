package com.example.weighttracker;

import android.content.Context;
import android.database.Cursor;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.example.weighttracker.data.*;
import com.example.weighttracker.domain.*;
import java.util.UUID;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class RepositoryInstrumentedTest {
    private Context context;
    private String name;
    private DatabaseHelper helper;
    private WeightRepository repo;
    private long alice, bob;
    @Before public void setup() {
        context = ApplicationProvider.getApplicationContext();
        name = "repository-test-" + UUID.randomUUID() + ".db";
        helper = new DatabaseHelper(context, name); repo = new SqliteWeightRepository(helper);
        alice = repo.register("Alice", "Tester", "alice@example.com", "5551234567", "Testpass1");
        bob = repo.register("Bobby", "Tester", "bob@example.com", "5551234568", "Testpass2");
    }
    @After public void cleanup() { helper.close(); context.deleteDatabase(name); }
    private WeightInput input(long id, String date, double weight, Double goal) { return new WeightInput(id, date, weight, "synthetic QA record", goal); }
    @Test public void authenticationAndPasswordHashRemainCompatible() {
        assertEquals(alice, repo.signIn(" ALICE@EXAMPLE.COM ", "Testpass1"));
        assertEquals(AppFailure.Kind.AUTHENTICATION, assertThrows(AppFailure.class, () -> repo.signIn("alice@example.com", "wrong")).kind);
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT password_hash, password_salt FROM users WHERE id=?", new String[]{Long.toString(alice)})) {
            assertTrue(c.moveToFirst()); assertNotEquals("Testpass1", c.getString(0)); assertFalse(c.getString(1).isEmpty());
        }
    }
    @Test public void duplicateEmailIsDistinctFromStorageError() {
        assertEquals(AppFailure.Kind.DUPLICATE_EMAIL, assertThrows(AppFailure.class,
                () -> repo.register("Alice", "Tester", "alice@example.com", "5551234567", "Testpass1")).kind);
    }
    @Test public void duplicateDateDoesNotChangeExistingGoalOrRecord() {
        repo.save(alice, input(-1, "2026-09-18", 181.26, 150.25));
        assertEquals(AppFailure.Kind.DUPLICATE_DATE, assertThrows(AppFailure.class,
                () -> repo.save(alice, input(-1, "2026-09-18", 190, 140.0))).kind);
        assertEquals(1, repo.load(alice).records.size()); assertEquals(150.25, repo.load(alice).settings.getGoalWeight(), 0);
    }
    @Test public void crossUserReadUpdateAndDeleteAreIsolated() {
        long id = repo.save(alice, input(-1, "2026-09-18", 181.26, null));
        assertTrue(repo.load(bob).records.isEmpty());
        assertEquals(AppFailure.Kind.NOT_FOUND, assertThrows(AppFailure.class,
                () -> repo.save(bob, input(id, "2026-09-18", 190, null))).kind);
        assertThrows(AppFailure.class, () -> repo.delete(bob, id));
        assertEquals(181.26, repo.load(alice).records.get(0).getWeight(), 0);
    }
    @Test public void sameDateIsAllowedForDifferentUsers() {
        repo.save(alice, input(-1, "2026-09-18", 181, null)); repo.save(bob, input(-1, "2026-09-18", 191, null));
        assertEquals(1, repo.load(alice).records.size()); assertEquals(1, repo.load(bob).records.size());
    }
    @Test public void failedGoalWriteRollsBackMeasurement() {
        helper.getWritableDatabase().execSQL("CREATE TRIGGER fail_goal BEFORE UPDATE OF goal_weight ON user_settings BEGIN SELECT RAISE(ABORT, 'test storage failure'); END");
        assertEquals(AppFailure.Kind.STORAGE, assertThrows(AppFailure.class,
                () -> repo.save(alice, input(-1, "2026-09-18", 181.26, 140.0))).kind);
        assertTrue(repo.load(alice).records.isEmpty()); assertEquals(150, repo.load(alice).settings.getGoalWeight(), 0);
    }
    @Test public void notesOnlyEditPreservesDecimalAndCrudWorks() {
        long id = repo.save(alice, input(-1, "2026-09-18", 181.26, 150.25));
        repo.save(alice, new WeightInput(id, "2026-09-18", 181.26, "updated note", 150.25));
        assertEquals(181.26, repo.load(alice).records.get(0).getWeight(), 0);
        assertEquals("updated note", repo.load(alice).records.get(0).getNotes());
        repo.delete(alice, id); assertTrue(repo.load(alice).records.isEmpty());
    }
    @Test public void versionTwoDataSurvivesAdapterReopen() {
        long id = helper.insertWeightRecord(alice, "2026-09-18", 181.26, "legacy helper record");
        helper.updateGoalWeight(alice, 150.25);
        // Remove only the new table in this synthetic test DB to reconstruct the exact v2 schema.
        helper.getWritableDatabase().execSQL("DROP TABLE account_preferences"); helper.getWritableDatabase().setVersion(2); helper.close();
        helper = new DatabaseHelper(context, name); repo = new SqliteWeightRepository(helper);
        assertEquals(3, helper.getReadableDatabase().getVersion());
        assertTrue(repo.load(alice).settings.isOnboardingComplete()); assertEquals("lbs",repo.load(alice).settings.getUnit());
        assertEquals(alice, repo.signIn("alice@example.com", "Testpass1"));
        assertEquals(id, repo.load(alice).records.get(0).getId()); assertEquals(150.25, repo.load(alice).settings.getGoalWeight(), 0);
    }
    @Test public void nonFiniteValuesAndInvalidUsersCannotPersist() {
        assertThrows(AppFailure.class, () -> repo.save(alice, input(-1, "2026-09-18", Double.NaN, null)));
        assertThrows(AppFailure.class, () -> repo.save(99999, input(-1, "2026-09-18", 180, null)));
        assertTrue(repo.load(alice).records.isEmpty());
    }
    @Test public void revisedLimitAppliesToNewWeightsGoalsAndSetup() {
        assertThrows(AppFailure.class,() -> repo.save(alice,input(-1,"2026-09-25",701,null)));
        assertThrows(AppFailure.class,() -> repo.updateGoals(alice,701,""));
        assertThrows(AppFailure.class,() -> repo.finishSetup(bob,150.0,701.0,"lbs","",false));
        assertTrue(repo.load(alice).records.isEmpty()); assertFalse(repo.load(bob).settings.isOnboardingComplete());
        repo.save(alice,input(-1,"2026-09-25",700,null)); assertEquals(700,repo.load(alice).records.get(0).getWeight(),0);
    }
    @Test public void legacyReadAndUnitChangeDoNotRewriteOutOfRangeSavedWeight() {
        long id = helper.insertWeightRecord(alice,"2026-09-25",800,"legacy");
        repo.updateProfile(alice,"Alice","Tester","5551234567","kg");
        assertEquals(800,repo.load(alice).records.get(0).getWeight(),0);
        assertEquals(id,repo.load(alice).records.get(0).getId());
        assertThrows(AppFailure.class,() -> repo.save(alice,input(id,"2026-09-25",800,null)));
        assertEquals(800,repo.load(alice).records.get(0).getWeight(),0);
    }
    @Test public void notesAreStoredAsDataNotSql() {
        String note = "'); DROP TABLE users; --";
        repo.save(alice, new WeightInput(-1, "2026-09-18", 180, note, null));
        assertEquals(note, repo.load(alice).records.get(0).getNotes());
        assertEquals(alice, repo.signIn("alice@example.com", "Testpass1"));
    }
    @Test public void optionalSetupUsesDefaultsAndCompletesOnlyOnce() {
        assertFalse(repo.load(alice).settings.isOnboardingComplete());
        repo.finishSetup(alice,null,null,"kg","",false);
        Snapshot s = repo.load(alice); assertEquals(150,s.settings.getGoalWeight(),0); assertEquals("",s.settings.getTargetDate()); assertEquals("kg",s.settings.getUnit()); assertTrue(s.records.isEmpty()); assertTrue(s.settings.isOnboardingComplete());
        repo.finishSetup(alice,120.0,180.0,"lbs","2027-01-01",true);
        assertTrue(repo.load(alice).records.isEmpty()); assertEquals(150,repo.load(alice).settings.getGoalWeight(),0);
    }
    @Test public void initialWeightGoalAndPreferencesSaveTogether() {
        repo.finishSetup(alice,140.0,180.25,"kg","2027-01-01",true);
        Snapshot s = repo.load(alice); assertEquals(180.25,s.records.get(0).getWeight(),0); assertEquals(140,s.settings.getGoalWeight(),0); assertTrue(s.settings.isSmsEnabled()); assertEquals("2027-01-01",s.settings.getTargetDate());
        repo.updateGoals(alice,145,""); assertEquals("",repo.load(alice).settings.getTargetDate()); assertEquals("kg",repo.load(alice).settings.getUnit());
    }
    @Test public void preferenceChangeDoesNotMutateWeightOrEmail() {
        repo.save(alice,input(-1,"2026-09-18",181.123456789,null));
        repo.updateProfile(alice,"Alicia","Testerson","5559876543","kg");
        assertEquals("alice@example.com",repo.profile(alice).email); assertEquals("Alicia",repo.profile(alice).first); assertEquals("5559876543",repo.profile(alice).settings.getPhoneNumber());
        assertEquals(181.123456789,repo.load(alice).records.get(0).getWeight(),0); assertEquals(150,repo.load(alice).settings.getGoalWeight(),0);
    }
    @Test public void passwordChangesRequireCurrentPassword() {
        assertThrows(AppFailure.class,() -> repo.changePassword(alice,"wrong","Updatedpass1"));
        assertEquals(alice,repo.signIn("alice@example.com","Testpass1"));
        repo.changePassword(alice,"Testpass1","Updatedpass1");
        assertThrows(AppFailure.class,() -> repo.signIn("alice@example.com","Testpass1")); assertEquals(alice,repo.signIn("alice@example.com","Updatedpass1"));
    }
    @Test public void deletionRequiresPasswordAndCascadesOnlyThatAccount() {
        repo.save(alice,input(-1,"2026-09-18",181,null)); repo.save(bob,input(-1,"2026-09-18",191,null));
        assertThrows(AppFailure.class,() -> repo.deleteAccount(alice,"wrong")); assertEquals(1,repo.load(alice).records.size());
        repo.deleteAccount(alice,"Testpass1"); assertFalse(helper.userExists(alice)); assertEquals(1,repo.load(bob).records.size());
        for (String table : new String[]{"weight_records","user_settings","account_preferences"}) try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table + " WHERE user_id=?",new String[]{Long.toString(alice)})) { assertTrue(c.moveToFirst()); assertEquals(0,c.getInt(0)); }
        assertThrows(AppFailure.class,() -> repo.signIn("alice@example.com","Testpass1"));
    }
    @Test public void failedSetupRollsBackAllChanges() {
        helper.getWritableDatabase().execSQL("CREATE TRIGGER fail_preferences BEFORE UPDATE ON account_preferences BEGIN SELECT RAISE(ABORT, 'synthetic failure'); END");
        assertThrows(AppFailure.class,() -> repo.finishSetup(alice,140.0,180.0,"kg","2027-01-01",true));
        Snapshot s = repo.load(alice); assertFalse(s.settings.isOnboardingComplete()); assertTrue(s.records.isEmpty()); assertEquals(150,s.settings.getGoalWeight(),0); assertFalse(s.settings.isSmsEnabled());
    }
}
