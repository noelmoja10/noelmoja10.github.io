package com.example.weighttracker.domain;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Storage stays in pounds. Changing the display preference never rewrites measurements. */
public enum WeightUnits {
    LBS("lbs", 1.0), KG("kg", 0.45359237);
    public final String label;
    private final double factor;
    WeightUnits(String label, double factor) { this.label = label; this.factor = factor; }
    public double fromPounds(double pounds) { return pounds * factor; }
    public double toPounds(double value) { return value / factor; }
    public String display(double pounds) { return WeightDisplay.display(fromPounds(pounds)); }
    public String input(double pounds) {
        if (this == LBS) return WeightDisplay.editable(pounds);
        return BigDecimal.valueOf(fromPounds(pounds)).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }
    public double parse(String text, String field) {
        if (Validators.text(text).trim().isEmpty()) throw AppFailure.invalid(field, "Enter a weight to continue");
        try {
            double value = Double.parseDouble(Validators.text(text).trim());
            double pounds = toPounds(value);
            // Six-decimal kg edit values may differ from the original by a fraction of a micro-pound.
            if (Double.isFinite(pounds) && pounds > 0 && pounds <= WeightPolicy.MAX_ENTRY_LBS + 0.000001)
                return Math.min(WeightPolicy.MAX_ENTRY_LBS, pounds);
        } catch (NumberFormatException ignored) { }
        throw AppFailure.invalid(field, "Enter a weight above 0 and up to " + display(WeightPolicy.MAX_ENTRY_LBS)
                + " " + label + (this == KG ? " (700 lbs)" : ""));
    }
    public static WeightUnits of(String value) {
        if ("lbs".equals(value)) return LBS;
        if ("kg".equals(value)) return KG;
        throw AppFailure.invalid("unit", "Choose lbs or kg");
    }
}
