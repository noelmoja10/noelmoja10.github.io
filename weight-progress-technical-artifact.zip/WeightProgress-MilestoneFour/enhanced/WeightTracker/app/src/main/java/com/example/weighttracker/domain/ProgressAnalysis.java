package com.example.weighttracker.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable, unit-independent analytics. Weights and slopes use the storage unit, pounds. */
public final class ProgressAnalysis {
    public enum Status {
        NO_DATA, INVALID_DATA, LIMIT_EXCEEDED, INSUFFICIENT_DATA, GOAL_REACHED,
        FLAT_TREND, MOVING_AWAY, STALE_DATA, OUT_OF_RANGE, PAST_PROJECTION, ESTIMATED
    }
    public static final class Point {
        public final LocalDate date;
        public final double weight, movingAverage;
        public final int samples;
        public Point(LocalDate date, double weight, double movingAverage, int samples) {
            this.date = date; this.weight = weight; this.movingAverage = movingAverage; this.samples = samples;
        }
    }
    public final List<Point> points;
    public final int windowSize;
    public final Status status;
    public final Double poundsPerDay;
    public final LocalDate projectedDate;

    ProgressAnalysis(List<Point> points, int windowSize, Status status, Double slope, LocalDate projection) {
        this.points = Collections.unmodifiableList(new ArrayList<>(points));
        this.windowSize = windowSize; this.status = status;
        this.poundsPerDay = slope; this.projectedDate = projection;
    }
    public Point latest() { return points.isEmpty() ? null : points.get(points.size() - 1); }
}
