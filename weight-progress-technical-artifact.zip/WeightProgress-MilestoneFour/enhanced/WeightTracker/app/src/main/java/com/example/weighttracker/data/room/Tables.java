package com.example.weighttracker.data.room;

import androidx.annotation.NonNull;
import androidx.room.*;

/** Persistence-only records. Domain objects never expose password material. */
public final class Tables {
    private Tables() { }
    @Entity(tableName="users", indices=@Index(value="username", unique=true))
    public static class User {
        @PrimaryKey(autoGenerate=true) public long id;
        @NonNull public String username = "";
        @NonNull public String first_name = "";
        @NonNull public String last_name = "";
        @NonNull public String email = "";
        // Preserved profile contact; settings.phone_number is the SMS destination.
        @NonNull public String phone_number = "";
        @NonNull public String password_hash = "";
        @NonNull public String password_salt = "";
        @NonNull public String created_at = "";
    }
    @Entity(tableName="user_settings", foreignKeys=@ForeignKey(entity=User.class,
            parentColumns="id", childColumns="user_id", onDelete=ForeignKey.CASCADE))
    public static class Settings {
        @PrimaryKey public long user_id;
        @NonNull public String phone_number = "";
        public boolean sms_enabled;
        public boolean goal_alert_sent;
        @NonNull public String weight_unit = "lbs";
        public boolean onboarding_complete;
    }
    @Entity(tableName="weight_records", foreignKeys=@ForeignKey(entity=User.class,
            parentColumns="id", childColumns="user_id", onDelete=ForeignKey.CASCADE),
            indices=@Index(value={"user_id", "entry_date"}, unique=true))
    public static class Weight {
        @PrimaryKey(autoGenerate=true) public long id;
        public long user_id;
        @NonNull public String entry_date = "";
        public double weight;
        @NonNull public String notes = "";
        @NonNull public String created_at = "";
    }
    @Entity(tableName="weight_goals", foreignKeys=@ForeignKey(entity=User.class,
            parentColumns="id", childColumns="user_id", onDelete=ForeignKey.CASCADE),
            indices={@Index(value={"user_id","active_slot"}, unique=true), @Index(value={"user_id","id"})})
    public static class Goal {
        @PrimaryKey(autoGenerate=true) public long id;
        public long user_id;
        public double goal_weight;
        @NonNull public String target_date = "";
        @NonNull public String created_at = "";
        // 1 = current; NULL = historical. SQLite permits multiple NULLs in a unique index.
        public Integer active_slot = 1;
    }
    public static class Stats {
        public long count;
        public Double minimum;
        public Double maximum;
        public Double average;
    }
}
