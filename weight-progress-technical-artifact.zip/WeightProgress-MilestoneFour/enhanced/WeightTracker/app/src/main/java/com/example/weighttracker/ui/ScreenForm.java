package com.example.weighttracker.ui;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.example.weighttracker.R;

/** Small shared visual vocabulary for the profile and goal forms. */
final class ScreenForm {
    final ScrollView root;
    final LinearLayout body;
    private final LinearLayout header;
    private final Context context;
    ScreenForm(Context context, String title, String subtitle) {
        this.context = context; root = new ScrollView(context); root.setFillViewport(true);
        root.setBackgroundColor(context.getColor(R.color.surface_soft));
        LinearLayout page = new LinearLayout(context); page.setOrientation(LinearLayout.VERTICAL); root.addView(page);
        header = new LinearLayout(context); header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(24),dp(28),dp(24),dp(28)); header.setBackgroundColor(context.getColor(R.color.brand_dark));
        TextView heading = label(title, 30); heading.setTextColor(Color.WHITE); header.addView(heading);
        TextView description = label(subtitle, 15); description.setTextColor(Color.rgb(221,235,232)); description.setPadding(0,dp(10),0,0); header.addView(description);
        page.addView(header);
        body = new LinearLayout(context); body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22),dp(24),dp(22),dp(28)); body.setBackgroundResource(R.drawable.panel_surface);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin = dp(14); page.addView(body,p);
    }
    int dp(int value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }
    TextView label(String text, int size) {
        TextView view = new TextView(context); view.setText(text); view.setTextSize(size); view.setTextColor(context.getColor(R.color.ink)); return view;
    }
    TextView text(String text) { TextView view = label(text,16); body.addView(view); return view; }
    void back(String description, Runnable action) {
        Button back = new Button(context); back.setId(R.id.pageBackButton); back.setText("Back");
        back.setAllCaps(false); back.setTextSize(16); back.setTextColor(Color.WHITE); back.setContentDescription(description);
        back.setBackgroundColor(Color.TRANSPARENT); back.setPadding(0,0,dp(12),0);
        back.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_back_white,0,0,0); back.setCompoundDrawablePadding(dp(6));
        back.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(92),dp(48)); p.bottomMargin = dp(8);
        header.addView(back,0,p);
    }
    EditText input(String label, int id, int type, String hint) {
        if (!label.isEmpty()) { TextView caption = label(label,15); caption.setPadding(0,dp(16),0,dp(8)); caption.setLabelFor(id); body.addView(caption); }
        EditText edit = new EditText(context); edit.setId(id);
        // setSingleLine can replace a password transformation; apply inputType afterward.
        edit.setSingleLine(type != (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE)); edit.setInputType(type);
        edit.setTypeface(context.getResources().getFont(R.font.inter_regular));
        edit.setTextSize(16); edit.setHint(hint); edit.setPadding(dp(14),0,dp(14),0); edit.setBackgroundResource(R.drawable.edit_text_bg);
        body.addView(edit,new LinearLayout.LayoutParams(-1,dp(type == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE) ? 88 : 56)));
        return edit;
    }
    Button button(String text, int id, boolean secondary, Runnable action) {
        Button button = new Button(context); button.setId(id); button.setText(text); button.setTextSize(16); button.setAllCaps(false);
        button.setBackgroundResource(secondary ? R.drawable.button_secondary : R.drawable.button_primary);
        button.setTextColor(context.getColor(secondary ? R.color.brand : R.color.white));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(54)); p.topMargin = dp(18); body.addView(button,p);
        button.setOnClickListener(v -> action.run()); return button;
    }
    Spinner units(int id) {
        TextView caption = label("Weight units",15); caption.setPadding(0,dp(16),0,dp(8)); caption.setLabelFor(id); body.addView(caption);
        ChoiceSpinner spinner = new ChoiceSpinner(context); spinner.setId(id);
        spinner.options(new String[]{"Pounds (lbs)","Kilograms (kg)"});
        body.addView(spinner,new LinearLayout.LayoutParams(dp(208),-2)); return spinner;
    }
}
