package com.example.weighttracker.presentation;

import com.example.weighttracker.domain.*;
import com.example.weighttracker.model.AccountProfile;
import java.util.concurrent.Executor;

/** Profile mutations remain off the UI thread; success events contain no credentials. */
public final class AccountViewModel extends TaskViewModel<AccountProfile> {
    public AccountViewModel(WeightRepository r, Session s, Executor w, Executor m) { super(r,s,w,m); }
    public void refresh() { long user = session.userId(); execute(() -> result(repository.profile(user), "", false)); }
    private void change(Runnable write, String message, boolean removed) {
        AccountProfile previous = state.getValue().data;
        long user = session.userId();
        execute(() -> {
            write.run(); AccountProfile updated = previous;
            if (!removed) try { updated = repository.profile(user); } catch (RuntimeException ignored) { }
            return result(updated, message, true);
        });
    }
    public void profile(String first, String last, String phone, String unit) {
        long user = session.userId(); change(() -> repository.updateProfile(user, first, last, phone, unit), "Profile saved", false);
    }
    public void goals(double pounds, String date) {
        long user = session.userId(); change(() -> repository.updateGoals(user, pounds, date), "Goals saved", false);
    }
    public void setup(Double goal, Double current, String unit, String date, boolean sms) {
        long user = session.userId(); change(() -> repository.finishSetup(user, goal, current, unit, date, sms), "You’re ready to go", false);
    }
    public void password(String current, String updated, String confirmation) {
        if (!updated.equals(confirmation)) { error(AppFailure.invalid("confirmation", "Password doesn’t match")); return; }
        long user = session.userId(); change(() -> repository.changePassword(user, current, updated), "Password changed", false);
    }
    public void remove(String password) {
        long user = session.userId(); change(() -> repository.deleteAccount(user, password), "Account deleted", true);
    }
}
