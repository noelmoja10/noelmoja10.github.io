package com.example.weighttracker.domain;

import com.example.weighttracker.util.DateUtils;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/** Presentation strings are separated from numeric computation; conversion never rewrites data. */
public final class TrendDisplay {
    public final String average, trend, projection, context;
    public TrendDisplay(ProgressAnalysis result, WeightUnits unit) {
        ProgressAnalysis.Point last = result.latest();
        average = last == null ? "—" : unit.display(last.movingAverage) + " " + unit.label;
        if (result.poundsPerDay == null) trend = "Not enough data";
        else {
            double rate = unit.fromPounds(result.poundsPerDay);
            trend = Math.abs(rate) < 0.005 ? "Less than 0.01 " + unit.label + "/day"
                    : String.format(Locale.US, "%+.2f %s/day", rate, unit.label);
        }
        switch (result.status) {
            case NO_DATA: projection = "Add your first entry to begin."; break;
            case INVALID_DATA: projection = "Trend unavailable. Check History for invalid, duplicate, or future dates and weights."; break;
            case LIMIT_EXCEEDED: projection = "This history exceeds the analytics limit of 100,000 entries."; break;
            case INSUFFICIENT_DATA: projection = "Add at least 3 entries spanning 7 days for a goal estimate."; break;
            case GOAL_REACHED: projection = "Your latest entry meets your weight-loss goal."; break;
            case FLAT_TREND: projection = "No goal date estimated: your weight trend is flat."; break;
            case MOVING_AWAY: projection = "No goal date estimated: the trend is not moving toward your weight-loss goal."; break;
            case STALE_DATA: projection = "Add a recent entry: the latest measurement is more than 30 days old."; break;
            case OUT_OF_RANGE: projection = "No goal date shown: the estimate is outside the 1-year display range."; break;
            case PAST_PROJECTION: projection = "The previous estimate is in the past. Add a recent entry to reassess."; break;
            case ESTIMATED: projection = "Estimated goal date · " + DateUtils.formatForDisplay(result.projectedDate.toString()); break;
            default: throw new IllegalStateException("Unrecognized analytics status");
        }
        context = last == null ? "Only valid entries from your account are analyzed."
                : "Average: latest " + last.samples + " of up to " + result.windowSize + " entries (not days).\n"
                + "Trend: " + result.points.size() + " entries over "
                + ChronoUnit.DAYS.between(result.points.get(0).date, last.date) + " days. Latest: "
                + DateUtils.formatForDisplay(last.date.toString()) + ".";
    }
}
