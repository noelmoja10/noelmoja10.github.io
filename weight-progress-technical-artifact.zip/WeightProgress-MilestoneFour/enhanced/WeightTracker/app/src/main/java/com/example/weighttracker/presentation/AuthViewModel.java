package com.example.weighttracker.presentation;

import com.example.weighttracker.domain.*;
import java.util.concurrent.Executor;

public final class AuthViewModel extends TaskViewModel<Long> {
    private boolean setupRequired;
    public AuthViewModel(WeightRepository repo, Session session, Executor worker, Executor main) { super(repo, session, worker, main); }
    @Override protected void accepted(Long userId) { session.signIn(userId); session.requireSetup(setupRequired); }
    public void signIn(String email, String password) {
        if (busy()) return;
        try {
            String normalized = Validators.email(email);
            String validPassword = Validators.password(password, false);
            execute(() -> {
                long id = repository.signIn(normalized, validPassword);
                setupRequired = !repository.load(id).settings.isOnboardingComplete();
                return result(id, "Signed in", true);
            });
        } catch (AppFailure failure) { error(failure); }
    }
    public void register(String first, String last, String email, String phone, String password, String confirmation) {
        if (busy()) return;
        try {
            String f = Validators.name(first, "first"), l = Validators.name(last, "last");
            String e = Validators.email(email), p = Validators.phone(phone);
            String secret = Validators.password(password, true);
            if (!secret.equals(confirmation)) throw AppFailure.invalid("confirmation", "Password doesn’t match");
            execute(() -> {
                long id = repository.register(f, l, e, p, secret); setupRequired = true;
                return result(id, "Account created", true);
            });
        } catch (AppFailure failure) { error(failure); }
    }
}
