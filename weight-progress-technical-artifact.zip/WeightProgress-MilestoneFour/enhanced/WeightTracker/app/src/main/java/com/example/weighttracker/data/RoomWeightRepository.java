package com.example.weighttracker.data;

import android.database.sqlite.SQLiteConstraintException;
import com.example.weighttracker.data.room.*;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.model.*;
import com.example.weighttracker.util.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.Callable;

/** Blocking Room adapter. Every multi-query operation has one consistent transaction. */
public final class RoomWeightRepository implements WeightRepository {
    private final WeightDatabase db;
    private final AccountDao accounts;
    private final WeightDao weights;
    private final GoalDao goals;
    public RoomWeightRepository(WeightDatabase db) {
        this.db=db; accounts=db.accounts(); weights=db.weights(); goals=db.goals();
    }
    private <T> T safely(Callable<T> work) {
        try { return work.call(); }
        catch(AppFailure failure) { throw failure; }
        catch(Exception failure) { throw AppFailure.storage(); } // Never expose SQL, hashes, or PII.
    }
    private <T> T tx(Callable<T> work) { return safely(() -> db.runInTransaction(work)); }
    private Tables.User requireUser(long id) {
        Validators.user(id); Tables.User u=accounts.user(id);
        if(u==null) throw new AppFailure(AppFailure.Kind.AUTHENTICATION,"","Please sign in again");
        return u;
    }
    private Tables.Settings settings(long user) {
        Tables.Settings s=accounts.settings(user); if(s==null) throw AppFailure.storage(); return s;
    }
    private Tables.Goal active(long user) {
        Tables.Goal g=goals.active(user); if(g==null) throw AppFailure.storage(); return g;
    }
    private UserSettings domainSettings(long user) {
        Tables.Settings s=settings(user); Tables.Goal g=active(user);
        return new UserSettings(user,g.goal_weight,s.phone_number,s.sms_enabled,s.goal_alert_sent,s.weight_unit,g.target_date,s.onboarding_complete);
    }
    private static WeightRecord domain(Tables.Weight w) {
        return w==null?null:new WeightRecord(w.id,w.user_id,w.entry_date,w.weight,w.notes);
    }
    private static List<WeightRecord> domain(List<Tables.Weight> rows) {
        List<WeightRecord> list=new ArrayList<>(); for(Tables.Weight w:rows) list.add(domain(w)); return list;
    }
    private String optionalDate(String date) { return Validators.text(date).trim().isEmpty()?"":Validators.date(date); }
    private void changed(int rows) { if(rows!=1) throw AppFailure.storage(); }
    private void addGoal(long user,double value,String targetDate) {
        Tables.Goal g=new Tables.Goal(); g.user_id=user; g.goal_weight=value; g.target_date=targetDate; g.created_at=Instant.now().toString(); goals.insert(g);
    }
    private void replaceGoal(long user,double value,String targetDate) {
        Tables.Goal prior=active(user);
        if(Double.compare(prior.goal_weight,value)==0 && prior.target_date.equals(targetDate)) return;
        changed(goals.retire(user)); addGoal(user,value,targetDate);
        // Preserve the existing weight-based alert reset behavior for date-only changes.
        if(Double.compare(prior.goal_weight,value)!=0) changed(accounts.alert(user,false));
    }
    @Override public long signIn(String email,String password) {
        return safely(() -> {
            Tables.User u=accounts.byEmail(Validators.email(email)); String p=Validators.password(password,false);
            if(u==null || !PasswordUtils.verifyPassword(p,u.password_salt,u.password_hash))
                throw new AppFailure(AppFailure.Kind.AUTHENTICATION,"password","Email or password is incorrect");
            return u.id;
        });
    }
    @Override public long register(String first,String last,String email,String phone,String password) {
        // Expensive password derivation runs on the caller's worker, outside the write transaction.
        Tables.User u=new Tables.User(); u.first_name=Validators.name(first,"first"); u.last_name=Validators.name(last,"last");
        u.username=Validators.email(email); u.email=u.username; u.phone_number=Validators.phone(phone);
        u.password_salt=PasswordUtils.createSalt(); u.password_hash=PasswordUtils.hashPassword(Validators.password(password,true),u.password_salt);
        u.created_at=Instant.now().toString();
        return tx(() -> {
            if(accounts.byEmail(u.username)!=null) throw new AppFailure(AppFailure.Kind.DUPLICATE_EMAIL,"email","An account already exists for this email");
            long id;
            try { id=accounts.insertUser(u); }
            catch(SQLiteConstraintException ex) {
                if(accounts.byEmail(u.username)!=null) throw new AppFailure(AppFailure.Kind.DUPLICATE_EMAIL,"email","An account already exists for this email");
                throw ex;
            }
            Tables.Settings s=new Tables.Settings(); s.user_id=id; s.phone_number=u.phone_number;
            accounts.insertSettings(s); addGoal(id,150,""); return id;
        });
    }
    @Override public Snapshot load(long user) {
        return tx(() -> { requireUser(user); return new Snapshot(domain(weights.history(user)),domainSettings(user)); });
    }
    /** Inclusive range, chronological rows; latest is the latest overall entry, not last insertion. */
    public DatabaseReport report(long user,String from,String to) {
        String start=Validators.date(from), end=Validators.date(to);
        if(start.compareTo(end)>0) throw AppFailure.invalid("date","Start date must be on or before end date");
        return tx(() -> {
            requireUser(user); active(user);
            Tables.Stats stats=weights.stats(user,start,end);
            List<DatabaseReport.GoalRevision> revisions=new ArrayList<>();
            for(Tables.Goal g:goals.history(user)) revisions.add(new DatabaseReport.GoalRevision(g.id,g.goal_weight,g.target_date,g.created_at,g.active_slot!=null));
            return new DatabaseReport(domain(weights.range(user,start,end)),domain(weights.latest(user)),stats.count,stats.minimum,stats.maximum,stats.average,revisions);
        });
    }
    @Override public long save(long user,WeightInput input) {
        if(input==null) throw AppFailure.invalid("weight","Enter a weight to continue");
        String date=Validators.date(input.date), notes=Validators.notes(input.notes);
        double weight=Validators.weight(Double.toString(input.weight),"weight");
        if(input.goal!=null) Validators.weight(Double.toString(input.goal),"goal");
        return tx(() -> {
            requireUser(user);
            if(input.recordId!=-1 && weights.record(user,input.recordId)==null)
                throw new AppFailure(AppFailure.Kind.NOT_FOUND,"","This weight record no longer exists");
            if(weights.dateExists(user,date,input.recordId))
                throw new AppFailure(AppFailure.Kind.DUPLICATE_DATE,"date","A record already exists for this date. Edit it in History.");
            long id=input.recordId;
            if(id==-1) {
                Tables.Weight w=new Tables.Weight(); w.user_id=user; w.entry_date=date; w.weight=weight; w.notes=notes; w.created_at=Instant.now().toString(); id=weights.insert(w);
            } else changed(weights.update(user,id,date,weight,notes));
            if(input.goal!=null) replaceGoal(user,input.goal,active(user).target_date);
            return id;
        });
    }
    @Override public void delete(long user,long id) {
        tx(() -> { requireUser(user); if(weights.delete(user,id)!=1) throw new AppFailure(AppFailure.Kind.NOT_FOUND,"","This weight record no longer exists"); return null; });
    }
    @Override public void smsSettings(long user,String phone,boolean enabled) {
        String p=enabled?Validators.phone(phone):Validators.text(phone).trim();
        tx(() -> { requireUser(user); changed(accounts.sms(user,p,enabled)); return null; });
    }
    @Override public void alertRequested(long user,boolean requested) {
        tx(() -> { requireUser(user); changed(accounts.alert(user,requested)); return null; });
    }
    @Override public AccountProfile profile(long user) {
        return tx(() -> { Tables.User u=requireUser(user); return new AccountProfile(user,u.first_name,u.last_name,u.email,domainSettings(user)); });
    }
    @Override public void updateProfile(long user,String first,String last,String phone,String unit) {
        String f=Validators.name(first,"first"), l=Validators.name(last,"last"), p=Validators.phone(phone); WeightUnits.of(unit);
        tx(() -> { requireUser(user); changed(accounts.profile(user,f,l,p)); changed(accounts.preferences(user,p,unit)); return null; });
    }
    @Override public void finishSetup(long user,Double goal,Double current,String unit,String targetDate,boolean sms) {
        WeightUnits.of(unit); double target=goal==null?150:Validators.weight(Double.toString(goal),"goal");
        if(current!=null) Validators.weight(Double.toString(current),"weight"); String date=optionalDate(targetDate);
        tx(() -> {
            requireUser(user); Tables.Settings s=settings(user);
            if(s.onboarding_complete) return null;
            if(sms) Validators.phone(s.phone_number);
            if(current!=null) {
                String today=DateUtils.todayIso();
                if(weights.dateExists(user,today,-1)) throw AppFailure.invalid("weight","An entry already exists for today. Edit it in History.");
                Tables.Weight w=new Tables.Weight(); w.user_id=user; w.entry_date=today; w.weight=current; w.notes="Initial weigh-in"; w.created_at=Instant.now().toString(); weights.insert(w);
            }
            replaceGoal(user,target,date); changed(accounts.sms(user,s.phone_number,sms)); changed(accounts.complete(user,unit)); return null;
        });
    }
    @Override public void updateGoals(long user,double goal,String targetDate) {
        Validators.weight(Double.toString(goal),"goal"); String date=optionalDate(targetDate);
        tx(() -> { requireUser(user); replaceGoal(user,goal,date); return null; });
    }
    private Tables.User reauthenticate(long user,String password) {
        Tables.User u=requireUser(user); Validators.password(password,false);
        if(!PasswordUtils.verifyPassword(password,u.password_salt,u.password_hash)) throw AppFailure.invalid("currentPassword","Current password is incorrect");
        return u;
    }
    @Override public void changePassword(long user,String currentPassword,String newPassword) {
        String p=Validators.password(newPassword,true);
        tx(() -> { reauthenticate(user,currentPassword); String salt=PasswordUtils.createSalt(); changed(accounts.password(user,PasswordUtils.hashPassword(p,salt),salt)); return null; });
    }
    @Override public void deleteAccount(long user,String password) {
        tx(() -> { reauthenticate(user,password); changed(accounts.delete(user)); return null; });
    }
}
