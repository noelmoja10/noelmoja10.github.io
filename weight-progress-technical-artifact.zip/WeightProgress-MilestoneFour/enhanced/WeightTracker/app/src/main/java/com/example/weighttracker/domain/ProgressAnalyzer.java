package com.example.weighttracker.domain;

import com.example.weighttracker.model.WeightRecord;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import static com.example.weighttracker.domain.ProgressAnalysis.Status.*;

/**
 * Pure Java trend engine. No storage writes, network calls, Android dependencies, or shared state.
 * Sort a defensive copy: O(n log n). Sliding average + centered regression: O(n).
 * Deque: O(min(n,w)); sorted copy and immutable output: O(n) total additional space.
 */
public final class ProgressAnalyzer {
    public static final int DEFAULT_WINDOW = 7;
    public static final int MAX_WINDOW = 365;
    public static final int MAX_RECORDS = 100_000;
    public static final int MIN_TREND_POINTS = 3;
    public static final int MIN_SPAN_DAYS = 7;
    public static final int MAX_PROJECTION_DAYS = 365;
    public static final int MAX_AGE_DAYS = 30;
    private static final double FLAT_EPSILON = 1e-9;

    private static final class DatedWeight {
        final LocalDate date;
        final double pounds;
        DatedWeight(LocalDate date, double pounds) { this.date = date; this.pounds = pounds; }
    }

    public ProgressAnalysis analyze(List<WeightRecord> records, long userId, double goal,
                                    int windowSize, LocalDate asOf) {
        // Configuration mistakes are programmer errors, not plausible-looking analytics.
        if (windowSize < 1 || windowSize > MAX_WINDOW || asOf == null)
            throw new IllegalArgumentException("Use a window of 1 to 365 entries and an analysis date");
        if (records == null || userId <= 0 || !validWeight(goal)) return empty(windowSize, INVALID_DATA);
        if (records.size() > MAX_RECORDS) return empty(windowSize, LIMIT_EXCEEDED);
        List<DatedWeight> sorted = new ArrayList<>(records.size());
        for (WeightRecord record : records) {
            // Fail closed: don't silently discard corrupt or other-account records and claim a valid trend.
            if (record == null || record.getUserId() != userId || !validWeight(record.getWeight())
                    || record.getEntryDate() == null) return empty(windowSize, INVALID_DATA);
            try {
                LocalDate date = LocalDate.parse(record.getEntryDate());
                if (date.getYear() < 1 || date.getYear() > 9999 || date.isAfter(asOf))
                    return empty(windowSize, INVALID_DATA);
                sorted.add(new DatedWeight(date, record.getWeight()));
            } catch (DateTimeException invalid) { return empty(windowSize, INVALID_DATA); }
        }
        if (sorted.isEmpty()) return empty(windowSize, NO_DATA);
        sorted.sort(Comparator.comparing(value -> value.date));
        for (int i = 1; i < sorted.size(); i++) {
            if (sorted.get(i - 1).date.equals(sorted.get(i).date)) return empty(windowSize, INVALID_DATA);
        }

        ArrayDeque<Double> window = new ArrayDeque<>();
        List<ProgressAnalysis.Point> points = new ArrayList<>(sorted.size());
        double sum = 0, meanX = 0, meanY = 0, sxx = 0, sxy = 0;
        int count = 0;
        LocalDate firstDate = sorted.get(0).date;
        for (DatedWeight item : sorted) {
            window.addLast(item.pounds);
            sum += item.pounds;
            if (window.size() > windowSize) sum -= window.removeFirst();
            points.add(new ProgressAnalysis.Point(item.date, item.pounds, sum / window.size(), window.size()));

            // Online centered moments avoid cancellation in n*sum(x*x) - sum(x)^2.
            // Each measurement has equal weight; x is elapsed calendar days, NOT record index.
            double x = ChronoUnit.DAYS.between(firstDate, item.date);
            count++;
            double dx = x - meanX, dy = item.pounds - meanY;
            meanX += dx / count;
            meanY += dy / count;
            sxx += dx * (x - meanX);
            sxy += dx * (item.pounds - meanY);
        }
        ProgressAnalysis.Point latest = points.get(points.size() - 1);
        long span = ChronoUnit.DAYS.between(firstDate, latest.date);
        Double slope = count >= MIN_TREND_POINTS && span >= MIN_SPAN_DAYS && sxx > 0 ? sxy / sxx : null;
        if (slope != null && !Double.isFinite(slope)) return empty(windowSize, INVALID_DATA);
        ProgressAnalysis.Status status;
        LocalDate projected = null;
        // This app retains its original weight-loss scope, including current <= goal as reached.
        if (latest.weight <= goal) status = GOAL_REACHED;
        else if (slope == null) status = INSUFFICIENT_DATA;
        else if (Math.abs(slope) <= FLAT_EPSILON) status = FLAT_TREND;
        else if (slope > 0) status = MOVING_AWAY;
        else if (ChronoUnit.DAYS.between(latest.date, asOf) > MAX_AGE_DAYS) status = STALE_DATA;
        else {
            // Extrapolate the fitted RATE from the latest observation, not the fitted intercept.
            double days = (goal - latest.weight) / slope;
            // Floating-point regression can turn an exact 16-day estimate into 16.00000000000001.
            // Normalize only within 1e-9 day of an integer before the range check and ceiling.
            double nearestDay = Math.rint(days);
            if (Math.abs(days - nearestDay) <= 1e-9) days = nearestDay;
            if (!Double.isFinite(days) || days <= 0 || days > MAX_PROJECTION_DAYS) status = OUT_OF_RANGE;
            else {
                LocalDate candidate = latest.date.plusDays(Math.max(1L, (long) Math.ceil(days)));
                if (candidate.getYear() > 9999) status = OUT_OF_RANGE;
                else if (candidate.isBefore(asOf)) status = PAST_PROJECTION;
                else { projected = candidate; status = ESTIMATED; }
            }
        }
        return new ProgressAnalysis(points, windowSize, status, slope, projected);
    }
    private boolean validWeight(double value) { return WeightPolicy.validStored(value); }
    private ProgressAnalysis empty(int size, ProgressAnalysis.Status status) {
        return new ProgressAnalysis(Collections.emptyList(), size, status, null, null);
    }
}
