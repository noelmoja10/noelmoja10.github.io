package com.example.weighttracker.ui;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import com.example.weighttracker.R;

/** Shared, compact destructive confirmation with readable copy and clear safe/destructive actions. */
final class ConfirmDialog extends Dialog {
    private final LinearLayout content;
    private final Button cancel, confirm;
    ConfirmDialog(Context context, String title, String message, String cancelLabel, String confirmLabel) {
        super(context); requestWindowFeature(Window.FEATURE_NO_TITLE);
        content = new LinearLayout(context); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(24),dp(24),dp(24),dp(24));
        GradientDrawable panel = new GradientDrawable(); panel.setColor(Color.WHITE); panel.setCornerRadius(dp(24)); content.setBackground(panel);
        ImageView icon = new ImageView(context); icon.setImageResource(R.drawable.ic_delete); icon.setPadding(dp(12),dp(12),dp(12),dp(12));
        GradientDrawable circle = new GradientDrawable(); circle.setColor(context.getColor(R.color.danger_light)); circle.setShape(GradientDrawable.OVAL); icon.setBackground(circle);
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); content.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView heading = text(title,22); heading.setTypeface(null,Typeface.BOLD); heading.setPadding(0,dp(16),0,dp(10)); content.addView(heading);
        TextView detail = text(message,16); detail.setLineSpacing(dp(3),1); content.addView(detail);
        LinearLayout actions = new LinearLayout(context); actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams spacing = new LinearLayout.LayoutParams(-1,-2); spacing.topMargin = dp(24);
        cancel = button(cancelLabel,false); confirm = button(confirmLabel,true);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0,-2,1); left.setMarginEnd(dp(10));
        actions.addView(cancel,left); actions.addView(confirm,new LinearLayout.LayoutParams(0,-2,1)); content.addView(actions,spacing);
        cancel.setOnClickListener(v -> cancel()); ScrollView scroll = new ScrollView(context); scroll.addView(content); setContentView(scroll); setCanceledOnTouchOutside(true);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT)); getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        WindowManager.LayoutParams window = getWindow().getAttributes(); window.dimAmount = .45f; getWindow().setAttributes(window);
    }
    private int dp(int value) { return Math.round(value * getContext().getResources().getDisplayMetrics().density); }
    private TextView text(String value,int size) { TextView view = new TextView(getContext()); view.setText(value); view.setTextSize(size); view.setTextColor(getContext().getColor(R.color.ink)); return view; }
    private Button button(String title,boolean danger) {
        Button button = new Button(getContext()); button.setText(title); button.setTextSize(14); button.setAllCaps(false); button.setMinHeight(dp(48)); button.setMinimumHeight(dp(48));
        button.setPadding(dp(10),dp(8),dp(10),dp(8)); button.setTextColor(getContext().getColor(danger ? R.color.white : R.color.brand));
        if (danger) { GradientDrawable background = new GradientDrawable(); background.setColor(Color.rgb(180,28,40)); background.setCornerRadius(dp(12)); button.setBackground(background); }
        else button.setBackgroundResource(R.drawable.button_secondary);
        return button;
    }
    void extra(View view) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin = dp(16); content.addView(view,content.getChildCount()-1,p);
    }
    void onConfirm(Runnable action) { confirm.setOnClickListener(v -> action.run()); }
    void busy(boolean value) { cancel.setEnabled(!value); confirm.setEnabled(!value); setCancelable(!value); setCanceledOnTouchOutside(!value); }
    @Override public void show() {
        super.show(); int available = getContext().getResources().getDisplayMetrics().widthPixels - dp(40);
        getWindow().setLayout(Math.min(available,dp(420)),ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}
