package com.example.weighttracker.domain;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeParseException;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Calendar-day countdown: not elapsed 24-hour periods, so DST does not shift the count. */
public final class TargetDateDisplay {
    private TargetDateDisplay() { }
    public static String label(String isoDate, LocalDate today) {
        if (isoDate == null || isoDate.trim().isEmpty()) return "";
        try {
            LocalDate target = LocalDate.parse(isoDate);
            long days = ChronoUnit.DAYS.between(today, target);
            String remaining = days == 0 ? "Target is today"
                    : days > 0 ? days + (days == 1 ? " day left" : " days left")
                    : "Target passed " + -days + (days == -1 ? " day ago" : " days ago");
            return target.format(DateTimeFormatter.ofPattern("MMM d, uuuu", Locale.US)) + "\n" + remaining;
        } catch (DateTimeParseException invalidStoredDate) { return ""; }
    }
}
