package com.example.weighttracker;

import android.os.Bundle;
import android.widget.EditText;
import com.example.weighttracker.domain.Validators;
import com.example.weighttracker.presentation.AuthViewModel;
import com.example.weighttracker.ui.BaseActivity;
import com.example.weighttracker.ui.CreateAccountActivity;

/** Launcher and sign-in view only; no database calls or credential state in the Activity. */
public final class MainActivity extends BaseActivity {
    @Override protected boolean requiresLogin() { return false; }
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (app.session.userId() > 0) { authenticated(); return; }
        install(R.layout.activity_login);
        AuthViewModel vm = model(AuthViewModel.class);
        EditText email = field("email", R.id.usernameEditText);
        EditText password = field("password", R.id.passwordEditText);
        toggle(password, R.id.loginPasswordToggleButton);
        rule("email", () -> Validators.email(text(email)));
        rule("password", () -> Validators.password(text(password), false));
        click(R.id.loginButton, () -> { if (valid()) vm.signIn(text(email), text(password)); });
        click(R.id.createAccountButton, () -> open(CreateAccountActivity.class));
        vm.state().observe(this, state -> {
            render(state);
            if (state.completed && vm.consumeCompletion()) { resetForm(() -> password.setText("")); authenticated(); }
        });
    }
}
