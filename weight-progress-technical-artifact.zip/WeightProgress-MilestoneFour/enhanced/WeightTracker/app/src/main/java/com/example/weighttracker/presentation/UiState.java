package com.example.weighttracker.presentation;

import com.example.weighttracker.domain.AppFailure;

public final class UiState<T> {
    public final T data;
    public final boolean loading;
    public final AppFailure error;
    public final String message;
    public final boolean completed;
    public UiState(T data, boolean loading, AppFailure error, String message, boolean completed) {
        this.data = data; this.loading = loading; this.error = error;
        this.message = message; this.completed = completed;
    }
}
