package com.example.weighttracker.domain;

public final class WeightInput {
    public final long recordId;
    public final String date;
    public final double weight;
    public final String notes;
    public final Double goal;
    public WeightInput(long recordId, String date, double weight, String notes, Double goal) {
        this.recordId = recordId; this.date = date; this.weight = weight; this.notes = notes; this.goal = goal;
    }
}
