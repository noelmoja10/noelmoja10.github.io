package com.example.weighttracker.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.Gravity;
import android.widget.*;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.lifecycle.AbstractSavedStateViewModelFactory;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.weighttracker.*;
import com.example.weighttracker.presentation.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

/** Shared view-only navigation, status, and binding. Persistence and validation live elsewhere. */
public abstract class BaseActivity extends ComponentActivity {
    protected WeightApplication app;
    private TextView status;
    private View content;
    private View navigation;
    private TabMotion tabMotion;
    private final FormErrors errors = new FormErrors();
    private final Set<View> locked = new HashSet<>();
    private boolean working;
    private final Map<String, EditText> fields = new LinkedHashMap<>();
    protected boolean requiresLogin() { return true; }
    protected boolean onboarding() { return false; }
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        app = (WeightApplication) getApplication();
        if (requiresLogin() && !onboarding() && Build.VERSION.SDK_INT >= 34) {
            // Whole-window slides would move the bottom bar as well as the page.
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0);
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0);
        }
        if (requiresLogin() && app.session.userId() <= 0) { login(); return; }
        if (requiresLogin() && app.session.needsSetup() && !onboarding()) { authenticated(); return; }
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (working) { Toast.makeText(BaseActivity.this, "Please wait for the current operation", Toast.LENGTH_SHORT).show(); return; }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
                setEnabled(true);
            }
        });
    }
    @Override protected void onResume() {
        super.onResume();
        if (requiresLogin() && app.session.userId() <= 0) login();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Reused top-level screens have no new form arguments. Consume the one-shot motion
        // metadata without replacing their original launch identity or saved-state extras.
        if (tabMotion != null) tabMotion.receive(intent, app.session.userId(), getClass().getName());
    }
    @Override protected void onStop() {
        if (tabMotion != null) tabMotion.finish();
        super.onStop();
    }
    @Override public void finish() {
        super.finish();
        if (requiresLogin() && !onboarding()) suppressWindowAnimation();
    }
    @SuppressWarnings("deprecation")
    private void suppressWindowAnimation() { overridePendingTransition(0, 0); }
    protected void install(int layout) {
        install(getLayoutInflater().inflate(layout, null, false));
    }
    protected void install(View screen) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.surface_soft));
        root.setFocusableInTouchMode(true);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        // Apply insets to the shared container, including status/error messages above each screen.
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets safe = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        status = new TextView(this);
        status.setTextColor(getColor(R.color.ink));
        status.setTextSize(14);
        status.setPadding(24, 8, 24, 8);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LinearLayout page = new LinearLayout(this);
        page.setId(R.id.tabPageContent);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(getColor(R.color.surface_soft));
        page.addView(status, new LinearLayout.LayoutParams(-1, -2));
        content = screen;
        content.setFitsSystemWindows(false);
        page.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        FrameLayout viewport = new FrameLayout(this);
        viewport.setId(R.id.tabContentViewport);
        viewport.setClipChildren(true);
        viewport.addView(page, new FrameLayout.LayoutParams(-1, -1));
        root.addView(viewport, new LinearLayout.LayoutParams(-1, 0, 1));
        if (requiresLogin() && !onboarding()) {
            navigation = navigation();
            root.addView(navigation, new LinearLayout.LayoutParams(-1, dp(76)));
            tabMotion = new TabMotion(viewport, page);
            tabMotion.receive(getIntent(), app.session.userId(), getClass().getName());
        }
        setContentView(root);
        root.requestFocus();
        ViewCompat.requestApplyInsets(root);
    }
    protected EditText field(String key, int id) {
        EditText edit = findViewById(id);
        fields.put(key, edit);
        errors.bind(key, edit);
        if (key.equals("weight") || key.equals("goal")) errors.quietWhenCleared(key);
        if ((edit.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) == InputType.TYPE_TEXT_VARIATION_PASSWORD)
            edit.setTypeface(getResources().getFont(R.font.inter_regular));
        return edit;
    }
    protected void rule(String key, Runnable validation) { errors.rule(key, validation::run); }
    protected boolean valid() { return errors.all(); }
    protected void resetForm(Runnable clear) { errors.reset(clear); }
    protected void confirmation(EditText password, EditText confirmation) { errors.confirmation("confirmation", password, confirmation); }
    protected void locked(View view) { locked.add(view); view.setEnabled(false); }
    protected int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    protected String text(EditText field) { return field.getText().toString(); }
    protected void click(int id, Runnable action) { findViewById(id).setOnClickListener(v -> action.run()); }
    protected void render(UiState<?> state) {
        working = state.loading;
        errors.pause(working);
        enabled(content, !working);
        if (navigation != null) enabled(navigation, !working);
        for (View view : locked) view.setEnabled(false);
        String label = state.loading ? "Working…" : state.error != null ? state.error.getMessage() : state.message;
        if (state.error != null && errors.contains(state.error.field)) {
            errors.show(state.error.field, state.error.getMessage()); label = "";
        }
        status.setText(label);
        status.setVisibility(label.isEmpty() ? View.GONE : View.VISIBLE);
    }
    private void enabled(View view, boolean value) {
        view.setEnabled(value);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) enabled(group.getChildAt(i), value);
        }
    }
    protected void toggle(EditText password, int buttonId) {
        password.setSaveEnabled(false);
        password.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        ImageButton button = findViewById(buttonId);
        final boolean[] visible = {false};
        button.setOnClickListener(v -> {
            visible[0] = !visible[0];
            password.setInputType(InputType.TYPE_CLASS_TEXT | (visible[0]
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            password.setTypeface(getResources().getFont(R.font.inter_regular));
            password.setSelection(password.length());
            button.setImageResource(visible[0] ? R.drawable.ic_visibility_off : R.drawable.ic_visibility);
            button.setContentDescription(visible[0] ? "Hide password" : "Show password");
        });
    }
    protected <T extends ViewModel> T model(Class<T> type) {
        return new ViewModelProvider(this, new AbstractSavedStateViewModelFactory(this, null) {
            @Override @SuppressWarnings("unchecked") protected <VM extends ViewModel> VM create(String key, Class<VM> cls, SavedStateHandle saved) {
                if (cls == AuthViewModel.class) return (VM) new AuthViewModel(app.repository, app.session, app.worker, app.main);
                if (cls == DashboardViewModel.class) return (VM) new DashboardViewModel(app.repository, app.session, app.worker, app.main, app.alerts);
                if (cls == WeightEditorViewModel.class) return (VM) new WeightEditorViewModel(app.repository, app.session, app.worker, app.main, saved, app.alerts);
                if (cls == SmsViewModel.class) return (VM) new SmsViewModel(app.repository, app.session, app.worker, app.main, app.alerts);
                if (cls == AccountViewModel.class) return (VM) new AccountViewModel(app.repository, app.session, app.worker, app.main);
                throw new IllegalArgumentException("Unknown ViewModel");
            }
        }).get(type);
    }
    protected void open(Class<?> destination) {
        Intent intent = new Intent(this, destination);
        if (destination == HomeActivity.class || destination == HistoryActivity.class || destination == MeActivity.class)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        navigate(intent, destination);
    }
    protected void editor(long recordId) {
        navigate(new Intent(this, WeightEditorActivity.class).putExtra("recordId", recordId), WeightEditorActivity.class);
    }
    private void navigate(Intent intent, Class<?> destination) {
        if (tabMotion != null) {
            tabMotion.prepare(intent, tabIndex(getClass()), tabIndex(destination), app.session.userId());
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        }
        startActivity(intent);
        if (tabMotion != null) suppressWindowAnimation();
    }
    private static int tabIndex(Class<?> screen) {
        return screen == HomeActivity.class ? 0 : screen == HistoryActivity.class ? 1
                : screen == WeightEditorActivity.class ? 2 : 3;
    }
    protected void returnToMe() { open(MeActivity.class); finish(); }
    protected void login() {
        startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }
    protected void authenticated() {
        startActivity(new Intent(this, app.session.needsSetup() ? FinishProfileActivity.class : HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }
    private View navigation() {
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER); bar.setBackgroundColor(getColor(R.color.white)); bar.setElevation(dp(8));
        bar.setId(R.id.bottomNavigation);
        Class<?>[] targets = {HomeActivity.class, HistoryActivity.class, WeightEditorActivity.class, MeActivity.class};
        String[] labels = {"Home", "History", "Add Entry", "Me"};
        int[] icons = {R.drawable.ic_home, R.drawable.ic_history, R.drawable.ic_add, R.drawable.ic_person};
        int[] ids = {R.id.navHomeButton, R.id.navHistoryButton, R.id.navAddEntryButton, R.id.navMeButton};
        int selected = tabIndex(getClass());
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            LinearLayout item = new LinearLayout(this); item.setId(ids[i]); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            item.setClickable(true); item.setFocusable(true); item.setSelected(selected == i); item.setContentDescription(labels[i] + (selected == i ? ", selected" : ""));
            ImageView icon = new ImageView(this); icon.setImageResource(icons[i]); icon.setPadding(dp(8),dp(6),dp(8),dp(6));
            icon.setColorFilter(getColor(selected == i ? R.color.brand_dark : R.color.ink));
            if (selected == i) { icon.setBackgroundResource(R.drawable.nav_selected_bg); icon.setElevation(dp(5)); }
            item.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(38)));
            TextView label = new TextView(this); label.setText(labels[i]); label.setTextSize(12); label.setGravity(Gravity.CENTER); label.setTextColor(getColor(selected == i ? R.color.brand_dark : R.color.ink)); item.addView(label,new LinearLayout.LayoutParams(-2,-2));
            item.setOnClickListener(v -> {
                if (getClass() == targets[index] && !(this instanceof WeightEditorActivity && getIntent().getLongExtra("recordId", -1) > 0)) return;
                open(targets[index]);
                if (!(this instanceof HomeActivity)) finish();
            });
            bar.addView(item, new LinearLayout.LayoutParams(0,-1,1));
        }
        return bar;
    }
    protected void menu() {
        new AlertDialog.Builder(this).setTitle("Weight Progress")
                .setItems(new String[]{"Add Weight Record", "Weight History", "SMS Reminders", "Log Out"}, (dialog, which) -> {
                    if (which == 0) editor(-1);
                    else if (which == 1) open(HistoryActivity.class);
                    else if (which == 2) open(SmsSettingsActivity.class);
                    else new AlertDialog.Builder(this).setTitle("Log out?")
                            .setMessage("You can sign back in with your email and password.")
                            .setNegativeButton("Cancel", null).setPositiveButton("Log Out", (d, w) -> { app.session.logout(); login(); }).show();
                }).show();
    }
    protected void notice(String message) { if (!message.isEmpty()) Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
