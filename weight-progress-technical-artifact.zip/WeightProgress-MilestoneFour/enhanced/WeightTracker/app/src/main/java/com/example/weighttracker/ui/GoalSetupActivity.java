package com.example.weighttracker.ui;
public final class GoalSetupActivity extends GoalFormActivity {
    @Override protected boolean onboarding() { return true; }
}
