package com.example.weighttracker.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.core.view.OneShotPreDrawListener;
import com.example.weighttracker.R;

/** Slides only page content. The bottom navigation and system bars are never animation targets. */
public final class TabMotion {
    private static final String TOKEN = "com.example.weighttracker.TAB_MOTION";
    private static long sequence;
    private static Pending pending;

    private final FrameLayout viewport;
    private final View page;
    private ValueAnimator animator;
    private ImageView outgoing;
    private OneShotPreDrawListener beforeDraw;

    TabMotion(FrameLayout viewport, View page) { this.viewport = viewport; this.page = page; }

    /** Positive means travel to a tab on the right; its page enters from the right. */
    public static int direction(int from, int to) { return Integer.compare(to, from); }

    void prepare(Intent intent, int from, int to, long user) {
        finish();
        clearPending();
        int direction = direction(from, to);
        if (direction == 0 || !ValueAnimator.areAnimatorsEnabled()) return;
        Bitmap image = null;
        if (page.getWidth() > 0 && page.getHeight() > 0) {
            // A short-lived, downsampled image gives both pages a continuous slide without
            // retaining an Activity or writing account information to disk.
            float scale = Math.min(1f, 720f / page.getWidth());
            image = Bitmap.createBitmap(Math.max(1, Math.round(page.getWidth() * scale)),
                    Math.max(1, Math.round(page.getHeight() * scale)), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(image);
            canvas.scale(scale, scale);
            page.draw(canvas);
        }
        Pending next = new Pending(++sequence, user, intent.getComponent().getClassName(), direction, image);
        pending = next;
        intent.putExtra(TOKEN, next.token);
        // If navigation is interrupted, release the image even if no destination consumes it.
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (pending == next) clearPending();
        }, 2000);
    }

    void receive(Intent intent, long user, String destination) {
        long token = intent.getLongExtra(TOKEN, -1);
        intent.removeExtra(TOKEN); // Never replay a transition after rotation or process recreation.
        if (pending == null || pending.token != token) return;
        Pending frame = pending;
        pending = null;
        if (frame.user != user || !frame.destination.equals(destination) || !ValueAnimator.areAnimatorsEnabled()) {
            frame.image = null;
            return;
        }
        finish();
        if (frame.image != null) {
            outgoing = new ImageView(viewport.getContext());
            outgoing.setImageBitmap(frame.image);
            // Preserve proportions if closing the keyboard changes the available page height.
            outgoing.setScaleType(ImageView.ScaleType.FIT_START);
            outgoing.setBackgroundColor(viewport.getContext().getColor(R.color.surface_soft));
            outgoing.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            viewport.addView(outgoing, new FrameLayout.LayoutParams(-1, -1));
        }
        frame.image = null;
        viewport.setTag(R.id.tabMotionDirection, frame.direction);
        beforeDraw = OneShotPreDrawListener.add(viewport, () -> {
            beforeDraw = null;
            int width = viewport.getWidth();
            page.setTranslationX(frame.direction * width);
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(280);
            animator.setInterpolator(new DecelerateInterpolator(1.4f));
            animator.addUpdateListener(value -> {
                float fraction = (float) value.getAnimatedValue();
                page.setTranslationX(frame.direction * width * (1f - fraction));
                if (outgoing != null) outgoing.setTranslationX(-frame.direction * width * fraction);
            });
            animator.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator animation) { resetViews(); animator = null; }
            });
            animator.start();
        });
    }

    void finish() {
        if (beforeDraw != null) { beforeDraw.removeListener(); beforeDraw = null; }
        if (animator != null) { animator.cancel(); animator = null; }
        resetViews();
    }

    private void resetViews() {
        page.setTranslationX(0);
        if (outgoing != null) {
            outgoing.setImageDrawable(null);
            viewport.removeView(outgoing);
            outgoing = null;
        }
    }

    private static void clearPending() {
        if (pending != null) pending.image = null;
        pending = null;
    }

    private static final class Pending {
        final long token, user;
        final String destination;
        final int direction;
        Bitmap image;
        Pending(long token, long user, String destination, int direction, Bitmap image) {
            this.token = token; this.user = user; this.destination = destination;
            this.direction = direction; this.image = image;
        }
    }
}
