package com.example.weighttracker.domain;

/** Optional SMS is a separate side effect: its failure must not make a saved weight appear unsaved. */
public final class GoalAlerts {
    public interface Gateway {
        boolean permitted();
        void request(String phone, double current, double goal);
        default void request(String phone, double current, double goal, String unit) { request(phone,current,goal); }
    }
    private final WeightRepository repository;
    private final Gateway gateway;
    public GoalAlerts(WeightRepository repository, Gateway gateway) {
        this.repository = repository; this.gateway = gateway;
    }
    public String evaluate(long userId, Snapshot snapshot) {
        if (snapshot.records.isEmpty()) return "";
        double current = snapshot.records.get(0).getWeight();
        double goal = snapshot.settings.getGoalWeight();
        try {
            if (current > goal) {
                if (snapshot.settings.isGoalAlertSent()) repository.alertRequested(userId, false);
            } else if (!snapshot.settings.isGoalAlertSent() && snapshot.settings.isSmsEnabled()
                    && !snapshot.settings.getPhoneNumber().isEmpty() && gateway.permitted()) {
                gateway.request(snapshot.settings.getPhoneNumber(), current, goal, snapshot.settings.getUnit());
                repository.alertRequested(userId, true);
                return "SMS requested. Delivery is not confirmed.";
            }
            return "";
        } catch (RuntimeException failure) {
            return "Your data was saved, but the SMS request or its status could not be completed.";
        }
    }
}
