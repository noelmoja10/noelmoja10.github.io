package com.example.weighttracker.domain;

/** Safe, user-facing failures. Never expose SQL, passwords, or exception details to a screen. */
public final class AppFailure extends RuntimeException {
    public enum Kind { VALIDATION, DUPLICATE_DATE, DUPLICATE_EMAIL, AUTHENTICATION, NOT_FOUND, STORAGE }
    public final Kind kind;
    public final String field;
    public AppFailure(Kind kind, String field, String message) {
        super(message);
        this.kind = kind;
        this.field = field;
    }
    public static AppFailure invalid(String field, String message) {
        return new AppFailure(Kind.VALIDATION, field, message);
    }
    public static AppFailure storage() {
        return new AppFailure(Kind.STORAGE, "", "Storage is unavailable. Your input has been kept. Please retry.");
    }
}
