package com.example.weighttracker.ui;

import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import com.example.weighttracker.R;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.presentation.AccountViewModel;

public final class ChangePasswordActivity extends BaseActivity {
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        AccountViewModel vm = model(AccountViewModel.class);
        ScreenForm form = new ScreenForm(this,"Change password","Confirm your current password to keep your account safe.");
        form.back("Back to Edit account",() -> getOnBackPressedDispatcher().onBackPressed());
        int secret = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;
        form.input("Current password",R.id.currentPasswordInput,secret,"Current password");
        form.input("New password",R.id.newPasswordInput,secret,"8+ characters, a letter and a number");
        form.input("Confirm new password",R.id.newPasswordConfirmation,secret,"Confirm password");
        form.button("Save password",R.id.passwordSaveButton,false,() -> { }); form.button("Cancel",R.id.profileCancelButton,true,this::finish);
        install(form.root);
        EditText current = field("currentPassword",R.id.currentPasswordInput), updated = field("password",R.id.newPasswordInput), confirm = field("confirmation",R.id.newPasswordConfirmation);
        for (EditText input : new EditText[]{current,updated,confirm}) { input.setSaveEnabled(false); input.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO); }
        rule("currentPassword",() -> { if (text(current).isEmpty()) throw AppFailure.invalid("currentPassword","Current password is required"); });
        rule("password",() -> Validators.password(text(updated),true));
        rule("confirmation",() -> { if (text(confirm).isEmpty() || !text(updated).equals(text(confirm))) throw AppFailure.invalid("confirmation","Password doesn’t match"); });
        confirmation(updated,confirm);
        click(R.id.passwordSaveButton,() -> { if (valid()) vm.password(text(current),text(updated),text(confirm)); });
        vm.state().observe(this,state -> { render(state); if (state.completed && vm.consumeCompletion()) { resetForm(() -> { current.setText(""); updated.setText(""); confirm.setText(""); }); notice(state.message); returnToMe(); } });
    }
}
