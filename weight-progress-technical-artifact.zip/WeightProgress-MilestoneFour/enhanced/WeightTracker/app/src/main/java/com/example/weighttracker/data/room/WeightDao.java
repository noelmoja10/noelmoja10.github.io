package com.example.weighttracker.data.room;

import androidx.room.*;
import java.util.List;

@Dao
public interface WeightDao {
    @Query("SELECT * FROM weight_records WHERE user_id=:user ORDER BY entry_date DESC,id DESC")
    List<Tables.Weight> history(long user);
    @Query("SELECT * FROM weight_records WHERE user_id=:user AND entry_date BETWEEN :start AND :end ORDER BY entry_date ASC,id ASC")
    List<Tables.Weight> range(long user, String start, String end);
    @Query("SELECT * FROM weight_records WHERE user_id=:user ORDER BY entry_date DESC,id DESC LIMIT 1")
    Tables.Weight latest(long user);
    @Query("SELECT COUNT(*) AS count,MIN(weight) AS minimum,MAX(weight) AS maximum,AVG(weight) AS average FROM weight_records WHERE user_id=:user AND entry_date BETWEEN :start AND :end")
    Tables.Stats stats(long user, String start, String end);
    @Query("SELECT * FROM weight_records WHERE id=:id AND user_id=:user") Tables.Weight record(long user,long id);
    @Query("SELECT EXISTS(SELECT 1 FROM weight_records WHERE user_id=:user AND entry_date=:date AND id!=:exceptId)")
    boolean dateExists(long user,String date,long exceptId);
    @Insert long insert(Tables.Weight record);
    @Query("UPDATE weight_records SET entry_date=:date,weight=:weight,notes=:notes WHERE id=:id AND user_id=:user")
    int update(long user,long id,String date,double weight,String notes);
    @Query("DELETE FROM weight_records WHERE id=:id AND user_id=:user") int delete(long user,long id);
}
