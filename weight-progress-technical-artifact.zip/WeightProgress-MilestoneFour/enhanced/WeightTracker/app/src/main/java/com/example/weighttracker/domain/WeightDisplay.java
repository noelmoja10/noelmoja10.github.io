package com.example.weighttracker.domain;

import java.math.BigDecimal;
import java.util.Locale;

public final class WeightDisplay {
    private WeightDisplay() { }
    public static String display(double value) {
        return String.format(Locale.US, value == Math.rint(value) ? "%.0f" : "%.1f", value);
    }
    /** Editable text must round-trip the saved value; display rounding must not alter a record. */
    public static String editable(double value) { return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString(); }
    public static String change(double value) {
        return (value > 0 ? "+" : "") + display(value) + " lbs";
    }
    // Preserve the original weight-loss scope. Gain goals are not introduced in this milestone.
    public static int lossProgress(double start, double current, double goal) {
        if (current <= goal) return 100;
        if (start <= goal || start == current) return 0;
        return (int) Math.max(0, Math.min(100, Math.round((start - current) / (start - goal) * 100)));
    }
}
