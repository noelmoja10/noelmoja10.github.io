package com.example.weighttracker.presentation;

import com.example.weighttracker.domain.*;
import com.example.weighttracker.util.DateUtils;
import java.util.concurrent.Executor;

public final class DashboardViewModel extends TaskViewModel<Snapshot> {
    private final GoalAlerts alerts;
    private boolean quickEntryOperation;
    private int windowSize = ProgressAnalyzer.DEFAULT_WINDOW;
    private final ProgressAnalyzer analyzer = new ProgressAnalyzer();
    public int windowSize() { return windowSize; }
    public void setWindowSize(int size) {
        if (size < 1 || size > ProgressAnalyzer.MAX_WINDOW) throw new IllegalArgumentException("Invalid window");
        if (busy() || size == windowSize) return;
        windowSize = size;
        refresh();
    }
    public boolean isQuickEntryOperation() { return quickEntryOperation; }
    public DashboardViewModel(WeightRepository repo, Session session, Executor worker, Executor main, GoalAlerts alerts) {
        super(repo, session, worker, main); this.alerts = alerts;
    }
    public void refresh() {
        if (busy()) return;
        quickEntryOperation = false;
        long user = session.userId();
        final int window = windowSize;
        execute(() -> result(analyzed(repository.load(user), user, window), "", false));
    }
    public void quickSave(String text) {
        if (busy()) return;
        try {
            Snapshot loaded = state.getValue().data;
            if (loaded == null) throw AppFailure.invalid("weight","Please wait for your account to load");
            double weight = WeightUnits.of(loaded.settings.getUnit()).parse(text, "weight");
            long user = session.userId();
            Snapshot previous = state.getValue().data;
            quickEntryOperation = true;
            execute(() -> {
                try {
                    repository.save(user, new WeightInput(-1, DateUtils.todayIso(), weight, "", null));
                } catch (AppFailure failure) {
                    // Quick Entry has no editable date; keep this error next to its weight field.
                    if (failure.kind == AppFailure.Kind.DUPLICATE_DATE)
                        throw new AppFailure(failure.kind, "weight", "You already have an entry for today. Edit it in History.");
                    throw failure;
                }
                return reloadAfterChange(user, previous, "Weight saved");
            });
        } catch (AppFailure failure) { error(failure); }
    }
    public void delete(long id) {
        if (busy()) return;
        quickEntryOperation = false;
        long user = session.userId();
        Snapshot previous = state.getValue().data;
        execute(() -> {
            repository.delete(user, id);
            return reloadAfterChange(user, previous, "Weight deleted");
        });
    }
    private Result<Snapshot> reloadAfterChange(long user, Snapshot previous, String message) {
        // Persistence has already succeeded. A refresh/SMS error must never invite repeating the write.
        try {
            Snapshot snapshot = repository.load(user);
            String alert = alerts.evaluate(user, snapshot);
            return result(analyzed(snapshot, user, windowSize), message + (alert.isEmpty() ? "" : ". " + alert), true);
        } catch (RuntimeException failure) {
            return result(previous, message + ". Refresh failed; reopen this screen to reload the saved data.", true);
        }
    }
    private Snapshot analyzed(Snapshot snapshot, long user, int window) {
        return new Snapshot(snapshot.records, snapshot.settings,
                analyzer.analyze(snapshot.records, user, snapshot.settings.getGoalWeight(), window, java.time.LocalDate.now()));
    }
}
