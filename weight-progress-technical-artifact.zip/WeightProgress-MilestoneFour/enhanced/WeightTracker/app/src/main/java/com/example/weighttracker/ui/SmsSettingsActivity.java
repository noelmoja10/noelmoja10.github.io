package com.example.weighttracker.ui;

import android.Manifest;
import android.os.Bundle;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.example.weighttracker.R;
import com.example.weighttracker.domain.Snapshot;
import com.example.weighttracker.presentation.UiState;
import com.example.weighttracker.presentation.SmsViewModel;
import com.example.weighttracker.util.SmsNotifier;

/** One explicit preference switch; rendering and loading never trigger a settings write. */
public final class SmsSettingsActivity extends BaseActivity {
    private SmsViewModel vm;
    private Switch reminders;
    private TextView status, recipient;
    private boolean binding;
    private Boolean pendingEnabled;
    private long permissionUser = -1;
    private final ActivityResultLauncher<String> permission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                long requestedBy = permissionUser; permissionUser = -1;
                if (vm == null || requestedBy <= 0 || app.session.userId() != requestedBy) return;
                Snapshot data = vm.state().getValue().data;
                if (data != null) { pendingEnabled = granted; vm.update(data.settings.getPhoneNumber(),granted); }
                if (!granted) notice("SMS permission was not granted. Reminders are off; weight tracking still works.");
            });
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        if (saved != null) permissionUser = saved.getLong("permissionUser",-1);
        vm = model(SmsViewModel.class);
        ScreenForm form = new ScreenForm(this,"SMS reminders","Optional goal alerts. You’re always in control.");
        form.back("Back to Me",this::returnToMe);
        reminders = new Switch(this); reminders.setId(R.id.smsToggle); reminders.setText("SMS reminders");
        reminders.setTextSize(18); reminders.setTypeface(null,android.graphics.Typeface.BOLD);
        reminders.setTextColor(getColor(R.color.ink)); reminders.setMinHeight(dp(64)); reminders.setSwitchPadding(dp(20));
        reminders.setSwitchMinWidth(dp(56));
        reminders.setSaveEnabled(false); // Stored preference, not restored widget state, is authoritative.
        int[][] states = {new int[]{android.R.attr.state_checked},new int[]{}};
        reminders.setThumbTintList(new ColorStateList(states,new int[]{getColor(R.color.brand),getColor(R.color.info)}));
        reminders.setTrackTintList(new ColorStateList(states,new int[]{android.graphics.Color.rgb(116,175,157),android.graphics.Color.rgb(163,174,167)}));
        form.body.addView(reminders,new LinearLayout.LayoutParams(-1,-2));
        status = form.text("Loading your preferences…"); status.setId(R.id.permissionStatusTextView);
        status.setTextSize(15); status.setPadding(dp(14),dp(12),dp(14),dp(12)); status.setBackgroundResource(R.drawable.notification_panel);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        TextView explanation = form.text("Get a text when a saved weight reaches your weight-loss goal. Turn this off at any time without affecting your tracking.");
        explanation.setPadding(0,dp(20),0,dp(20)); explanation.setLineSpacing(dp(3),1);
        TextView caption = form.text("SEND TO"); caption.setTextSize(12); caption.setTextColor(getColor(R.color.muted_ink));
        recipient = form.text(""); recipient.setId(R.id.smsRecipient); recipient.setTextSize(22); recipient.setPadding(0,dp(6),0,dp(4));
        TextView help = form.text("Uses the phone number saved in your account."); help.setTextSize(14); help.setTextColor(getColor(R.color.muted_ink));
        Button edit = form.button("Edit phone number",R.id.editSmsPhoneButton,true,() -> open(ProfileActivity.class));
        LinearLayout.LayoutParams p = (LinearLayout.LayoutParams)edit.getLayoutParams(); p.width = dp(188); p.height = dp(48); edit.setLayoutParams(p); edit.setTextSize(14);
        TextView privacy = form.text("Requires SMS permission and a supported phone/carrier. Carrier charges may apply. These are goal alerts—not scheduled daily reminders. Turning the switch off stops app alerts but does not revoke Android’s permission.");
        privacy.setTextSize(14); privacy.setTextColor(getColor(R.color.muted_ink)); privacy.setPadding(0,dp(24),0,0); privacy.setLineSpacing(dp(3),1);
        install(form.root);
        reminders.setOnCheckedChangeListener((button, enabled) -> {
            if (binding || vm.busy() || permissionUser > 0) return;
            Snapshot data = vm.state().getValue().data;
            if (data == null) { showState(vm.state().getValue()); return; }
            String phone = data.settings.getPhoneNumber();
            if (enabled && !vm.validPhone(phone)) { showState(vm.state().getValue()); return; }
            if (enabled && !SmsNotifier.canSend(this)) {
                permissionUser = app.session.userId(); reminders.setEnabled(false);
                permission.launch(Manifest.permission.SEND_SMS);
            } else { pendingEnabled = enabled; vm.update(phone,enabled); }
        });
        vm.state().observe(this, state -> {
            render(state); showState(state);
            if (state.completed && vm.consumeCompletion()) notice(state.message);
        });
    }
    @Override protected void onResume() {
        super.onResume();
        if (!isFinishing() && vm != null && permissionUser < 0) vm.refresh();
    }
    private void showState(UiState<Snapshot> state) {
        Snapshot data = state.data;
        boolean enabled = data != null && data.settings.isSmsEnabled() && SmsNotifier.canSend(this);
        if (state.loading && pendingEnabled != null) enabled = pendingEnabled;
        else if (!state.loading) pendingEnabled = null;
        binding = true; reminders.setChecked(enabled); binding = false;
        reminders.setEnabled(!state.loading && data != null && permissionUser < 0);
        if (data == null) return;
        String number = data.settings.getPhoneNumber(); recipient.setText(number.isEmpty() ? "No phone number saved" : number);
        status.setText(state.loading ? "Saving your preference…" : enabled ? "On · Goal alerts enabled"
                : SmsNotifier.canSend(this) ? "Off · No text messages will be requested"
                : "Off · Turn on to allow SMS permission");
    }
    @Override protected void onSaveInstanceState(Bundle saved) { saved.putLong("permissionUser",permissionUser); super.onSaveInstanceState(saved); }
}
