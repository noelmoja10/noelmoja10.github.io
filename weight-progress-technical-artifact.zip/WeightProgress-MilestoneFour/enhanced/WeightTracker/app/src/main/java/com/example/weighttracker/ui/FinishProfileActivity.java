package com.example.weighttracker.ui;
public final class FinishProfileActivity extends ProfileActivity {
    @Override protected boolean onboarding() { return true; }
}
