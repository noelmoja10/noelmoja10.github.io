package com.example.weighttracker.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.weighttracker.R;
import com.example.weighttracker.model.AccountProfile;

/** Distinct label/value rows; stack on narrow screens or when larger text is requested. */
public final class AccountDetailsView extends LinearLayout {
    public AccountDetailsView(Context context) {
        super(context); setOrientation(VERTICAL); setPadding(0, dp(16), 0, dp(4));
    }
    public void show(AccountProfile account) {
        removeAllViews();
        row("first", "First Name", account.first, true);
        row("last", "Last Name", account.last, true);
        row("email", "Email", account.email, true);
        row("phone", "Phone", account.settings.getPhoneNumber(), true);
        row("unit", "Weight Units", "kg".equals(account.settings.getUnit()) ? "Kilograms (kg)" : "Pounds (lbs)", false);
    }
    private void row(String key, String label, String value, boolean divider) {
        boolean stacked = getResources().getConfiguration().fontScale > 1.15f
                || getResources().getConfiguration().screenWidthDp < 360;
        LinearLayout row = new LinearLayout(getContext()); row.setOrientation(stacked ? VERTICAL : HORIZONTAL);
        row.setGravity(Gravity.TOP); row.setPadding(0,dp(12),0,dp(12));
        TextView caption = new TextView(getContext()); caption.setText(label); caption.setTextSize(14);
        caption.setTypeface(getResources().getFont(R.font.inter_semibold)); caption.setTextColor(getContext().getColor(R.color.muted_ink));
        caption.setTag("account:" + key + ":label");
        row.addView(caption,new LayoutParams(stacked ? -1 : dp(110),-2));
        TextView text = new TextView(getContext()); text.setText(value == null || value.isEmpty() ? "Not provided" : value);
        text.setTextSize(16); text.setTypeface(getResources().getFont(R.font.inter_medium)); text.setTextColor(getContext().getColor(R.color.brand_dark));
        text.setTag("account:" + key + ":value");
        if (stacked) text.setPadding(0,dp(4),0,0);
        row.addView(text,stacked ? new LayoutParams(-1,-2) : new LayoutParams(0,-2,1)); addView(row,new LayoutParams(-1,-2));
        if (divider) { View line = new View(getContext()); line.setBackgroundColor(getContext().getColor(R.color.line)); addView(line,new LayoutParams(-1,dp(1))); }
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
