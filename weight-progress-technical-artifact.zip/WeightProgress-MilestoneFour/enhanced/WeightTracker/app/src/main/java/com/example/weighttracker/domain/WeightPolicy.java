package com.example.weighttracker.domain;

/** Product input limits, not medical advice. Reading legacy data must never rewrite it. */
public final class WeightPolicy {
    public static final double MAX_ENTRY_LBS = 700;
    public static final double LEGACY_MAX_LBS = 1500;
    private WeightPolicy() { }
    public static boolean validEntry(double pounds) {
        return Double.isFinite(pounds) && pounds > 0 && pounds <= MAX_ENTRY_LBS;
    }
    /** Existing measurements/goals retain the old read envelope for non-mutating analytics. */
    public static boolean validStored(double pounds) {
        return Double.isFinite(pounds) && pounds > 0 && pounds <= LEGACY_MAX_LBS;
    }
}
