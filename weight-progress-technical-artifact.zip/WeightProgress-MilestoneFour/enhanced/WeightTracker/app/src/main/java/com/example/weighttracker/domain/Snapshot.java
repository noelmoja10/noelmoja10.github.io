package com.example.weighttracker.domain;

import com.example.weighttracker.model.UserSettings;
import com.example.weighttracker.model.WeightRecord;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Snapshot {
    public final List<WeightRecord> records;
    public final UserSettings settings;
    public final ProgressAnalysis analysis;
    public Snapshot(List<WeightRecord> records, UserSettings settings) {
        this(records, settings, null);
    }
    public Snapshot(List<WeightRecord> records, UserSettings settings, ProgressAnalysis analysis) {
        this.records = Collections.unmodifiableList(new ArrayList<>(records));
        this.settings = settings;
        this.analysis = analysis;
    }
}
