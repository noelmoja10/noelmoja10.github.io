package com.example.weighttracker.presentation;

import androidx.lifecycle.SavedStateHandle;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.model.WeightRecord;
import com.example.weighttracker.util.DateUtils;
import java.util.concurrent.Executor;

public final class WeightEditorViewModel extends TaskViewModel<Snapshot> {
    private final SavedStateHandle draft;
    private final GoalAlerts alerts;
    private boolean initialized;
    public WeightEditorViewModel(WeightRepository repo, Session session, Executor worker, Executor main,
                                 SavedStateHandle draft, GoalAlerts alerts) {
        super(repo, session, worker, main); this.draft = draft; this.alerts = alerts;
    }
    public String field(String key) { String value = draft.get(key); return value == null ? "" : value; }
    public void draft(String key, String value) {
        if (!(key.equals("weight") || key.equals("date") || key.equals("goal") || key.equals("notes")))
            throw new IllegalArgumentException("Unsupported draft field");
        draft.set(key, value);
    }
    public long recordId() { Long id = draft.get("recordId"); return id == null ? -1 : id; }
    public WeightUnits unit() { return WeightUnits.of(draft.contains("unit") ? draft.get("unit") : "lbs"); }
    public void initialize(long id) {
        if (initialized || busy()) return;
        draft.set("recordId", id);
        long user = session.userId();
        execute(() -> result(repository.load(user), "", false));
    }
    @Override protected void accepted(Snapshot snapshot) {
        if (initialized) return;
        WeightRecord selected = null;
        for (WeightRecord r : snapshot.records) if (r.getId() == recordId()) selected = r;
        if (recordId() != -1 && selected == null) return;
        if (!draft.contains("unit")) draft.set("unit", snapshot.settings.getUnit());
        if (!draft.contains("weight")) draft.set("weight", selected == null ? "" : unit().input(selected.getWeight()));
        if (!draft.contains("date")) draft.set("date", selected == null ? DateUtils.todayDisplay() : DateUtils.formatForDisplay(selected.getEntryDate()));
        if (!draft.contains("notes")) draft.set("notes", selected == null ? "" : selected.getNotes());
        if (!draft.contains("goal")) draft.set("goal", WeightDisplay.editable(snapshot.settings.getGoalWeight()));
        initialized = true;
    }
    public void save() {
        if (busy()) return;
        try {
            if (!initialized) throw new AppFailure(AppFailure.Kind.NOT_FOUND, "", "Unable to load this record. Return to History and retry.");
            long user = session.userId();
            Validators.user(user);
            Snapshot previous = state.getValue().data;
            double pounds = unit().parse(field("weight"),"weight");
            // A note-only edit must not round-trip a rounded unit conversion into stored data.
            for (WeightRecord record : previous.records)
                if (record.getId() == recordId() && field("weight").equals(unit().input(record.getWeight()))) pounds = record.getWeight();
            WeightInput input = new WeightInput(recordId(), Validators.date(field("date")), pounds, Validators.notes(field("notes")), null);
            execute(() -> {
                repository.save(user, input);
                String note = "Weight saved";
                Snapshot refreshed = previous;
                try {
                    refreshed = repository.load(user);
                    String alert = alerts.evaluate(user, refreshed);
                    if (!alert.isEmpty()) note += ". " + alert;
                } catch (RuntimeException failure) { note += ". Reopen History to refresh the saved data."; }
                return result(refreshed, note, true);
            });
        } catch (AppFailure failure) { error(failure); }
    }
}
