package com.example.weighttracker.ui;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.example.weighttracker.domain.AppFailure;
import java.util.*;

/** Accessible, inline errors. Empty fields are quiet until blur or submit. */
final class FormErrors {
    interface Rule { void validate(); }
    private static final class Item {
        EditText input; TextView error; View box; Rule rule; boolean touched, focused, quietWhenCleared;
    }
    private final Map<String, Item> items = new LinkedHashMap<>();
    private boolean paused;
    void pause(boolean value) { paused = value; }
    /** Clearing a successfully submitted form is not a new user validation attempt. */
    void reset(Runnable update) {
        boolean before = paused; paused = true;
        try { update.run(); }
        finally {
            for (Map.Entry<String, Item> entry : items.entrySet()) {
                entry.getValue().touched = false; entry.getValue().focused = false; show(entry.getKey(), "");
            }
            paused = before;
        }
    }
    void bind(String key, EditText input) {
        if (items.containsKey(key)) return;
        Item item = new Item(); item.input = input;
        View box = input.getParent() instanceof FrameLayout ? (View) input.getParent() : input;
        ViewGroup parent = (ViewGroup) box.getParent();
        int position = parent.indexOfChild(box); ViewGroup.LayoutParams previous = box.getLayoutParams();
        parent.removeView(box);
        LinearLayout wrapper = new LinearLayout(input.getContext()); wrapper.setOrientation(LinearLayout.VERTICAL);
        int boxHeight = previous.height;
        previous.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        parent.addView(wrapper, position, previous);
        wrapper.addView(box, new LinearLayout.LayoutParams(-1, boxHeight > 0 ? boxHeight : -2));
        if (box != input) {
            int left = input.getPaddingLeft(), top = input.getPaddingTop(), right = input.getPaddingRight(), bottom = input.getPaddingBottom();
            input.setBackgroundColor(Color.TRANSPARENT); input.setPadding(left,top,right,bottom);
        }
        TextView error = new TextView(input.getContext());
        error.setTag("error:" + key); error.setTextColor(Color.rgb(180, 28, 40)); error.setTextSize(13);
        error.setPadding(2, 6, 2, 0); error.setVisibility(View.GONE);
        error.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        wrapper.addView(error); item.error = error; item.box = box; items.put(key, item);
        show(key, "");
        input.setOnFocusChangeListener((v, focused) -> {
            if (paused) return;
            if (focused) item.focused = true;
            else if (item.focused) { item.focused = false; item.touched = true; validate(key); }
        });
        input.addTextChangedListener(watcher(() -> {
            if (paused) return;
            if (input.hasFocus()) item.focused = true;
            if (item.quietWhenCleared && input.getText().toString().trim().isEmpty()) {
                item.touched = false; show(key, "");
            } else if (item.touched && item.rule != null) validate(key);
            else show(key, "");
        }));
    }
    void rule(String key, Rule rule) { items.get(key).rule = rule; }
    void quietWhenCleared(String key) { items.get(key).quietWhenCleared = true; }
    void show(String key, String message) {
        Item item = items.get(key); if (item == null) return;
        boolean invalid = !message.isEmpty();
        GradientDrawable border = new GradientDrawable();
        border.setColor(Color.WHITE); border.setCornerRadius(12 * item.input.getResources().getDisplayMetrics().density);
        border.setStroke(invalid ? 4 : 2, invalid ? Color.rgb(180,28,40) : Color.rgb(170,177,173));
        int left = item.box.getPaddingLeft(), top = item.box.getPaddingTop(), right = item.box.getPaddingRight(), bottom = item.box.getPaddingBottom();
        item.box.setBackground(border); item.box.setPadding(left,top,right,bottom); item.error.setText(message);
        item.error.setVisibility(invalid ? View.VISIBLE : View.GONE);
        item.input.setContentDescription(invalid ? item.input.getHint() + ". " + message : null);
    }
    boolean contains(String key) { return items.containsKey(key); }
    boolean validate(String key) {
        Item item = items.get(key);
        if (item.rule == null) return true;
        try { item.rule.validate(); show(key, ""); return true; }
        catch (AppFailure failure) { show(key, failure.getMessage()); return false; }
    }
    boolean all() {
        boolean valid = true;
        for (String key : items.keySet()) { items.get(key).touched = true; valid = validate(key) && valid; }
        return valid;
    }
    void confirmation(String key, EditText password, EditText confirmation) {
        Runnable check = () -> {
            if (paused) return;
            Item item = items.get(key);
            if (item.touched || confirmation.hasFocus() || confirmation.length() > 0) {
                item.touched = true; validate(key);
            }
        };
        password.addTextChangedListener(watcher(check)); confirmation.addTextChangedListener(watcher(check));
        confirmation.setOnFocusChangeListener((v, focused) -> {
            if (paused) return;
            if (focused) items.get(key).touched = true;
            check.run();
        });
    }
    static TextWatcher watcher(Runnable changed) {
        return new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) { }
            public void onTextChanged(CharSequence s,int start,int before,int count) { }
            public void afterTextChanged(Editable e) { changed.run(); }
        };
    }
}
