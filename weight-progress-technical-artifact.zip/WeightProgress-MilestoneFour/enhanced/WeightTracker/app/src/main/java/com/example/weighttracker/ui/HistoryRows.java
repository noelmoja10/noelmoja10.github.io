package com.example.weighttracker.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import com.example.weighttracker.R;
import com.example.weighttracker.domain.WeightDisplay;
import com.example.weighttracker.domain.WeightUnits;
import com.example.weighttracker.model.WeightRecord;
import com.example.weighttracker.util.DateUtils;
import java.util.List;
import java.util.function.LongConsumer;

/** Shared row rendering; callbacks carry only record IDs and never access persistence. */
final class HistoryRows {
    private final Context context;
    WeightUnits unit = WeightUnits.LBS;
    private final LongConsumer edit;
    private final LongConsumer delete;
    HistoryRows(Context context, LongConsumer edit, LongConsumer delete) { this.context = context; this.edit = edit; this.delete = delete; }
    private int dp(int value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }
    private TextView label(String text) {
        TextView view = new TextView(context); view.setText(text); view.setTextSize(16); view.setTextColor(context.getColor(R.color.ink)); return view;
    }
    private ImageButton action(int icon, String description, Runnable callback) {
        ImageButton button = new ImageButton(context);
        button.setImageResource(icon); button.setContentDescription(description);
        button.setBackgroundColor(context.getColor(android.R.color.transparent));
        button.setPadding(dp(8), dp(8), dp(8), dp(8));
        button.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));
        button.setOnClickListener(v -> callback.run()); return button;
    }
    private void confirm(WeightRecord record) {
        ConfirmDialog dialog = new ConfirmDialog(context,"Delete weight record?",
                DateUtils.formatForDisplay(record.getEntryDate()) + " · " + unit.display(record.getWeight()) + " " + unit.label
                        + "\n\nThis entry will be permanently removed. Your other entries will stay unchanged.","Keep entry","Delete entry");
        dialog.onConfirm(() -> { dialog.dismiss(); delete.accept(record.getId()); }); dialog.show();
    }
    void recent(LinearLayout container, List<WeightRecord> records) {
        container.removeAllViews();
        if (records.isEmpty()) { container.addView(label("No weight records yet")); return; }
        for (int i = 0; i < Math.min(3, records.size()); i++) {
            WeightRecord record = records.get(i);
            LinearLayout row = new LinearLayout(context); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView value = label(DateUtils.formatForDisplay(record.getEntryDate()) + " - " + unit.display(record.getWeight()) + " " + unit.label);
            value.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1));
            value.setGravity(Gravity.CENTER_VERTICAL);
            value.setOnClickListener(v -> edit.accept(record.getId()));
            row.addView(value); row.addView(action(R.drawable.ic_delete, "Delete weight record", () -> confirm(record))); container.addView(row);
        }
    }
    private TextView cell(String text, int width, boolean bold) {
        TextView view = label(text); view.setTextSize(14); view.setGravity(Gravity.CENTER);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        view.setBackgroundResource(R.drawable.table_cell);
        view.setLayoutParams(new TableRow.LayoutParams(dp(width), dp(64)));
        if (bold) view.setTypeface(context.getResources().getFont(R.font.inter_bold), Typeface.BOLD);
        return view;
    }
    void table(TableLayout table, List<WeightRecord> records) {
        while (table.getChildCount() > 1) table.removeViewAt(1);
        if (records.isEmpty()) {
            TableRow row = new TableRow(context); TextView empty = cell("No records yet", 362, false);
            TableRow.LayoutParams params = (TableRow.LayoutParams) empty.getLayoutParams(); params.span = 5;
            row.addView(empty); table.addView(row); return;
        }
        for (int i = 0; i < records.size(); i++) {
            WeightRecord record = records.get(i);
            double delta = i + 1 == records.size() ? 0 : record.getWeight() - records.get(i+1).getWeight();
            String change = i + 1 == records.size() ? "--" : (delta > 0 ? "+" : "") + unit.display(delta) + " " + unit.label;
            TableRow row = new TableRow(context);
            row.setBaselineAligned(false);
            String date = DateUtils.formatForDisplay(record.getEntryDate());
            // Keep the year readable in a narrow column instead of wrapping its final digit.
            row.addView(cell(date.substring(0, 5) + "\n" + date.substring(6), 76, false));
            row.addView(cell(unit.display(record.getWeight()) + " " + unit.label, 76, false));
            row.addView(cell(change, 80, true));
            ImageButton editButton = action(R.drawable.ic_edit, "Edit weight record", () -> edit.accept(record.getId()));
            editButton.setBackgroundResource(R.drawable.table_cell);
            editButton.setTag("history:edit:" + record.getId());
            editButton.setLayoutParams(new TableRow.LayoutParams(dp(58), dp(64)));
            ImageButton deleteButton = action(R.drawable.ic_delete, "Delete weight record", () -> confirm(record));
            deleteButton.setBackgroundResource(R.drawable.table_cell);
            deleteButton.setTag("history:delete:" + record.getId());
            deleteButton.setLayoutParams(new TableRow.LayoutParams(dp(84), dp(64)));
            row.addView(editButton); row.addView(deleteButton); table.addView(row);
        }
    }
}
