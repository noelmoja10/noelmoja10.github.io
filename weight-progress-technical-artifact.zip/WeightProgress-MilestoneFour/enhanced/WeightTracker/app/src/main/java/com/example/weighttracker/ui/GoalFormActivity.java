package com.example.weighttracker.ui;

import android.Manifest;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.example.weighttracker.R;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.presentation.AccountViewModel;
import com.example.weighttracker.util.SmsNotifier;
import java.time.LocalDate;

/** Optional first-run goals and the later, explicit Save/Cancel editor. */
public class GoalFormActivity extends BaseActivity {
    private AccountViewModel vm;
    private EditText goal, current, date;
    private Switch sms;
    private WeightUnits unit = WeightUnits.LBS;
    private TextView goalCaption, currentCaption;
    private final ActivityResultLauncher<String> permission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (!granted) { sms.setChecked(false); notice("SMS permission was not granted. You can enable reminders later in Me."); }
                saveSetup(granted);
            });
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        if (saved != null) unit = WeightUnits.of(saved.getString("displayUnit","lbs"));
        vm = model(AccountViewModel.class);
        ScreenForm form = new ScreenForm(this,onboarding() ? "Set your goals" : "Update goals",
                onboarding() ? "Step 2 of 2 · Everything here is optional. You can change it later in Me." : "Make a plan that works for you. Save when you’re ready.");
        if (!onboarding()) form.back("Back to Me",this::returnToMe);
        Spinner units = onboarding() ? form.units(R.id.unitSpinner) : null;
        goalCaption = form.text("Goal weight");
        goalCaption.setPadding(0,dp(16),0,dp(8)); goalCaption.setLabelFor(R.id.goalInput);
        goal = form.input("",R.id.goalInput,InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL,"Goal weight");
        if (onboarding()) {
            currentCaption = form.text("Current weight");
            currentCaption.setPadding(0,dp(16),0,dp(8)); currentCaption.setLabelFor(R.id.weightInput);
            current = form.input("",R.id.weightInput,InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL,"Optional current weight");
        }
        date = form.input("Target date · optional",R.id.targetDateInput,InputType.TYPE_CLASS_TEXT,"No target date");
        date.setFocusable(false); date.setClickable(true); date.setOnClickListener(v -> {
            LocalDate initial = LocalDate.now(); try { if (!text(date).isEmpty()) initial = LocalDate.parse(text(date)); } catch (RuntimeException ignored) { }
            new DatePickerDialog(this,(picker,y,m,d) -> date.setText(LocalDate.of(y,m+1,d).toString()),initial.getYear(),initial.getMonthValue()-1,initial.getDayOfMonth()).show();
        });
        Button clearDate = form.button("Clear target date",R.id.clearTargetDateButton,true,() -> date.setText(""));
        clearDate.setVisibility(View.GONE);
        date.addTextChangedListener(FormErrors.watcher(() -> clearDate.setVisibility(text(date).isEmpty() ? View.GONE : View.VISIBLE)));
        if (onboarding()) {
            sms = new Switch(this); sms.setId(R.id.smsOptIn); sms.setText("Enable SMS goal alerts"); sms.setTextSize(16); sms.setPadding(0,dp(18),0,dp(18)); form.body.addView(sms);
            form.text("Off by default. Requires SMS permission and a supported device/carrier. Carrier charges may apply.");
        }
        Button save = form.button(onboarding() ? "Finish setup" : "Save goals",R.id.setupFinishButton,false,this::save);
        form.button(onboarding() ? "← Back" : "Cancel",R.id.setupBackButton,true,this::finish);
        install(form.root); field("goal",R.id.goalInput); field("targetDate",R.id.targetDateInput);
        rule("goal",() -> { if (!text(goal).trim().isEmpty()) unit.parse(text(goal),"goal"); });
        if (current != null) { field("weight",R.id.weightInput); rule("weight",() -> { if (!text(current).trim().isEmpty()) unit.parse(text(current),"weight"); }); }
        if (units != null) {
            units.setSelection(unit == WeightUnits.KG ? 1 : 0);
            units.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                public void onNothingSelected(AdapterView<?> parent) { }
                public void onItemSelected(AdapterView<?> parent,View view,int position,long id) {
                    WeightUnits next = position == 0 ? WeightUnits.LBS : WeightUnits.KG;
                    if (next != unit) {
                        try {
                            Double g = text(goal).trim().isEmpty() ? null : unit.parse(text(goal),"goal");
                            Double c = current == null || text(current).trim().isEmpty() ? null : unit.parse(text(current),"weight");
                            unit = next; if (g != null) goal.setText(unit.input(g)); if (c != null) current.setText(unit.input(c));
                        } catch (AppFailure invalid) { units.setSelection(unit == WeightUnits.KG ? 1 : 0); valid(); notice("Correct or clear the weight before changing units."); }
                    }
                    labels();
                }
            });
        }
        final boolean[] loaded = {saved != null && vm.state().getValue().data != null};
        vm.state().observe(this,state -> {
            render(state); save.setEnabled(!state.loading && state.data != null);
            if (state.data != null && !loaded[0]) {
                loaded[0] = true; unit = WeightUnits.of(state.data.settings.getUnit());
                if (units != null) units.setSelection(unit == WeightUnits.KG ? 1 : 0);
                if (!onboarding()) { goal.setText(unit.input(state.data.settings.getGoalWeight())); date.setText(state.data.settings.getTargetDate()); }
                labels();
            }
            if (state.completed && vm.consumeCompletion()) {
                notice(state.message);
                if (onboarding()) { app.session.requireSetup(false); authenticated(); } else finish();
            }
        });
        labels(); if (vm.state().getValue().data == null) vm.refresh();
    }
    private void labels() {
        goalCaption.setText("Goal weight (" + unit.label + ")"); goal.setHint("Default: " + unit.display(150) + " " + unit.label);
        if (currentCaption != null) currentCaption.setText("Current weight (" + unit.label + ")");
    }
    private void save() {
        if (!valid() || vm.state().getValue().data == null) return;
        if (onboarding()) {
            if (sms.isChecked() && !SmsNotifier.canSend(this)) permission.launch(Manifest.permission.SEND_SMS);
            else saveSetup(sms.isChecked());
        } else {
            double original = vm.state().getValue().data.settings.getGoalWeight();
            double value = text(goal).trim().isEmpty() ? 150 : text(goal).equals(unit.input(original)) ? original : unit.parse(text(goal),"goal");
            vm.goals(value,text(date));
        }
    }
    private void saveSetup(boolean enabled) {
        if (app.session.userId() <= 0 || !valid()) return;
        vm.setup(text(goal).trim().isEmpty() ? null : unit.parse(text(goal),"goal"), text(current).trim().isEmpty() ? null : unit.parse(text(current),"weight"),unit.label,text(date),enabled);
    }
    @Override protected void onSaveInstanceState(Bundle state) { state.putString("displayUnit",unit.label); super.onSaveInstanceState(state); }
}
