package com.example.weighttracker.domain;

import com.example.weighttracker.model.WeightRecord;
import java.util.*;

/** Immutable, account-scoped query result. All weights are canonical pounds. */
public final class DatabaseReport {
    public final List<WeightRecord> records;
    public final WeightRecord latest;
    public final long count;
    public final Double minimum, maximum, average;
    public final List<GoalRevision> goals;
    public DatabaseReport(List<WeightRecord> records,WeightRecord latest,long count,Double min,Double max,Double avg,List<GoalRevision> goals) {
        this.records=Collections.unmodifiableList(new ArrayList<>(records)); this.latest=latest;
        this.count=count; minimum=min; maximum=max; average=avg;
        this.goals=Collections.unmodifiableList(new ArrayList<>(goals));
    }
    public static final class GoalRevision {
        public final long id;
        public final double weight;
        public final String targetDate, recordedAt;
        public final boolean active;
        public GoalRevision(long id,double weight,String date,String recorded,boolean active) {
            this.id=id; this.weight=weight; targetDate=date; recordedAt=recorded; this.active=active;
        }
    }
}
