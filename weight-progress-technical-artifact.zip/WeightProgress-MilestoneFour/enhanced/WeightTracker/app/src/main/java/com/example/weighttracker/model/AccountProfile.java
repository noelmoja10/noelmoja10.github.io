package com.example.weighttracker.model;

public final class AccountProfile {
    public final long id;
    public final String first, last, email;
    public final UserSettings settings;
    public AccountProfile(long id, String first, String last, String email, UserSettings settings) {
        this.id = id; this.first = first; this.last = last; this.email = email; this.settings = settings;
    }
}
