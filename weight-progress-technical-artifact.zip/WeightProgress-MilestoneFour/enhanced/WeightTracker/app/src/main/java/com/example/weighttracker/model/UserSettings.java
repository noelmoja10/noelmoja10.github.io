package com.example.weighttracker.model;

public final class UserSettings {
    private final long userId;
    private final double goalWeight;
    private final String phoneNumber;
    private final boolean smsEnabled;
    private final boolean goalAlertSent;
    private String unit = "lbs", targetDate = "";
    private boolean onboardingComplete = true;

    public UserSettings(
            long userId,
            double goalWeight,
            String phoneNumber,
            boolean smsEnabled,
            boolean goalAlertSent) {
        this.userId = userId;
        this.goalWeight = goalWeight;
        this.phoneNumber = phoneNumber == null ? "" : phoneNumber;
        this.smsEnabled = smsEnabled;
        this.goalAlertSent = goalAlertSent;
    }

    public long getUserId() {
        return userId;
    }

    public UserSettings(long userId, double goal, String phone, boolean sms, boolean alert,
                        String unit, String targetDate, boolean complete) {
        this(userId, goal, phone, sms, alert);
        this.unit = unit; this.targetDate = targetDate == null ? "" : targetDate;
        this.onboardingComplete = complete;
    }
    public String getUnit() { return unit; }
    public String getTargetDate() { return targetDate; }
    public boolean isOnboardingComplete() { return onboardingComplete; }

    public double getGoalWeight() {
        return goalWeight;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean isSmsEnabled() {
        return smsEnabled;
    }

    public boolean isGoalAlertSent() {
        return goalAlertSent;
    }
}
