package com.example.weighttracker.data.room;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.room.*;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import android.database.Cursor;

@Database(entities={Tables.User.class,Tables.Settings.class,Tables.Weight.class,Tables.Goal.class},
        version=4, exportSchema=true)
public abstract class WeightDatabase extends RoomDatabase {
    public abstract AccountDao accounts();
    public abstract WeightDao weights();
    public abstract GoalDao goals();
    public static WeightDatabase open(Context context, String name) {
        return Room.databaseBuilder(context.getApplicationContext(), WeightDatabase.class, name)
                .addMigrations(FROM_1_TO_3, FROM_2_TO_3, FROM_3_TO_4)
                .addCallback(new Callback() {
                    @Override public void onCreate(@NonNull SupportSQLiteDatabase db) { installGuards(db); }
                }).build(); // No main-thread queries, destructive migration, or silent data reset.
    }
    private static void preferences(SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE account_preferences (user_id INTEGER PRIMARY KEY, weight_unit TEXT NOT NULL DEFAULT 'lbs' CHECK(weight_unit IN ('lbs','kg')), target_date TEXT NOT NULL DEFAULT '', onboarding_complete INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
        db.execSQL("INSERT INTO account_preferences(user_id,onboarding_complete) SELECT id,1 FROM users");
    }
    public static final Migration FROM_1_TO_3 = new Migration(1,3) {
        @Override public void migrate(@NonNull SupportSQLiteDatabase db) {
            for (String col : new String[]{"first_name","last_name","email","phone_number"})
                db.execSQL("ALTER TABLE users ADD COLUMN " + col + " TEXT NOT NULL DEFAULT ''");
            db.execSQL("UPDATE users SET email=username WHERE email=''"); preferences(db);
        }
    };
    public static final Migration FROM_2_TO_3 = new Migration(2,3) {
        @Override public void migrate(@NonNull SupportSQLiteDatabase db) { preferences(db); }
    };
    public static final Migration FROM_3_TO_4 = new Migration(3,4) {
        @Override public void migrate(@NonNull SupportSQLiteDatabase db) {
            // Room/SQLiteOpenHelper wraps the complete migration path in one transaction.
            // Missing account rows or orphaned children fail closed, never disappear silently.
            assertEmpty(db,"PRAGMA foreign_key_check");
            assertEmpty(db,"SELECT u.id FROM users u LEFT JOIN user_settings s ON s.user_id=u.id LEFT JOIN account_preferences p ON p.user_id=u.id WHERE s.user_id IS NULL OR p.user_id IS NULL");
            db.execSQL("ALTER TABLE users RENAME TO legacy_users");
            db.execSQL("ALTER TABLE user_settings RENAME TO legacy_settings");
            db.execSQL("ALTER TABLE weight_records RENAME TO legacy_weights");
            db.execSQL("ALTER TABLE account_preferences RENAME TO legacy_preferences");
            db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username TEXT NOT NULL, first_name TEXT NOT NULL, last_name TEXT NOT NULL, email TEXT NOT NULL, phone_number TEXT NOT NULL, password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, created_at TEXT NOT NULL)");
            db.execSQL("CREATE TABLE user_settings (user_id INTEGER NOT NULL PRIMARY KEY, phone_number TEXT NOT NULL, sms_enabled INTEGER NOT NULL, goal_alert_sent INTEGER NOT NULL, weight_unit TEXT NOT NULL, onboarding_complete INTEGER NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE TABLE weight_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user_id INTEGER NOT NULL, entry_date TEXT NOT NULL, weight REAL NOT NULL, notes TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE TABLE weight_goals (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user_id INTEGER NOT NULL, goal_weight REAL NOT NULL, target_date TEXT NOT NULL, created_at TEXT NOT NULL, active_slot INTEGER, FOREIGN KEY(user_id) REFERENCES users(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("INSERT INTO users SELECT id,username,first_name,last_name,email,phone_number,password_hash,password_salt,created_at FROM legacy_users");
            db.execSQL("INSERT INTO user_settings SELECT s.user_id,s.phone_number,s.sms_enabled,s.goal_alert_sent,p.weight_unit,p.onboarding_complete FROM legacy_settings s JOIN legacy_preferences p ON p.user_id=s.user_id");
            db.execSQL("INSERT INTO weight_records SELECT id,user_id,entry_date,weight,notes,created_at FROM legacy_weights");
            // The actual historical goal creation time is unknown: record migration time, not a fabricated date.
            db.execSQL("INSERT INTO weight_goals(user_id,goal_weight,target_date,created_at,active_slot) SELECT s.user_id,s.goal_weight,p.target_date,CURRENT_TIMESTAMP,1 FROM legacy_settings s JOIN legacy_preferences p ON p.user_id=s.user_id");
            for (String pair : new String[]{"legacy_users:users","legacy_settings:user_settings","legacy_weights:weight_records","legacy_settings:weight_goals"}) {
                String[] names=pair.split(":");
                assertEmpty(db,"SELECT 1 WHERE (SELECT COUNT(*) FROM "+names[0]+") != (SELECT COUNT(*) FROM "+names[1]+")");
            }
            // Preserve AUTOINCREMENT high-water marks even when the highest prior row was deleted.
            for (String pair : new String[]{"legacy_users:users","legacy_weights:weight_records"}) {
                String[] names=pair.split(":");
                db.execSQL("UPDATE sqlite_sequence SET seq=MAX(seq,COALESCE((SELECT seq FROM sqlite_sequence WHERE name=?),0)) WHERE name=?",new Object[]{names[0],names[1]});
            }
            for (String table : new String[]{"legacy_weights","legacy_settings","legacy_preferences","legacy_users"}) db.execSQL("DROP TABLE "+table);
            db.execSQL("CREATE UNIQUE INDEX index_users_username ON users(username)");
            db.execSQL("CREATE UNIQUE INDEX index_weight_records_user_id_entry_date ON weight_records(user_id,entry_date)");
            db.execSQL("CREATE UNIQUE INDEX index_weight_goals_user_id_active_slot ON weight_goals(user_id,active_slot)");
            db.execSQL("CREATE INDEX index_weight_goals_user_id_id ON weight_goals(user_id,id)");
            assertEmpty(db,"PRAGMA foreign_key_check");
            installGuards(db);
        }
    };
    private static void assertEmpty(SupportSQLiteDatabase db,String sql) {
        try(Cursor c=db.query(sql)) { if(c.moveToFirst()) throw new IllegalStateException("Migration integrity check failed"); }
    }
    private static void guard(SupportSQLiteDatabase db,String name,String event,String table,String invalid) {
        db.execSQL("CREATE TRIGGER IF NOT EXISTS "+name+" BEFORE "+event+" ON "+table+" WHEN "+invalid+" BEGIN SELECT RAISE(ABORT,'Invalid stored value'); END");
    }
    private static void installGuards(SupportSQLiteDatabase db) {
        // New writes obey the approved range; existing larger legacy measurements remain untouched.
        for(String event:new String[]{"INSERT","UPDATE OF weight,entry_date"})
            guard(db,"guard_weight_"+(event.equals("INSERT")?"insert":"update"),event,"weight_records",
                    "NEW.weight IS NULL OR NEW.weight<=0 OR NEW.weight>700 OR length(NEW.entry_date)!=10 OR NEW.entry_date NOT GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' OR date(NEW.entry_date,'+0 days') IS NULL OR date(NEW.entry_date,'+0 days')!=NEW.entry_date");
        guard(db,"guard_goal_insert","INSERT","weight_goals","NEW.goal_weight IS NULL OR NEW.goal_weight<=0 OR NEW.goal_weight>700 OR (NEW.active_slot IS NOT NULL AND NEW.active_slot!=1) OR (NEW.target_date!='' AND (length(NEW.target_date)!=10 OR date(NEW.target_date,'+0 days') IS NULL OR date(NEW.target_date,'+0 days')!=NEW.target_date))");
        // Goal revision content is immutable; only retiring the active row is allowed.
        guard(db,"guard_goal_update","UPDATE","weight_goals","NEW.user_id!=OLD.user_id OR NEW.goal_weight!=OLD.goal_weight OR NEW.target_date!=OLD.target_date OR NEW.created_at!=OLD.created_at OR NEW.id!=OLD.id OR NOT (OLD.active_slot=1 AND NEW.active_slot IS NULL)");
        for(String event:new String[]{"INSERT","UPDATE"})
            guard(db,"guard_settings_"+event.toLowerCase(java.util.Locale.ROOT),event,"user_settings",
                    "NEW.weight_unit NOT IN ('lbs','kg') OR NEW.sms_enabled NOT IN (0,1) OR NEW.goal_alert_sent NOT IN (0,1) OR NEW.onboarding_complete NOT IN (0,1)");
    }
}
