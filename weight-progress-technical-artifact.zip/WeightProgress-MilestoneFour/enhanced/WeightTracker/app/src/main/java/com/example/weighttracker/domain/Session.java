package com.example.weighttracker.domain;

/** Memory-only authentication. Rotation retains it; process death deliberately requires sign-in. */
public final class Session {
    private volatile long userId = -1;
    private volatile long generation;
    private volatile boolean setupRequired;
    public boolean needsSetup() { return setupRequired; }
    public void requireSetup(boolean value) { setupRequired = value; }
    public long userId() { return userId; }
    public long generation() { return generation; }
    public void signIn(long id) { Validators.user(id); generation++; userId = id; setupRequired = false; }
    public void logout() { generation++; userId = -1; setupRequired = false; }
}
