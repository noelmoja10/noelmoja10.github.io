package com.example.weighttracker.presentation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.weighttracker.domain.*;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/** Serial submissions, retained state, and injectable executors make lifecycle/error paths testable. */
public abstract class TaskViewModel<T> extends ViewModel {
    protected final WeightRepository repository;
    protected final Session session;
    private final Executor worker;
    private final Executor main;
    private boolean cleared;
    protected final MutableLiveData<UiState<T>> state = new MutableLiveData<>(new UiState<>(null, false, null, "", false));
    protected TaskViewModel(WeightRepository repository, Session session, Executor worker, Executor main) {
        this.repository = repository; this.session = session; this.worker = worker; this.main = main;
    }
    public final LiveData<UiState<T>> state() { return state; }
    public final boolean busy() { return state.getValue().loading; }
    public final boolean consumeCompletion() {
        UiState<T> current = state.getValue();
        if (!current.completed) return false;
        state.setValue(new UiState<>(current.data, false, null, "", false));
        return true;
    }
    protected final void error(AppFailure failure) {
        state.setValue(new UiState<>(state.getValue().data, false, failure, "", false));
    }
    protected static final class Result<T> {
        final T data; final String message; final boolean complete;
        Result(T data, String message, boolean complete) { this.data = data; this.message = message; this.complete = complete; }
    }
    protected Result<T> result(T data, String message, boolean complete) { return new Result<>(data, message, complete); }
    protected void accepted(T data) { }
    protected final void execute(Callable<Result<T>> action) {
        if (busy() || cleared) return;
        final long generation = session.generation();
        final T previous = state.getValue().data;
        state.setValue(new UiState<>(previous, true, null, "", false));
        try {
            worker.execute(() -> {
                Result<T> result = null;
                AppFailure failure = null;
                try {
                    if (session.generation() != generation) throw new AppFailure(AppFailure.Kind.AUTHENTICATION, "", "Please sign in again");
                    result = action.call();
                } catch (AppFailure ex) { failure = ex; }
                catch (Exception ex) { failure = AppFailure.storage(); }
                final Result<T> finished = result;
                final AppFailure failed = failure;
                main.execute(() -> {
                    if (cleared) return;
                    if (session.generation() != generation) {
                        state.setValue(new UiState<>(null, false,
                                new AppFailure(AppFailure.Kind.AUTHENTICATION, "", "Please sign in again"), "", false));
                    } else if (failed != null) error(failed);
                    else {
                        accepted(finished.data);
                        state.setValue(new UiState<>(finished.data, false, null, finished.message, finished.complete));
                    }
                });
            });
        } catch (RuntimeException rejected) { error(AppFailure.storage()); }
    }
    @Override protected void onCleared() { cleared = true; }
}
