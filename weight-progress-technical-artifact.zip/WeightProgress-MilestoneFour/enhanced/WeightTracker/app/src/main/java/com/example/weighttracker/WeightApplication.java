package com.example.weighttracker;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import com.example.weighttracker.data.*;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.util.SmsNotifier;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Application-scoped dependencies: never hold an Activity in a retained ViewModel or repository. */
public final class WeightApplication extends Application {
    public final Session session = new Session();
    public final ExecutorService worker = Executors.newSingleThreadExecutor();
    public Executor main;
    public WeightRepository repository;
    public GoalAlerts alerts;
    @Override public void onCreate() {
        super.onCreate();
        Handler handler = new Handler(Looper.getMainLooper());
        main = handler::post;
        repository = new RoomWeightRepository(com.example.weighttracker.data.room.WeightDatabase.open(this, "weight_progress.db"));
        alerts = new GoalAlerts(repository, new GoalAlerts.Gateway() {
            @Override public boolean permitted() { return SmsNotifier.canSend(WeightApplication.this); }
            @Override public void request(String phone, double current, double goal) {
                SmsNotifier.sendGoalReached(WeightApplication.this, phone, current, goal);
            }
            @Override public void request(String phone, double current, double goal, String unit) {
                SmsNotifier.sendGoalReached(WeightApplication.this, phone, current, goal, unit);
            }
        });
    }
}
