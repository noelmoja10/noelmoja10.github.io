package com.example.weighttracker.ui;

import android.os.Bundle;
import com.example.weighttracker.R;
import com.example.weighttracker.presentation.DashboardViewModel;

public final class HistoryActivity extends BaseActivity {
    private DashboardViewModel vm;
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        install(R.layout.activity_history);
        vm = model(DashboardViewModel.class);
        HistoryRows rows = new HistoryRows(this, this::editor, vm::delete);
        findViewById(R.id.historySmsButton).setVisibility(android.view.View.GONE);
        click(R.id.addFromHistoryButton, () -> editor(-1));
        findViewById(R.id.backHomeFromHistoryButton).setVisibility(android.view.View.GONE);
        vm.state().observe(this, state -> {
            if (state.data != null) { rows.unit = com.example.weighttracker.domain.WeightUnits.of(state.data.settings.getUnit()); rows.table(findViewById(R.id.weightHistoryTable), state.data.records); }
            render(state);
            if (state.completed && vm.consumeCompletion()) notice(state.message);
        });
    }
    @Override protected void onResume() { super.onResume(); if (!isFinishing() && vm != null) vm.refresh(); }
}
