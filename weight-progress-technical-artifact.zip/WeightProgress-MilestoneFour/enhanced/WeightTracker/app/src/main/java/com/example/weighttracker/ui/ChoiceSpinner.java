package com.example.weighttracker.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.Spinner;
import com.example.weighttracker.R;

/** Shared native, keyboard-accessible selector with consistent selected and menu states. */
public final class ChoiceSpinner extends Spinner {
    public ChoiceSpinner(Context context) { this(context, null); }
    public ChoiceSpinner(Context context, AttributeSet attrs) {
        super(context, attrs, android.R.attr.spinnerStyle, Spinner.MODE_DROPDOWN);
        setBackgroundResource(R.drawable.choice_control);
        setPopupBackgroundResource(R.drawable.choice_popup);
        setPadding(0, 0, 0, 0);
        setMinimumHeight(dp(48));
    }
    public void options(String[] values) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), R.layout.unit_selection, values) {
            @Override public View getDropDownView(int position, View recycled, ViewGroup parent) {
                CheckedTextView row = (CheckedTextView) super.getDropDownView(position, recycled, parent);
                boolean selected = position == getSelectedItemPosition();
                row.setChecked(selected);
                row.setTypeface(getResources().getFont(selected ? R.font.inter_semibold : R.font.inter_regular));
                row.setTextColor(getContext().getColor(selected ? R.color.brand_dark : R.color.ink));
                row.setBackgroundResource(selected ? R.drawable.choice_selected : R.drawable.choice_option);
                return row;
            }
        };
        adapter.setDropDownViewResource(R.layout.unit_option);
        setAdapter(adapter);
    }
    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        setDropDownWidth(w);
        setDropDownVerticalOffset(h + dp(6));
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
