package com.example.weighttracker.domain;

/** Blocking contract: invoke on the worker executor, never on the Android UI thread. */
public interface WeightRepository {
    long signIn(String email, String password);
    long register(String first, String last, String email, String phone, String password);
    Snapshot load(long userId);
    long save(long userId, WeightInput input);
    void delete(long userId, long recordId);
    void smsSettings(long userId, String phone, boolean enabled);
    void alertRequested(long userId, boolean requested);
    com.example.weighttracker.model.AccountProfile profile(long userId);
    void updateProfile(long userId, String first, String last, String phone, String unit);
    void finishSetup(long userId, Double goalPounds, Double currentPounds, String unit, String targetDate, boolean sms);
    void updateGoals(long userId, double goalPounds, String targetDate);
    void changePassword(long userId, String currentPassword, String newPassword);
    void deleteAccount(long userId, String currentPassword);
}
