package com.example.weighttracker.domain;

import com.example.weighttracker.util.DateUtils;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/** Android-independent boundary rules shared by ViewModels and the repository. */
public final class Validators {
    private Validators() { }
    public static String email(String value) {
        String result = text(value).trim().toLowerCase(Locale.US);
        if (result.isEmpty()) throw AppFailure.invalid("email", "Email is required");
        if (result.length() > 254 || !result.matches("[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+"))
            throw AppFailure.invalid("email", "Enter a valid email address");
        return result;
    }
    public static String phone(String value) {
        String result = text(value).trim().replaceAll("[\\s()-]", "");
        if (result.isEmpty()) throw AppFailure.invalid("phone", "Phone number is required");
        if (!result.matches("\\+?[0-9]{7,15}"))
            throw AppFailure.invalid("phone", "Enter 7 to 15 digits, with an optional +");
        return result;
    }
    public static String name(String value, String field) {
        String result = text(value).trim();
        if (result.isEmpty()) throw AppFailure.invalid(field, (field.equals("first") ? "First name" : "Last name") + " is required");
        if (result.length() < 2 || result.length() > 100)
            throw AppFailure.invalid(field, "Enter a name between 2 and 100 characters");
        return result;
    }
    public static String password(String value, boolean newAccount) {
        String result = text(value);
        if (result.isEmpty()) throw AppFailure.invalid("password", "Password is required");
        if (newAccount && (result.length() < 8 || !result.codePoints().anyMatch(Character::isLetter)
                || !result.codePoints().anyMatch(Character::isDigit)))
            throw AppFailure.invalid("password", "Use 8+ characters with a letter and number");
        return result;
    }
    public static double weight(String value, String field) {
        if (text(value).trim().isEmpty()) throw AppFailure.invalid(field, "Enter a weight to continue");
        try {
            double result = Double.parseDouble(text(value).trim());
            if (WeightPolicy.validEntry(result)) return result;
        } catch (NumberFormatException ignored) { }
        throw AppFailure.invalid(field, "Enter a weight above 0 and up to " + WeightDisplay.display(WeightPolicy.MAX_ENTRY_LBS) + " lbs");
    }
    public static String date(String value) {
        try { return DateUtils.normalizeToIso(value); }
        catch (DateTimeParseException ex) { throw AppFailure.invalid("date", "Use a valid MM/DD/YYYY or YYYY-MM-DD date"); }
    }
    public static String notes(String value) {
        String result = text(value).trim();
        if (result.length() > 2000) throw AppFailure.invalid("notes", "Keep notes within 2000 characters");
        return result;
    }
    public static void user(long id) {
        if (id <= 0) throw new AppFailure(AppFailure.Kind.AUTHENTICATION, "", "Please sign in again");
    }
    public static String text(String value) { return value == null ? "" : value; }
}
