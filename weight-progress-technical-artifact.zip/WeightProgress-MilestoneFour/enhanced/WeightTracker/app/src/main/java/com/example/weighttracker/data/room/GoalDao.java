package com.example.weighttracker.data.room;

import androidx.room.*;
import java.util.List;

@Dao
public interface GoalDao {
    @Query("SELECT * FROM weight_goals WHERE user_id=:user AND active_slot=1 LIMIT 1") Tables.Goal active(long user);
    @Query("SELECT * FROM weight_goals WHERE user_id=:user ORDER BY id DESC") List<Tables.Goal> history(long user);
    @Query("UPDATE weight_goals SET active_slot=NULL WHERE user_id=:user AND active_slot=1") int retire(long user);
    @Insert long insert(Tables.Goal goal);
}
