package com.example.weighttracker.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import com.example.weighttracker.R;
import com.example.weighttracker.presentation.WeightEditorViewModel;
import java.util.LinkedHashMap;
import java.util.Map;

public final class WeightEditorActivity extends BaseActivity {
    private final Map<String, EditText> inputs = new LinkedHashMap<>();
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        ScreenForm form = new ScreenForm(this,getIntent().getLongExtra("recordId",-1) > 0 ? "Edit entry" : "Add entry","Record a weigh-in and track your progress over time.");
        android.widget.TextView unitLabel = form.text("Weight units: lbs");
        form.input("Weight",R.id.weightEditText,android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL,"Weight");
        form.input("Date",R.id.dateEditText,android.text.InputType.TYPE_CLASS_DATETIME | android.text.InputType.TYPE_DATETIME_VARIATION_DATE,"MM/DD/YYYY");
        form.input("Notes · optional",R.id.notesEditText,android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE,"How are you feeling?");
        form.button("Save entry",R.id.saveWeightButton,false,() -> { });
        install(form.root);
        WeightEditorViewModel vm = model(WeightEditorViewModel.class);
        bind(vm, "weight", R.id.weightEditText); bind(vm, "date", R.id.dateEditText);
        bind(vm, "notes", R.id.notesEditText);
        rule("weight",() -> vm.unit().parse(text(inputs.get("weight")),"weight"));
        rule("date",() -> com.example.weighttracker.domain.Validators.date(text(inputs.get("date"))));
        rule("notes",() -> com.example.weighttracker.domain.Validators.notes(text(inputs.get("notes"))));
        click(R.id.saveWeightButton, () -> { if (valid()) vm.save(); });
        vm.state().observe(this, state -> {
            for (Map.Entry<String, EditText> entry : inputs.entrySet()) {
                String value = vm.field(entry.getKey());
                if (!text(entry.getValue()).equals(value)) entry.getValue().setText(value);
            }
            ((Button) findViewById(R.id.saveWeightButton)).setText(vm.recordId() == -1 ? R.string.save_weight_record : R.string.update_weight_record);
            render(state);
            unitLabel.setText("Weight units: " + vm.unit().label + " · change in Me → Account");
            inputs.get("weight").setHint("Weight (" + vm.unit().label + ")");
            if (state.completed && vm.consumeCompletion()) { notice(state.message); open(HistoryActivity.class); finish(); }
        });
        vm.initialize(getIntent().getLongExtra("recordId", -1));
    }
    private void bind(WeightEditorViewModel vm, String key, int id) {
        EditText edit = field(key, id); inputs.put(key, edit);
        edit.setSaveEnabled(false);
        edit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { vm.draft(key, s.toString()); }
            @Override public void afterTextChanged(Editable e) { }
        });
    }
}
