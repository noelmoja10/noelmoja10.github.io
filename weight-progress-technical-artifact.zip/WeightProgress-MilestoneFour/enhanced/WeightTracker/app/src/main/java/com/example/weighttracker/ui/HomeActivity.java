package com.example.weighttracker.ui;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.example.weighttracker.R;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.presentation.DashboardViewModel;

public final class HomeActivity extends BaseActivity {
    private DashboardViewModel vm;
    private String displayUnit;
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        displayUnit = saved == null ? "lbs" : saved.getString("quickUnit","lbs");
        ScreenForm form = new ScreenForm(this,"Weight Progress","Small steps. Meaningful progress.");
        LinearLayout page = (LinearLayout) form.body.getParent();
        View progressCard = getLayoutInflater().inflate(R.layout.view_progress_card,page,false);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1,-2); cardParams.topMargin = dp(14);
        page.addView(progressCard,1,cardParams);
        LinearLayout quickHeading = new LinearLayout(this); quickHeading.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView quickTitle = form.label("Quick entry",22); quickTitle.setId(R.id.quickEntryHeading);
        quickTitle.setTypeface(getResources().getFont(R.font.inter_semibold)); quickTitle.setLabelFor(R.id.quickWeightEditText);
        quickHeading.addView(quickTitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView today = form.label("Today",13); today.setTextColor(getColor(R.color.brand_dark));
        today.setTypeface(getResources().getFont(R.font.inter_medium)); today.setBackgroundResource(R.drawable.choice_selected);
        today.setPadding(dp(12),dp(7),dp(12),dp(7)); quickHeading.addView(today);
        form.body.addView(quickHeading);
        TextView quickHelp = form.text("One small check-in, one step forward."); quickHelp.setTextSize(14);
        quickHelp.setTextColor(getColor(R.color.muted_ink)); quickHelp.setPadding(0,dp(8),0,dp(16));
        form.input("",R.id.quickWeightEditText,android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL,"Weight (lbs)");
        form.button("Save today’s weight",R.id.addWeightButton,false,() -> { });
        TextView recent = form.text("Recent entries"); recent.setTextSize(22); recent.setPadding(0,dp(28),0,dp(12));
        LinearLayout container = new LinearLayout(this); container.setId(R.id.recentHistoryContainer); container.setOrientation(LinearLayout.VERTICAL); form.body.addView(container);
        form.button("View all history",R.id.historyButton,true,() -> open(HistoryActivity.class));
        View trendsCard = getLayoutInflater().inflate(R.layout.view_trends_card,page,false);
        LinearLayout.LayoutParams trendsParams = new LinearLayout.LayoutParams(-1,-2);
        trendsParams.topMargin = dp(14);
        page.addView(trendsCard,trendsParams);
        install(form.root);
        vm = model(DashboardViewModel.class);
        ChoiceSpinner window = findViewById(R.id.trendWindowSpinner);
        window.options(getResources().getStringArray(R.array.trend_windows));
        int[] sizes = {3,7,14};
        window.setSelection(vm.windowSize() == 3 ? 0 : vm.windowSize() == 14 ? 2 : 1);
        window.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id) { vm.setWindowSize(sizes[position]); }
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        EditText weight = field("weight", R.id.quickWeightEditText);
        rule("weight",() -> { if (vm.state().getValue().data != null) WeightUnits.of(vm.state().getValue().data.settings.getUnit()).parse(text(weight),"weight"); });
        click(R.id.addWeightButton, () -> { if (valid()) vm.quickSave(text(weight)); });
        click(R.id.historyButton, () -> open(HistoryActivity.class));
        HistoryRows rows = new HistoryRows(this, this::editor, vm::delete);
        vm.state().observe(this, state -> {
            if (state.data != null) {
                summary(state.data); rows.unit = WeightUnits.of(state.data.settings.getUnit());
                if (state.data.analysis != null) {
                    TrendDisplay trends = new TrendDisplay(state.data.analysis,rows.unit);
                    ((TextView)findViewById(R.id.trendAverage)).setText(trends.average);
                    ((TextView)findViewById(R.id.trendRate)).setText(trends.trend);
                    ((TextView)findViewById(R.id.trendProjection)).setText(trends.projection);
                    ((TextView)findViewById(R.id.trendContext)).setText(trends.context);
                }
                if (!displayUnit.equals(rows.unit.label) && !text(weight).trim().isEmpty()) {
                    try { weight.setText(rows.unit.input(WeightUnits.of(displayUnit).parse(text(weight),"weight"))); }
                    catch (AppFailure invalid) { weight.setText(""); }
                }
                displayUnit = rows.unit.label;
                weight.setHint("Weight (" + rows.unit.label + ")"); rows.recent(findViewById(R.id.recentHistoryContainer), state.data.records);
            }
            else {
                ((TextView) findViewById(R.id.currentWeightTextView)).setText("--");
                ((TextView) findViewById(R.id.goalWeightTextView)).setText("--");
                ((TextView) findViewById(R.id.progressPercentTextView)).setText("--");
                ((TextView) findViewById(R.id.remainingWeightTextView)).setText("");
                ((TextView)findViewById(R.id.trendAverage)).setText("—");
                ((TextView)findViewById(R.id.trendRate)).setText("—");
                ((TextView)findViewById(R.id.trendProjection)).setText(R.string.trends_loading);
                ((TextView)findViewById(R.id.trendContext)).setText("");
            }
            render(state);
            window.setEnabled(!state.loading && state.data != null);
            findViewById(R.id.addWeightButton).setEnabled(!state.loading && state.data != null);
            if (state.completed && vm.consumeCompletion()) {
                if (vm.isQuickEntryOperation()) resetForm(() -> weight.setText(""));
                notice(state.message);
            }
        });
    }
    @Override protected void onResume() { super.onResume(); if (!isFinishing() && vm != null) vm.refresh(); }
    @Override protected void onSaveInstanceState(Bundle state) { state.putString("quickUnit",displayUnit); super.onSaveInstanceState(state); }
    private void summary(Snapshot data) {
        double goal = data.settings.getGoalWeight();
        WeightUnits unit = WeightUnits.of(data.settings.getUnit());
        measurement(R.id.goalWeightTextView,unit.display(goal),unit);
        TextView target = findViewById(R.id.targetDateDisplay);
        String targetLabel = TargetDateDisplay.label(data.settings.getTargetDate(),java.time.LocalDate.now());
        android.text.SpannableString targetText = new android.text.SpannableString(targetLabel);
        int split = targetLabel.indexOf('\n');
        if (split > 0) {
            targetText.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),0,split,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            targetText.setSpan(new android.text.style.RelativeSizeSpan(.88f),split+1,targetText.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        target.setText(targetText); target.setVisibility(targetLabel.isEmpty() ? View.GONE : View.VISIBLE);
        findViewById(R.id.targetDatePanel).setVisibility(targetLabel.isEmpty() ? View.GONE : View.VISIBLE);
        int progress = 0;
        String currentText = "--", remainingText = getString(R.string.progress_empty);
        if (!data.records.isEmpty()) {
            double current = data.records.get(0).getWeight();
            double start = data.records.get(data.records.size() - 1).getWeight();
            progress = WeightDisplay.lossProgress(start, current, goal);
            currentText = unit.display(current);
            remainingText = current <= goal ? "Weight-loss goal reached" : unit.display(current - goal) + " " + unit.label + " left to goal";
        }
        measurement(R.id.currentWeightTextView,currentText,unit);
        ((TextView) findViewById(R.id.progressPercentTextView)).setText(getString(R.string.progress_percent, progress));
        ((TextView) findViewById(R.id.remainingWeightTextView)).setText(remainingText);
        View track = findViewById(R.id.progressTrackLayout), fill = findViewById(R.id.progressFillView);
        final int percent = progress;
        track.post(() -> { ViewGroup.LayoutParams p = fill.getLayoutParams(); p.width = Math.round(track.getWidth() * percent / 100f); fill.setLayoutParams(p); });
    }
    private void measurement(int id,String value,WeightUnits unit) {
        // One styled text run keeps the unit beside short and long numbers at every text size.
        android.text.SpannableString text = new android.text.SpannableString(value + " " + unit.label);
        text.setSpan(new android.text.style.RelativeSizeSpan(.42f),value.length(),text.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ((TextView)findViewById(id)).setText(text);
    }
}
