package com.example.weighttracker.data.room;

import androidx.room.*;

@Dao
public interface AccountDao {
    @Query("SELECT * FROM users WHERE id=:user") Tables.User user(long user);
    @Query("SELECT * FROM users WHERE username=:email LIMIT 1") Tables.User byEmail(String email);
    @Query("SELECT * FROM user_settings WHERE user_id=:user") Tables.Settings settings(long user);
    @Insert long insertUser(Tables.User user);
    @Insert void insertSettings(Tables.Settings settings);
    @Query("UPDATE users SET first_name=:first,last_name=:last,phone_number=:phone WHERE id=:user")
    int profile(long user, String first, String last, String phone);
    @Query("UPDATE user_settings SET phone_number=:phone,weight_unit=:unit WHERE user_id=:user")
    int preferences(long user, String phone, String unit);
    @Query("UPDATE user_settings SET weight_unit=:unit,onboarding_complete=1 WHERE user_id=:user")
    int complete(long user, String unit);
    @Query("UPDATE user_settings SET phone_number=:phone,sms_enabled=:enabled WHERE user_id=:user")
    int sms(long user, String phone, boolean enabled);
    @Query("UPDATE user_settings SET goal_alert_sent=:sent WHERE user_id=:user") int alert(long user, boolean sent);
    @Query("UPDATE users SET password_hash=:hash,password_salt=:salt WHERE id=:user")
    int password(long user, String hash, String salt);
    @Query("DELETE FROM users WHERE id=:user") int delete(long user);
}
