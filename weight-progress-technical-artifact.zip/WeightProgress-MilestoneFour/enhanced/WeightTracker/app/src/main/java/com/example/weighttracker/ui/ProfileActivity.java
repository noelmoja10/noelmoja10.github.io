package com.example.weighttracker.ui;

import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import com.example.weighttracker.R;
import com.example.weighttracker.domain.*;
import com.example.weighttracker.presentation.AccountViewModel;

/** The same profile form supports first-run confirmation and later account edits. */
public class ProfileActivity extends BaseActivity {
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        AccountViewModel vm = model(AccountViewModel.class);
        ScreenForm form = new ScreenForm(this, onboarding() ? "Finish your profile" : "Edit account",
                onboarding() ? "Step 1 of 2 · Check your details before you begin." : "Keep your details and preferred units up to date.");
        if (!onboarding()) form.back("Back to Me",this::returnToMe);
        form.input("First name", R.id.firstNameEditText, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS,"First name");
        form.input("Last name", R.id.lastNameEditText, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS,"Last name");
        EditText email = form.input("Email · cannot be changed", R.id.accountEmailEditText, InputType.TYPE_CLASS_TEXT,"Email");
        email.setTextColor(android.graphics.Color.rgb(101,108,104)); email.setBackgroundResource(R.drawable.readonly_field_bg); email.setPadding(dp(14),0,dp(14),0); locked(email);
        if (!onboarding()) form.button("Change password", R.id.passwordButton,true,() -> open(ChangePasswordActivity.class));
        form.input("Phone", R.id.accountPhoneEditText, InputType.TYPE_CLASS_PHONE,"Phone number");
        Spinner units = onboarding() ? null : form.units(R.id.unitSpinner);
        if (units != null) form.text("Changes to units apply across the app. Your saved measurements stay the same.");
        Button save = form.button(onboarding() ? "Next →" : "Save changes", R.id.profileSaveButton,false, () -> { });
        if (onboarding()) {
            LinearLayout.LayoutParams p = (LinearLayout.LayoutParams)save.getLayoutParams(); p.width = dp(140); p.gravity = Gravity.END; save.setLayoutParams(p);
        } else {
            form.button("Cancel", R.id.profileCancelButton,true,this::finish);
        }
        install(form.root);
        EditText first = field("first",R.id.firstNameEditText), last = field("last",R.id.lastNameEditText), phone = field("phone",R.id.accountPhoneEditText);
        rule("first",() -> Validators.name(text(first),"first")); rule("last",() -> Validators.name(text(last),"last")); rule("phone",() -> Validators.phone(text(phone)));
        final boolean[] populated = {saved != null && vm.state().getValue().data != null};
        save.setOnClickListener(v -> { if (valid() && vm.state().getValue().data != null) vm.profile(text(first),text(last),text(phone), units == null ? vm.state().getValue().data.settings.getUnit() : units.getSelectedItemPosition() == 0 ? "lbs" : "kg"); });
        vm.state().observe(this,state -> {
            render(state); save.setEnabled(!state.loading && state.data != null);
            if (state.data != null && !populated[0]) {
                populated[0] = true; first.setText(state.data.first); last.setText(state.data.last); email.setText(state.data.email); phone.setText(state.data.settings.getPhoneNumber());
                if (units != null) units.setSelection(state.data.settings.getUnit().equals("kg") ? 1 : 0);
            }
            if (state.completed && vm.consumeCompletion()) {
                if (onboarding()) open(GoalSetupActivity.class); else { notice(state.message); finish(); }
            }
        });
        if (vm.state().getValue().data == null) vm.refresh();
    }
}
