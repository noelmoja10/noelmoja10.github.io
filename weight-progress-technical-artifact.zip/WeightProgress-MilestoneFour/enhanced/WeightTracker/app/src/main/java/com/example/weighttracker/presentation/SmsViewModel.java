package com.example.weighttracker.presentation;

import com.example.weighttracker.domain.*;
import java.util.concurrent.Executor;

public final class SmsViewModel extends TaskViewModel<Snapshot> {
    private final GoalAlerts alerts;
    public SmsViewModel(WeightRepository repo, Session session, Executor worker, Executor main, GoalAlerts alerts) {
        super(repo, session, worker, main); this.alerts = alerts;
    }
    public void refresh() {
        long user = session.userId();
        execute(() -> result(repository.load(user), "", false));
    }
    public boolean validPhone(String phone) {
        try { Validators.phone(phone); return true; }
        catch (AppFailure failure) { error(failure); return false; }
    }
    public void update(String phone, boolean enabled) {
        if (busy() || (enabled && !validPhone(phone))) return;
        long user = session.userId();
        Snapshot previous = state.getValue().data;
        execute(() -> {
            repository.smsSettings(user, phone, enabled);
            String note = enabled ? "SMS reminders enabled" : "SMS reminders are off";
            Snapshot snapshot = previous;
            try {
                snapshot = repository.load(user);
                if (enabled) {
                    String alert = alerts.evaluate(user, snapshot);
                    if (!alert.isEmpty()) note += ". " + alert;
                }
            } catch (RuntimeException failure) { note += ". Reopen SMS reminders to refresh the saved data."; }
            return result(snapshot, note, true);
        });
    }
}
