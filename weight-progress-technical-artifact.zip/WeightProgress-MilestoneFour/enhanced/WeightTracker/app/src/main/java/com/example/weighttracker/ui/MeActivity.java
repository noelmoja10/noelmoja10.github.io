package com.example.weighttracker.ui;

import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import com.example.weighttracker.R;
import com.example.weighttracker.presentation.AccountViewModel;

public final class MeActivity extends BaseActivity {
    private AccountViewModel vm;
    private ConfirmDialog deleteDialog;
    private EditText deletePassword;
    private TextView deleteError;
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved); if (isFinishing()) return;
        vm = model(AccountViewModel.class);
        ScreenForm form = new ScreenForm(this,"Me","Your account, goals, and preferences—all in one place.");
        LinearLayout header = new LinearLayout(this); header.setGravity(android.view.Gravity.CENTER_VERTICAL); header.setBaselineAligned(false);
        TextView title = form.label("Account",22); title.setTypeface(null,android.graphics.Typeface.BOLD);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button edit = new Button(this); edit.setId(R.id.editAccountButton); edit.setText("Edit Account"); edit.setAllCaps(false); edit.setTextSize(14);
        edit.setBackgroundResource(R.drawable.button_secondary); edit.setTextColor(getColor(R.color.brand)); edit.setPadding(dp(10),0,dp(10),0); edit.setMinWidth(0); edit.setMinimumWidth(0);
        header.addView(edit,new LinearLayout.LayoutParams(dp(124),dp(48))); edit.setOnClickListener(v -> open(ProfileActivity.class)); form.body.addView(header);
        AccountDetailsView summary = new AccountDetailsView(this); summary.setId(R.id.accountDetails); form.body.addView(summary);
        form.button("SMS reminders",R.id.openSmsButton,true,() -> open(SmsSettingsActivity.class));
        form.button("Update goals",R.id.updateGoalsButton,true,() -> open(GoalFormActivity.class));
        form.button("Log out",R.id.logoutButton,true,() -> { app.session.logout(); login(); });
        Button delete = form.button("Delete account",R.id.deleteAccountButton,true,this::confirmDelete); delete.setTextColor(android.graphics.Color.rgb(180,28,40));
        install(form.root);
        vm.state().observe(this,state -> {
            render(state);
            if (state.data != null) summary.show(state.data);
            if (deleteDialog != null && deleteDialog.isShowing()) {
                deleteDialog.busy(state.loading);
                if (state.error != null) deleteError.setText(state.error.getMessage());
            }
            if (state.completed && vm.consumeCompletion()) { if (deletePassword != null) deletePassword.setText(""); if (deleteDialog != null) deleteDialog.dismiss(); app.session.logout(); notice(state.message); login(); }
        });
    }
    @Override protected void onResume() { super.onResume(); if (vm != null && app.session.userId() > 0) vm.refresh(); }
    private void confirmDelete() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        deletePassword = new EditText(this); deletePassword.setId(R.id.currentPasswordInput); deletePassword.setHint("Current password"); deletePassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); deletePassword.setSaveEnabled(false); deletePassword.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO);
        deletePassword.setTypeface(getResources().getFont(R.font.inter_regular));
        deletePassword.setTextSize(16); deletePassword.setBackgroundResource(R.drawable.edit_text_bg); deletePassword.setPadding(dp(12),dp(8),dp(12),dp(8)); box.addView(deletePassword,new LinearLayout.LayoutParams(-1,dp(54)));
        deleteError = new TextView(this); deleteError.setTextColor(android.graphics.Color.rgb(180,28,40)); deleteError.setAccessibilityLiveRegion(android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE); box.addView(deleteError);
        deleteDialog = new ConfirmDialog(this,"Permanently delete your account?",
                "Your profile, goals, and all weight entries will be removed from this app. This cannot be undone. Confirm your current password to continue.","Keep account","Delete permanently");
        deleteDialog.extra(box); deleteDialog.setOnDismissListener(d -> deletePassword.setText(""));
        deleteDialog.onConfirm(() -> {
            if (text(deletePassword).isEmpty()) { deleteError.setText("Current password is required"); return; }
            deleteError.setText(""); vm.remove(text(deletePassword));
        }); deleteDialog.show();
    }
    @Override protected void onDestroy() { if (deleteDialog != null) deleteDialog.dismiss(); super.onDestroy(); }
}
