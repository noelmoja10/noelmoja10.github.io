package com.example.weighttracker.ui;

import android.os.Bundle;
import android.widget.EditText;
import com.example.weighttracker.R;
import com.example.weighttracker.presentation.AuthViewModel;
import com.example.weighttracker.domain.*;

public final class CreateAccountActivity extends BaseActivity {
    @Override protected boolean requiresLogin() { return false; }
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        install(R.layout.activity_create_account);
        AuthViewModel vm = model(AuthViewModel.class);
        EditText first = field("first", R.id.firstNameEditText), last = field("last", R.id.lastNameEditText);
        EditText email = field("email", R.id.accountEmailEditText), phone = field("phone", R.id.accountPhoneEditText);
        EditText password = field("password", R.id.createPasswordEditText), confirmation = field("confirmation", R.id.confirmPasswordEditText);
        toggle(password, R.id.createPasswordToggleButton);
        toggle(confirmation, R.id.confirmPasswordToggleButton);
        rule("first", () -> Validators.name(text(first), "first"));
        rule("last", () -> Validators.name(text(last), "last"));
        rule("email", () -> Validators.email(text(email)));
        rule("phone", () -> Validators.phone(text(phone)));
        rule("password", () -> Validators.password(text(password), true));
        rule("confirmation", () -> {
            if (text(confirmation).isEmpty() || !text(password).equals(text(confirmation)))
                throw AppFailure.invalid("confirmation", "Password doesn’t match");
        });
        confirmation(password, confirmation);
        click(R.id.submitCreateAccountButton, () -> { if (valid()) vm.register(text(first), text(last), text(email), text(phone), text(password), text(confirmation)); });
        click(R.id.backToLoginButton, this::finish);
        vm.state().observe(this, state -> {
            render(state);
            if (state.completed && vm.consumeCompletion()) {
                resetForm(() -> { password.setText(""); confirmation.setText(""); }); authenticated();
            }
        });
    }
}
