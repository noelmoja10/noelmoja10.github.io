# Weight Progress — Milestone Four

CS 499 Enhancement Three: Databases · Noel Canlas · October 3, 2026

This is the runnable **Room-backed version** of Weight Progress. It carries forward the approved September 25 UI, its 700 lb input limit, and Milestone Three analytics. The database changes follow the Category Three plan: typed entities and DAOs, goal revision history, indexed queries, transactional operations, and tested non-destructive migrations.

## Open and run

1. Extract the technical-artifact ZIP, if using the packaged copy.
2. In Android Studio choose **File → Open** and select `enhanced/WeightTracker`, the directory containing `settings.gradle`. Do not open the outer `enhanced` directory.
3. Allow Gradle sync. Use **JDK 21**, Android SDK **36.1**, and the supplied Gradle wrapper. Dependencies require network access on a first build.
4. Select **app / debug**, choose an Android emulator/device (API 26 or higher), and Run.
5. Create a fictional account for review. SMS is optional; leave it off unless intentionally testing permissions on a suitable device.

The visible app name remains **Weight Progress**. Its debug package is `com.example.weighttracker.milestone4`, so it installs separately from earlier milestone and UI-review apps. Existing accounts in those packages are **not copied**. Migration tests use disposable legacy fixtures, not private databases. The standalone APK is a convenience preview, not a substitute for the required source ZIP.

## Build and test

```sh
./gradlew testDebugUnitTest assembleDebug assembleDebugAndroidTest lintDebug
./gradlew connectedDebugAndroidTest
```

The first command needs no emulator. The second needs a connected emulator/device and runs the database, benchmark, and UI tests. It may remove the test installation afterward; Run the app again for interactive review. No release signing keys are included. The debug APK is generated in `app/build/outputs/apk/debug/app-debug.apk`.

The implementation uses Java, Android Gradle Plugin 9.2.1, Gradle 9.4.1, and Room 2.8.4 with Java annotation processing. Room's exported version-4 schema is checked in under `app/schemas/`; its directory is declared to Gradle's compiler argument provider. Room runs behind the existing worker-thread repository interface, without main-thread queries or destructive-migration fallback.

## Review the enhancement

- `DATABASE_DESIGN.md`: relationships, migration, transactions, security, queries, and demonstration steps.
- `app/src/main/java/com/example/weighttracker/data/room/`: four entities, three DAOs, migrations, and database guards.
- `app/src/main/java/com/example/weighttracker/data/RoomWeightRepository.java`: production adapter and range/statistics/goal-history report.
- `app/src/androidTest/java/com/example/weighttracker/RoomInstrumentedTest.java`: 23 Room and migration tests.
- `app/src/androidTest/java/com/example/weighttracker/PerformanceInstrumentedTest.java`: measurements across four history sizes.
- `ALGORITHM_DESIGN.md`: unchanged Milestone Three complexity analysis.
- Outer `evidence/` and `REVIEW GUIDE.md`: actual results, synthetic screenshots, and submission inventory.

Goal history and summary queries are demonstrated through repository tests and Database Inspector, not a new UI screen. Existing goal editing writes revisions automatically. The legacy SQLite helper/adapter exist **only in androidTest** for migration fixtures and baseline tests; production uses Room.

## Scope and limitations

Weights remain stored in pounds; lbs/kg is a display preference. Larger legacy values are retained without rounding; new/edited values must be greater than zero and at most 700 lbs. Older accounts' goal history begins at migration because earlier revisions were never stored. The migrated goal timestamp records migration, not an invented original creation date.

Tests use synthetic accounts and a non-sending SMS gateway. Verification covers one API 35 emulator, not every supported Android version, physical device, carrier, or accessibility configuration. Room does not encrypt the database. Full-history UI/analytics still materialize records in memory; indexing alone does not make those paths constant-time.

This package has not been submitted to the course or published to GitHub. Font assets and third-party notices are retained. `README-CS360.md` describes the original artifact, not current setup instructions.
