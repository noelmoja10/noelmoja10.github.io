# Weight trend analysis

## Scope

Milestone Three adds algorithms to the Weight Progress CS 360 artifact. The starting point is the September 19 UI Preview, including all its UI fixes. The original CS 360 project and an exact pre-analytics snapshot are also included so prior architecture/UI work is not mistaken for newly implemented algorithm work.

Home now includes a **Weight trends** card below Recent entries. It displays the latest moving average, an all-history daily linear trend, and a conditional estimated weight-loss goal date. The existing current/goal card, progress percentage, chosen target date/countdown, quick entry, and fixed bottom navigation keep their previous behavior. A forecast does not change the stored target date or trigger SMS.

**September 25 UI-review copy:** This document describes the inherited Milestone Three algorithm. Original/pre-analytics snapshots remain in the separate Milestone Three package, not this review ZIP. The preview adds the requested UI refinements and a 700 lb new/edit input limit, centralized in `WeightPolicy`. Read-only analytics deliberately retains the prior 1,500 lb envelope for legacy stored measurements and goals so existing data is not silently discarded, changed, or made unreadable. Newly entered or edited values must satisfy the tighter limit. No database schema or algorithmic formula is changed.

## Data flow and contracts

`HomeActivity → DashboardViewModel worker → repository.load(user) → ProgressAnalyzer → immutable ProgressAnalysis in Snapshot → TrendDisplay → Home views`

- The repository still enforces account ownership; the analyzer additionally rejects any record whose user ID differs from the supplied signed-in user. It never publishes partial results from a mixed-account input.
- Inputs are immutable weight records in **pounds**, the existing storage unit. Output averages/rates remain in pounds until the presentation layer converts to lbs/kg. Unit changes do not modify measurements, window membership, or projected dates.
- `ProgressAnalyzer` is independent of Android, storage, and wall-clock time. The caller supplies `asOf`, making tests deterministic. It does not read notes, names, email, or phone numbers.
- The ViewModel runs loading and analytics on the existing worker executor. Its session-generation check rejects results after logout or account change. Analysis has no persistence or SMS side effects.
- The selected moving-average window is 3, 7, or 14 **entries**, default 7. It survives Activity recreation through the retained ViewModel, but it is not a persistent account preference. The engine supports windows of 1–365 entries for testing/reuse.

## Algorithm

1. Validate configuration, account scope, finite positive weights/goals up to 1,500 lbs, and real dates in years 1–9999. Reject future dates and duplicate dates. Refuse more than 100,000 records at the analytics boundary. These are application constraints, not medical criteria.
2. Copy and sort observations by date ascending without changing the input list. The original repository list remains newest-first for Home and History.
3. Traverse once. Add each weight to an `ArrayDeque` and running sum; when the window exceeds `w`, subtract and remove its oldest value. Divide by actual window size, including partial starting windows. No missing days are invented or interpolated.
4. During the same traversal, compute centered running means and covariance for elapsed calendar days `x` and weight `y`. This yields the ordinary least-squares slope without repeatedly scanning the series. Using calendar days instead of entry positions accounts for irregular gaps; each recorded observation still has equal weight.
5. Return immutable dated points containing the measured weight, moving average, and actual sample count. With at least 3 distinct observations spanning 7 days, compute the daily slope as centered covariance divided by centered variance. Centered moments avoid the cancellation risk in raw sum-of-squares subtraction.
6. Retain the app's existing weight-loss scope. The latest weight at or below goal means reached. Otherwise, require a negative, non-flat slope and a last entry no older than 30 days for a forecast. Estimate remaining days from **(goal − latest weight) / daily slope**. This extrapolates a fitted rate from the latest actual observation; it is not the intercept-based crossing of the entire fitted line.
7. Show a date only within 365 days of the latest observation and not before `asOf`. Round fractional days up. Normalize values within 1e-9 day of an integer before rounding so floating-point noise cannot add an extra day. This numerical tolerance is not a clinical tolerance.

The 3-point/7-day minimum, 30-day freshness rule, and one-year horizon are conservative product display policies, not scientifically validated forecasting guarantees. Flat means a slope magnitude no greater than 1e-9 lbs/day for numerical handling. The UI explains insufficient, flat, rising, stale, invalid, and out-of-range cases rather than producing a misleading date.

### Pseudocode

```text
analyze(records, user, goal, windowSize, asOf):
    validate configuration
    validate every record and account ownership, or return unavailable
    sort a defensive copy by date ascending
    reject duplicate dates
    window = empty deque; runningSum = 0
    initialize count, meanX, meanY, centeredXX, centeredXY
    for each dated observation:
        append weight; add it to runningSum
        if window too large: subtract and remove oldest weight
        append immutable point(weight, runningSum / window.size, date)
        x = elapsed calendar days since earliest observation
        update centered regression moments using x and weight
    slope = centeredXY / centeredXX when count and span are sufficient
    select explicit forecast status using latest measurement and slope
    return immutable points, slope, status, optional projected date
```

## Complexity and tradeoffs

Let `n` be the number of observations and `w` the configured entry window.

| Operation | Time | Additional space |
|---|---|---|
| Validation and defensive copy | O(n) | O(n) |
| Sorting | O(n log n) worst case | O(n) worst case |
| Sliding averages and regression | O(n) amortized | O(min(n,w)) deque plus O(n) output |
| Complete analysis | O(n log n) worst case | O(n) |
| Naive repeated-window average, excluding sorting | O(n × min(n,w)) | O(n) if all output points are kept |

Java documents most `ArrayDeque` operations as amortized constant time (Oracle, n.d.). The implementation uses end operations, not linear-time value removal. Every weight enters once and leaves at most once. For fixed small `w`, both average implementations are asymptotically O(n); the variable-window comparison explains the benefit as `w` grows. Sorting is included in the complete bound, so this project does not claim the entire analyzer is O(n) for arbitrary input.

The regression test compares all 20,000 moving averages at `w = 365` against an independent naive implementation: 7,233,570 reference weight visits versus 39,635 deque end operations by algorithmic count. These are not elapsed-time measurements or a claim of a corresponding wall-clock speedup. The full output list is retained for inspectability/future charting; only its latest smoothed value is displayed today.

## Limits and safeguards

- Ordinary least squares is sensitive to outliers and extrapolation can be poor (NIST/SEMATECH, n.d.). This implementation does not claim confidence intervals, medical validity, causal explanations, or guaranteed goal attainment. The UI states that estimates assume the past trend continues.
- An all-history rate can lag a recent change in behavior. Changing the averaging window changes smoothing, **not** the regression sample. A rolling regression or robust fit would need a separate design decision and tests.
- The original plan suggested retaining valid records. This implementation deliberately rejects an invalid/ambiguous dataset as a whole, with no partial forecast; silent removal could change the apparent trend. Corrections remain available in History.
- No analytics schema change, Room dependency, real SMS, telemetry, or cloud service is added. Existing SQLite v3 migration/account security from the UI Preview are retained.
- The history-size guard bounds engine work but does not make the existing repository load or full History table paginated. Large-history UI performance is not established by the pure-engine test.

## Review and test locations

- `app/src/main/java/com/example/weighttracker/domain/ProgressAnalyzer.java`
- `app/src/main/java/com/example/weighttracker/domain/ProgressAnalysis.java`
- `app/src/main/java/com/example/weighttracker/domain/TrendDisplay.java`
- `app/src/main/java/com/example/weighttracker/presentation/DashboardViewModel.java`
- `app/src/main/java/com/example/weighttracker/ui/HomeActivity.java`
- `app/src/main/res/layout/view_trends_card.xml`
- `app/src/test/java/com/example/weighttracker/domain/ProgressAnalyzerTest.java`
- `app/src/test/java/com/example/weighttracker/presentation/ViewModelTest.java`
- `app/src/androidTest/java/com/example/weighttracker/ScreenInstrumentedTest.java` (three `analytics...` tests)

## Sources

Oracle. (n.d.). *ArrayDeque (Java SE 11).* https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/ArrayDeque.html

NIST/SEMATECH. (n.d.). *Linear least squares regression.* In *e-Handbook of Statistical Methods*. https://www.itl.nist.gov/div898/handbook/pmd/section1/pmd141.htm
