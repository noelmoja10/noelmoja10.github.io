# Milestone Four verification

Completed October 2–3, 2026. Final source, APK, tests, and package audited October 3.

## Results

| Check | Result |
| --- | --- |
| Debug app and instrumentation builds | Passed |
| Unit tests | 100 passed, 0 failures/errors/skips |
| Emulator tests | 79 passed: 23 Room/migration, 37 Room-backed UI, 18 legacy baseline, 1 benchmark |
| Lint | 0 errors/fatals; 135 warnings |
| Supported migration paths | 1 → 3 → 4, 2 → 3 → 4, 3 → 4 passed |
| Preserved snapshots | Original matches Milestone Three original; pre-database matches approved UI exactly |
| UI/presentation/resources/analytics | Existing files unchanged from approved UI baseline |
| Packaging | Source hashes and ZIP read-back verified by the packaging script |

Build: JDK 21, Gradle 9.4.1, AGP 9.2.1, SDK 36.1, Room 2.8.4. Emulator: WeightProgress_API35, Android 15, ARM64. Production application ID for this debug build: `com.example.weighttracker.milestone4`. Sources use the inherited Java 11 language target.

## What the tests establish

The 23 Room tests verify chronological and inclusive range queries, latest-by-date rather than insertion order, SQL aggregates including empty ranges, immutable reports, account isolation, CRUD, duplicate handling, SQL metacharacters as data, foreign keys, unique active goals, units/ranges/calendar dates, revision immutability, main-thread rejection, concurrent goal updates, and index search plans. Failure injection verifies registration, setup, and measurement/goal rollback. Password changes and deletion require reauthentication, and account deletion cascades without deleting another account's rows.

Migration fixtures cover versions 1, 2, and 3 with existing credentials, notes, precise large measurements, different profile/SMS contacts, goals, alert state, and preferences. They check reopen behavior, preservation of deleted-ID high-water marks, and fresh-equivalent guards after migration. Missing required legacy settings abort safely without removing the old user or changing its schema version. Row counts and foreign keys are checked inside migration as well as through fixture assertions. New values obey 700 lbs while legacy values above 700 remain preserved.

The 37 inherited screen tests now use Room. They exercise navigation, validation, lifecycle/rotation, account flows, units, approved selectors/typography, inline duplicate errors, progress/history, SMS toggle behavior, and analytics. The 18 legacy-adapter tests remain a comparison/regression set and are not counted as Room-specific coverage. The benchmark measures four workload sizes with methodology and limits in `BENCHMARKS.md`.

## Evidence and limitations

`build.log`, `instrumentation-final.log`, `unit-tests/`, and `lint-results-debug.xml` contain actual outputs. `package-summary.json` records file changes, counts, and checksums; `source-sha256.json` covers all three source snapshots. Screenshots are generated from synthetic-account tests. No private account database or release signing key is included. The SMS gateway in tests sends no real texts.

Lint warnings remain and are included for transparency: 100 hard-coded/localization text warnings, 27 unused resources, 7 layout optimization warnings, and 1 newer Android Gradle Plugin suggestion. Consult the full report before deciding which to address. Passing lint means no configured blocking errors, not a warning-free or accessibility-certified app.

Only one emulator/API was exercised. Broader device/API coverage, TalkBack auditing, real SMS delivery, production performance, encryption at rest, and recovery of already-corrupt legacy data are not established. Unsupported or inconsistent databases fail without destructive fallback. Separate milestone debug packages do not share or automatically migrate one another's data.

No course submission or GitHub publication was performed.
