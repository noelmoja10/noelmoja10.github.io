# Measured history-size benchmarks

Final verification: October 3, 2026. Source: `instrumentation-final.log` and `PerformanceInstrumentedTest.java`.

## Method

One Android 15/API 35 ARM64 emulator, debug build, synthetic accounts only. Each dataset contains daily weights ending October 2, 2026. The analyzer receives a reproducibly shuffled copy (seed 42) and a seven-entry window. Database inserts occur before timing. Each operation receives five warmups followed by eleven System.nanoTime measurements. Median is the sixth sorted sample; nearest-rank p95 is the eleventh (maximum) sample. SQL calls run against the populated database with warm caches. Results include emulator/JIT/GC/scheduling variability; they are exploratory, not a production benchmark or a statistically stable tail-latency estimate.

## Results

All cells show **median / p95 in milliseconds**.

| Entries | Full analyzer | SQL aggregate | Latest query | Full repository report |
| ---: | ---: | ---: | ---: | ---: |
| 10 | 0.189 / 0.476 | 0.218 / 0.851 | 0.214 / 0.268 | 1.822 / 2.147 |
| 100 | 0.644 / 1.141 | 0.218 / 0.397 | 0.175 / 0.311 | 2.638 / 3.187 |
| 1,000 | 5.435 / 17.282 | 0.254 / 0.749 | 0.297 / 0.744 | 6.510 / 10.340 |
| 10,000 | 21.082 / 22.273 | 0.851 / 0.909 | 0.058 / 0.308 | 18.679 / 21.486 |

## Interpretation and limits

The full analyzer includes sorting, sliding-window averages, and regression, not only the O(n) averaging pass. Its documented worst-case overall cost remains O(n log n). SQL aggregates scan matching records; the latest query can stop at the indexed endpoint. The full report also materializes range rows and goal revisions inside a transaction. These are different workloads, so their timings are not an apples-to-apples algorithm comparison.

At larger sizes, analyzer/report work grows while aggregate-only work avoids creating a WeightRecord for every row. Smaller inputs do not scale monotonically because runtime overhead and measurement noise can dominate. No before/after speedup, constant-time aggregate, universal response-time guarantee, or power/battery result is claimed. Full-history UI loading remains a potential scaling limit. Repeat on physical devices and use a controlled release benchmark harness before setting a performance budget.

The measurements address the Milestone Three instructor suggestion to accompany complexity discussion with runs at different history sizes. They supplement the existing independent reference and operation-count tests rather than replacing correctness checks.

Reproduce with the full instrumentation suite or select only `com.example.weighttracker.PerformanceInstrumentedTest` in the test runner. The test deletes only its own uniquely named synthetic database.
